# Character-Specific Stand Arrow Theme Music

Add character-specific theme music playback when a character activates a Stand Arrow for the first time during battle, featuring seamless looping, snappy 0.5-second crossfades, audio ducking for combat sound effects, and full pause/resume and match-end lifecycle synchronization.

## User Review & Critical Decisions

> [!IMPORTANT]
> The following user preferences have been confirmed and incorporated into the design:
> - **Playback Loop Behavior**: The character's theme will loop continuously throughout the battle until the match ends or another character activates a Stand Arrow.
> - **Battle Sound Effects Balance**: Battle sound effects (punches, dashes, projectiles) will be slightly ducked to 55% volume while theme music is playing, keeping the music prominent while retaining punchy combat feedback.
> - **Crossfade Transition**: When a different character activates a Stand Arrow while a theme is active, a snappy 0.5-second crossfade will smoothly transition between the themes without pops or sudden cutoffs.
> - **Audio Files in `app/src/main/res/raw/`**: The 9 character theme MP3 files (`jotaro_theme.mp3`, `dio_theme.mp3`, `giorno_theme.mp3`, `bruno_theme.mp3`, `polnareff_theme.mp3`, `kakyoin_theme.mp3`, `mista_theme.mp3`, `josuke_theme.mp3`, `gyro_theme.mp3`) will be housed in `res/raw`. Robust missing-file safety is guaranteed: if any file is missing, the game logs a warning and proceeds normally without crashing.

---

## 1. Overview & Core Concept

When any character in STAND-OFF touches and activates a Stand Arrow:
1. The 2.5-second dramatic freeze and pierce animation triggers.
2. At the exact start of this activation animation, that character's signature anime theme song begins playing.
3. The theme continues playing after the freeze ends, accompanying the newly awakened character into combat.
4. If another character subsequently activates a Stand Arrow, the current theme fades out over 0.5 seconds while the new character's theme fades in.
5. Only one character theme plays at any given time.
6. When the battle ends (KO victory or rematch) or the user exits to the character select / main menu, the theme fades out and resets cleanly.

---

## 2. User Experience & Visual Design

### Key User Flows

```
[Stand Arrow Collision]
          │
          ▼
[2.5s Arena Freeze & Pierce Animation]
    ├── ThemeMusicManager.playTheme(characterId)
    │      ├── Resolve R.raw.<character>_theme
    │      ├── 0.5s Crossfade (if another theme is playing)
    │      ├── Loop continuously (isLooping = true)
    │      └── Duck Battle SFX (SoundSynthesizer.sfxVolumeScale = 0.55f)
    └── Golden aura & pierce sparks
          │
          ▼
[Awakening Complete: HP + Rage + Buffs applied]
    ├── Arena unfreezes
    └── Theme music keeps playing in background during combat
          │
    ┌─────┴─────────────────────────────────┐
    ▼                                       ▼
[Battle Paused]                        [Battle Ends (KO)]
  Theme pauses                           Theme fades out & stops
  Unpause resumes from position          Normal SFX volume restored
```

### Character Theme Mapping
- **Jotaro** (`CharacterId.JOTARO`) $\rightarrow$ `R.raw.jotaro_theme`
- **Dio** (`CharacterId.DIO`) $\rightarrow$ `R.raw.dio_theme`
- **Giorno** (`CharacterId.GIORNO`) $\rightarrow$ `R.raw.giorno_theme`
- **Bruno** (`CharacterId.BRUNO`) $\rightarrow$ `R.raw.bruno_theme`
- **Polnareff** (`CharacterId.POLNAREFF`) $\rightarrow$ `R.raw.polnareff_theme`
- **Kakyoin** (`CharacterId.KAKYOIN`) $\rightarrow$ `R.raw.kakyoin_theme`
- **Mista** (`CharacterId.MISTA`) $\rightarrow$ `R.raw.mista_theme`
- **Josuke** (`CharacterId.JOSUKE`) $\rightarrow$ `R.raw.josuke_theme`
- **Gyro** (`CharacterId.GYRO`) $\rightarrow$ `R.raw.gyro_theme`

---

## 3. Key Product Decisions & Trade-Offs

- **Dedicated `ThemeMusicManager` vs. Mixing into `SoundSynthesizer`**:
  - *Decision*: Keep `SoundSynthesizer` for low-latency procedural synthesized combat SFX (`AudioTrack.MODE_STATIC`), and create `ThemeMusicManager` using Android's native `MediaPlayer` for compressed streaming MP3 playback.
  - *Why*: `AudioTrack` is designed for raw PCM synthesis of sub-second sound bursts; `MediaPlayer` is the standard Android engine for decoding MP3s with hardware acceleration, looping, volume scaling, and pause/resume.
- **Audio Ducking Strategy**:
  - *Decision*: Add a `sfxVolumeScale` multiplier in `SoundSynthesizer` that drops from `1.0f` to `0.55f` when theme music is active, restoring to `1.0f` when stopped.
  - *Why*: Prevents high-intensity sound effects (such as multi-fist barrages) from drowning out the musical motifs while ensuring strikes still feel impactful.
- **Fail-Safe Resource Resolution**:
  - *Decision*: Check if resource exists before calling `MediaPlayer.create()`, and wrap creation in `try-catch`.
  - *Why*: Guarantees zero game crashes if any resource file is missing or corrupt, as mandated by Google Play policy and user requirements.

---

## 4. Technical Architecture & Component Mapping

```
┌────────────────────────────────────────────────────────┐
│                      BattleScreen                      │
│  - Observes isPaused -> ThemeMusicManager.pause/resume │
│  - DisposableEffect -> ThemeMusicManager.stopAndReset  │
└──────────────────────────┬─────────────────────────────┘
                           │
             callbacks     ▼
┌────────────────────────────────────────────────────────┐
│                     BattleSimulator                    │
│  - activeArrowActivation starts                        │
│      -> triggers onPlayTheme(fighter.characterId)      │
│  - checkVictoryCondition()                             │
│      -> triggers onStopTheme()                         │
│  - restart()                                           │
│      -> triggers onStopTheme()                         │
└──────────────────────────┬─────────────────────────────┘
                           │
                           ▼
┌────────────────────────────────────────────────────────┐
│                   ThemeMusicManager                    │
│  - playTheme(context, characterId)                     │
│  - 0.5s snappy crossfade between old and new player    │
│  - pause() / resume()                                  │
│  - stopAndReset() / release()                          │
└────────────┬─────────────────────────────┬─────────────┘
             │ sets volume scale           │ controls MP3
             ▼                             ▼
┌─────────────────────────┐   ┌──────────────────────────┐
│    SoundSynthesizer     │   │   Android MediaPlayer    │
│  (sfxVolumeScale=0.55f) │   │ (app/src/main/res/raw/*) │
└─────────────────────────┘   └──────────────────────────┘
```

### Proposed Changes

1. **Audio Resources**:
   - Populate `app/src/main/res/raw/` with:
     - `jotaro_theme.mp3`
     - `dio_theme.mp3`
     - `giorno_theme.mp3`
     - `bruno_theme.mp3`
     - `polnareff_theme.mp3`
     - `kakyoin_theme.mp3`
     - `mista_theme.mp3`
     - `josuke_theme.mp3`
     - `gyro_theme.mp3`

2. **`com.example.audio.ThemeMusicManager` (New Singleton)**:
   - Manages active and fading `MediaPlayer` instances.
   - Coroutine-driven 500ms volume interpolation for crossfade.
   - Resource ID mapping for each `CharacterId`.
   - Comprehensive exception handling and null checks.

3. **`SoundSynthesizer.kt`**:
   - Add `@Volatile var sfxVolumeScale: Float = 1.0f`.
   - Apply `sfxVolumeScale` when rendering short audio buffers to duck SFX during theme playback.

4. **`BattleSimulator.kt`**:
   - Add event callbacks:
     - `var onPlayTheme: ((CharacterId) -> Unit)? = null`
     - `var onStopTheme: (() -> Unit)? = null`
   - Trigger `onPlayTheme` at the exact start of Stand Arrow activation (when `activeArrowActivation` is created).
   - Trigger `onStopTheme` when victory conditions are met in `checkVictoryCondition()` and in `restart()`.

5. **`BattleScreen.kt`**:
   - Connect `simulator.onPlayTheme` and `simulator.onStopTheme` to `ThemeMusicManager`.
   - Sync `isPaused` state with `ThemeMusicManager.pause()` and `ThemeMusicManager.resume()`.
   - Add `DisposableEffect` to cleanly stop and release `ThemeMusicManager` when exiting the battle screen.

---

## 5. Verification Plan

1. **Build & Resource Verification**:
   - Run `compile_applet` to verify compilation, resource packaging in `R.raw`, and Gradle configuration.
2. **Stand Arrow Activation Verification**:
   - Confirm theme starts at the exact beginning of the 2.5s freeze animation.
   - Confirm theme continues playing during normal combat after the freeze animation ends.
   - Confirm a character cannot trigger the theme twice in the same battle.
3. **Crossfade Verification**:
   - Verify that when a second character collects a Stand Arrow, the first theme fades out over 0.5s while the new theme takes over without audio clipping.
4. **Pause/Resume & Match End Verification**:
   - Verify pausing the game pauses the music, and unpausing resumes from the exact position.
   - Verify winning the match stops the music cleanly and resets audio ducking.
   - Verify restarting a match resets all theme states.
