package com.example

import com.example.model.*
import com.example.simulation.BattleSimulator
import org.junit.Assert.*
import org.junit.Test

class BattleSimulationTest {

    @Test
    fun testAllNineCharactersRegistered() {
        val chars = CharacterRegistry.characters
        assertEquals(9, chars.size)

        val expectedIds = listOf(
            CharacterId.JOTARO, CharacterId.MISTA, CharacterId.JOSUKE,
            CharacterId.DIO, CharacterId.POLNAREFF, CharacterId.KAKYOIN,
            CharacterId.GIORNO, CharacterId.BRUNO, CharacterId.GYRO
        )
        for (id in expectedIds) {
            assertTrue("Character $id should be registered", chars.containsKey(id))
            val def = chars[id]!!
            assertTrue("Speed should be positive", def.baseSpeed > 0f)
            assertTrue("Attack range should be positive", def.normalRange > 0f)
        }
    }

    @Test
    fun testTimeStopDurationsAreExactlyEightSeconds() {
        val jotaroDef = CharacterRegistry.get(CharacterId.JOTARO)
        val dioDef = CharacterRegistry.get(CharacterId.DIO)

        assertEquals("Jotaro Time Stop must be exactly 8 seconds", 8.0f, jotaroDef.rageDuration, 0.001f)
        assertEquals("DIO Time Stop must be exactly 8 seconds", 8.0f, dioDef.rageDuration, 0.001f)
    }

    @Test
    fun testFighterBouncingBounds() {
        val config = BattleConfig(
            isTwoVsTwo = false,
            blueTeam = listOf(CharacterId.JOTARO),
            redTeam = listOf(CharacterId.DIO)
        )
        val sim = BattleSimulator(config)
        sim.phase = BattlePhase.FIGHTING // Skip countdown for physics test

        // Simulate 200 frames (approx 3.3 seconds of active bouncing)
        for (i in 0 until 200) {
            sim.update(0.016f)
            for (f in sim.fighters) {
                val r = f.radius
                assertTrue("Fighter X should be >= radius: ${f.x} >= $r", f.x >= r - 0.1f)
                assertTrue("Fighter X should be <= 1000 - radius: ${f.x} <= ${1000f - r}", f.x <= 1000f - r + 0.1f)
                assertTrue("Fighter Y should be >= radius: ${f.y} >= $r", f.y >= r - 0.1f)
                assertTrue("Fighter Y should be <= 1000 - radius: ${f.y} <= ${1000f - r}", f.y <= 1000f - r + 0.1f)
            }
        }
    }

    @Test
    fun testTwoVsTwoInitializesFourFighters() {
        val config = BattleConfig(
            isTwoVsTwo = true,
            blueTeam = listOf(CharacterId.JOTARO, CharacterId.MISTA),
            redTeam = listOf(CharacterId.DIO, CharacterId.POLNAREFF)
        )
        val sim = BattleSimulator(config)
        assertEquals(4, sim.fighters.size)

        val blueFighters = sim.fighters.filter { it.team == Team.BLUE }
        val redFighters = sim.fighters.filter { it.team == Team.RED }

        assertEquals(2, blueFighters.size)
        assertEquals(2, redFighters.size)
    }

    @Test
    fun testPolnareffWeaknessDefenseMultiplier() {
        val polnareff = CharacterRegistry.get(CharacterId.POLNAREFF)
        assertTrue("Polnareff should have higher damage taken weakness", polnareff.defenseMultiplier > 1.0f)
    }

    @Test
    fun testJosukeDorararaDuration() {
        val josuke = CharacterRegistry.get(CharacterId.JOSUKE)
        assertEquals(10.0f, josuke.rageDuration, 0.001f)
    }

    @Test
    fun testRealTimeHpSystem() {
        val config = BattleConfig(
            isTwoVsTwo = false,
            blueTeam = listOf(CharacterId.JOTARO),
            redTeam = listOf(CharacterId.DIO)
        )
        val sim = BattleSimulator(config)
        val target = sim.fighters.first { it.team == Team.RED }

        assertEquals(200f, target.maxHp, 0.001f)
        assertEquals(200f, target.hp, 0.001f)

        // Damage target
        target.hp = (target.hp - 25f).coerceIn(0f, target.maxHp)
        assertEquals(175f, target.hp, 0.001f)

        // Clamping check: can never go below 0
        target.hp = (target.hp - 300f).coerceIn(0f, target.maxHp)
        assertEquals(0f, target.hp, 0.001f)
    }

    @Test
    fun testPunchBarrageFistTargetCount() {
        val config = BattleConfig(
            isTwoVsTwo = false,
            blueTeam = listOf(CharacterId.JOTARO),
            redTeam = listOf(CharacterId.DIO)
        )
        val sim = BattleSimulator(config)
        val jotaro = sim.fighters.first { it.team == Team.BLUE }
        jotaro.attackCooldownTimer = 0f

        sim.phase = BattlePhase.FIGHTING
        // Run updates to trigger barrage
        for (i in 0 until 50) {
            sim.update(0.016f)
            if (jotaro.isPerformingBarrage) break
        }
        assertTrue("Jotaro should target 20-25 punches during barrage", jotaro.barrageTargetFistCount in 20..25)
    }
}
