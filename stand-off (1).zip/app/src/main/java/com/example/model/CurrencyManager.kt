package com.example.model

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

object CurrencyManager {
    private const val PREFS_NAME = "stand_off_currency_prefs"
    private const val KEY_BALANCE = "stand_coins_balance"
    private const val KEY_RESOLVED_BATTLES = "resolved_battle_ids"
    private const val STARTING_BALANCE = 1000
    private const val BANKRUPTCY_BAILOUT = 100

    private var prefs: SharedPreferences? = null
    private val _coins = MutableStateFlow(STARTING_BALANCE)
    val coins: StateFlow<Int> = _coins.asStateFlow()

    private val resolvedBattleIds = mutableSetOf<Long>()

    fun init(context: Context) {
        if (prefs == null) {
            val appCtx = context.applicationContext
            prefs = appCtx.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            val current = prefs?.getInt(KEY_BALANCE, STARTING_BALANCE) ?: STARTING_BALANCE
            _coins.value = current.coerceAtLeast(0)

            val savedIds = prefs?.getStringSet(KEY_RESOLVED_BATTLES, emptySet()) ?: emptySet()
            resolvedBattleIds.addAll(savedIds.mapNotNull { it.toLongOrNull() })
        }
    }

    fun getBalance(): Int = _coins.value

    @Synchronized
    fun deductWager(amount: Int): Boolean {
        if (amount == 0) return true
        val current = _coins.value
        if (current < amount) return false
        val newBal = current - amount
        _coins.value = newBal
        prefs?.edit()?.putInt(KEY_BALANCE, newBal)?.apply()
        return true
    }

    @Synchronized
    fun awardPayout(battleInstanceId: Long, payout: Int): Boolean {
        if (resolvedBattleIds.contains(battleInstanceId)) {
            return false // Already resolved to prevent double reward
        }
        resolvedBattleIds.add(battleInstanceId)
        val newBal = _coins.value + payout
        _coins.value = newBal

        persistState()
        return true
    }

    @Synchronized
    fun recordLoss(battleInstanceId: Long): Boolean {
        if (resolvedBattleIds.contains(battleInstanceId)) {
            return false
        }
        resolvedBattleIds.add(battleInstanceId)
        // Check bankruptcy bailout
        var bailoutApplied = false
        if (_coins.value <= 0) {
            _coins.value = BANKRUPTCY_BAILOUT
            bailoutApplied = true
        }
        persistState()
        return bailoutApplied
    }

    @Synchronized
    fun checkAndApplyBailout(): Boolean {
        if (_coins.value <= 0) {
            _coins.value = BANKRUPTCY_BAILOUT
            persistState()
            return true
        }
        return false
    }

    fun isBattleResolved(battleInstanceId: Long): Boolean {
        return resolvedBattleIds.contains(battleInstanceId)
    }

    private fun persistState() {
        prefs?.edit()?.apply {
            putInt(KEY_BALANCE, _coins.value)
            // Limit saved resolved IDs to recent 50 to prevent unbounded growth
            val pruned = resolvedBattleIds.toList().takeLast(50).map { it.toString() }.toSet()
            putStringSet(KEY_RESOLVED_BATTLES, pruned)
            apply()
        }
    }
}
