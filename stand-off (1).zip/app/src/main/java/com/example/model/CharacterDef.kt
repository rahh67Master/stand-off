package com.example.model

import androidx.compose.ui.graphics.Color

enum class AttackType {
    PUNCH_BARRAGE,
    GUNSHOT,
    RAPID_FENCING,
    EMERALD_PROJECTILE,
    MELEE_COMBO,
    STEEL_BALL_SPIN
}

enum class RageType {
    TIME_STOP_JOTARO,
    SEX_PISTOLS_VOLLEY,
    DORARARA_OVERDRIVE,
    TIME_STOP_DIO,
    CHARIOT_FENCING_STORM,
    EMERALD_STRING_TRAP,
    LIFE_DEFENSE,
    ZIPPER_TELEPORT_COMBO,
    GOLDEN_SPIN_SPREAD
}

data class CharacterDef(
    val id: CharacterId,
    val baseSpeed: Float, // Speed target from spec
    val primaryColor: Color,
    val secondaryColor: Color,
    val accentColor: Color,
    val attackType: AttackType,
    val normalRange: Float, // distance to initiate
    val attackCooldown: Float, // seconds
    val defenseMultiplier: Float = 1.0f,
    val rageType: RageType,
    val rageDuration: Float, // in seconds (e.g. 8.0s for Jotaro & DIO, 10.0s for Josuke)
    val rageName: String,
    val rageDescription: String,
    val battleCry: String,
    val soundEffectWord: String
)

object CharacterRegistry {
    val characters: Map<CharacterId, CharacterDef> = mapOf(
        CharacterId.JOTARO to CharacterDef(
            id = CharacterId.JOTARO,
            baseSpeed = 255f,
            primaryColor = Color(0xFF1E293B), // Dark navy
            secondaryColor = Color(0xFF6366F1), // Star Platinum Indigo/Purple
            accentColor = Color(0xFFA855F7),
            attackType = AttackType.PUNCH_BARRAGE,
            normalRange = 180f,
            attackCooldown = 0.6f,
            rageType = RageType.TIME_STOP_JOTARO,
            rageDuration = 8.0f, // EXACTLY 8 SECONDS
            rageName = "STAR PLATINUM: THE WORLD",
            rageDescription = "Freezes time for 8 seconds. Enemies and projectiles are frozen while Jotaro moves rapidly to attack.",
            battleCry = "ORA ORA ORA ORA!",
            soundEffectWord = "ORA!"
        ),
        CharacterId.MISTA to CharacterDef(
            id = CharacterId.MISTA,
            baseSpeed = 210f,
            primaryColor = Color(0xFF0284C7), // Blue-orange helmet
            secondaryColor = Color(0xFFEA580C),
            accentColor = Color(0xFFFACC15),
            attackType = AttackType.GUNSHOT,
            normalRange = 450f,
            attackCooldown = 1.0f, // fires 1 bullet ~every 1 second
            rageType = RageType.SEX_PISTOLS_VOLLEY,
            rageDuration = 2.0f,
            rageName = "SEX PISTOLS PASS-PASS!",
            rageDescription = "Fires 6 enhanced homing bullets over 2 seconds with high speed ricochets.",
            battleCry = "PASS PASS PASS! YEE-HAW!",
            soundEffectWord = "BANG!"
        ),
        CharacterId.JOSUKE to CharacterDef(
            id = CharacterId.JOSUKE,
            baseSpeed = 260f,
            primaryColor = Color(0xFF4338CA), // Josuke navy & pink
            secondaryColor = Color(0xFFEC4899),
            accentColor = Color(0xFF06B6D4),
            attackType = AttackType.PUNCH_BARRAGE,
            normalRange = 175f,
            attackCooldown = 0.55f,
            rageType = RageType.DORARARA_OVERDRIVE,
            rageDuration = 10.0f, // EXACTLY 10 SECONDS
            rageName = "DORARARA OVERDRIVE",
            rageDescription = "10 seconds of massive barrage range (up to 380 units) and enhanced life restoration on every hit.",
            battleCry = "DORARARARARA!",
            soundEffectWord = "DORA!"
        ),
        CharacterId.DIO to CharacterDef(
            id = CharacterId.DIO,
            baseSpeed = 250f,
            primaryColor = Color(0xFFEAB308), // Golden Yellow
            secondaryColor = Color(0xFFCA8A04),
            accentColor = Color(0xFF10B981), // Emerald green heart motif
            attackType = AttackType.PUNCH_BARRAGE,
            normalRange = 185f,
            attackCooldown = 0.5f,
            rageType = RageType.TIME_STOP_DIO,
            rageDuration = 8.0f, // EXACTLY 8 SECONDS
            rageName = "THE WORLD: TIME STOP",
            rageDescription = "Stops time for 8 seconds. Enemies and physics freeze while DIO unleashes relentless golden strikes.",
            battleCry = "MUDA MUDA MUDA MUDA!",
            soundEffectWord = "MUDA!"
        ),
        CharacterId.POLNAREFF to CharacterDef(
            id = CharacterId.POLNAREFF,
            baseSpeed = 310f, // Fastest mover!
            primaryColor = Color(0xFFE2E8F0), // Silver
            secondaryColor = Color(0xFF94A3B8),
            accentColor = Color(0xFF38BDF8),
            attackType = AttackType.RAPID_FENCING,
            normalRange = 190f,
            attackCooldown = 0.45f,
            defenseMultiplier = 1.15f, // lower defense weakness
            rageType = RageType.CHARIOT_FENCING_STORM,
            rageDuration = 5.0f,
            rageName = "CHARIOT RAPID FENCING",
            rageDescription = "Removes armor for hyper-speed rapier thrusts with visible blade trails and high damage.",
            battleCry = "HORA HORA HORA HORA!",
            soundEffectWord = "SLASH!"
        ),
        CharacterId.KAKYOIN to CharacterDef(
            id = CharacterId.KAKYOIN,
            baseSpeed = 195f,
            primaryColor = Color(0xFF047857), // Deep emerald
            secondaryColor = Color(0xFF10B981),
            accentColor = Color(0xFFEF4444), // Cherry red accent
            attackType = AttackType.EMERALD_PROJECTILE,
            normalRange = 420f,
            attackCooldown = 1.1f,
            rageType = RageType.EMERALD_STRING_TRAP,
            rageDuration = 7.0f,
            rageName = "20-METER EMERALD SPLASH",
            rageDescription = "Deploys 8 glowing emerald tripwire strings. Crossing a string triggers 4 falling aerial emeralds.",
            battleCry = "EMERALDO SPLASHU!",
            soundEffectWord = "SPLASH!"
        ),
        CharacterId.GIORNO to CharacterDef(
            id = CharacterId.GIORNO,
            baseSpeed = 235f,
            primaryColor = Color(0xFFD97706), // Golden / Magenta suit
            secondaryColor = Color(0xFFC026D3),
            accentColor = Color(0xFFFBBF24),
            attackType = AttackType.PUNCH_BARRAGE,
            normalRange = 175f,
            attackCooldown = 0.6f,
            rageType = RageType.LIFE_DEFENSE,
            rageDuration = 2.0f,
            rageName = "GOLDEN LIFE DEFENSE",
            rageDescription = "Enters a 2-second life protection trance, reducing incoming damage by 50% with passive regeneration.",
            battleCry = "MUDA MUDA MUDA!",
            soundEffectWord = "GOLDEN!"
        ),
        CharacterId.BRUNO to CharacterDef(
            id = CharacterId.BRUNO,
            baseSpeed = 285f,
            primaryColor = Color(0xFFF8FAFC), // White suit with black laces
            secondaryColor = Color(0xFF1E3A8A), // Navy lace
            accentColor = Color(0xFFF59E0B), // Golden zippers
            attackType = AttackType.MELEE_COMBO,
            normalRange = 190f,
            attackCooldown = 0.5f,
            rageType = RageType.ZIPPER_TELEPORT_COMBO,
            rageDuration = 3.0f,
            rageName = "ZIPPER DIMENSION WARP",
            rageDescription = "Unzips space to instantly reposition behind the opponent, followed by a heavy 3-hit zipper strike.",
            battleCry = "ARI ARI ARI ARI... ARRIVEDERCI!",
            soundEffectWord = "ZIPPER!"
        ),
        CharacterId.GYRO to CharacterDef(
            id = CharacterId.GYRO,
            baseSpeed = 195f,
            primaryColor = Color(0xFF15803D), // Green hat & steel balls
            secondaryColor = Color(0xFF78350F), // Leather coat
            accentColor = Color(0xFF84CC16), // Bright neon spin green
            attackType = AttackType.STEEL_BALL_SPIN,
            normalRange = 440f,
            attackCooldown = 1.5f, // fires 1 spinning ball ~every 1.5s
            rageType = RageType.GOLDEN_SPIN_SPREAD,
            rageDuration = 3.5f,
            rageName = "GOLDEN RATIO ROTATION",
            rageDescription = "Launches 4 enhanced spinning steel balls in a wide curved arc with intense rotational shockwaves.",
            battleCry = "NYOHO! GO GO ZEPELLI!",
            soundEffectWord = "SPIN!"
        )
    )

    fun get(id: CharacterId): CharacterDef = characters[id] ?: characters.values.first()
}
