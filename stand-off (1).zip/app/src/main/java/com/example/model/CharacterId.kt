package com.example.model

enum class CharacterId(
    val displayName: String,
    val japaneseName: String,
    val standName: String,
    val title: String
) {
    JOTARO(
        displayName = "JOTARO",
        japaneseName = "空条 承太郎",
        standName = "Star Platinum",
        title = "Heavy Barrage Specialist"
    ),
    MISTA(
        displayName = "MISTA",
        japaneseName = "グイード・ミスタ",
        standName = "Sex Pistols",
        title = "Ranged Gunfighter"
    ),
    JOSUKE(
        displayName = "JOSUKE",
        japaneseName = "東方 仗助",
        standName = "Crazy Diamond",
        title = "Aggressive Melee / Sustain"
    ),
    DIO(
        displayName = "DIO",
        japaneseName = "ディオ・ブランドー",
        standName = "The World",
        title = "Aggressive Rushdown"
    ),
    POLNAREFF(
        displayName = "POLNAREFF",
        japaneseName = "J・P・ポルナレフ",
        standName = "Silver Chariot",
        title = "Fast Melee / Fencing"
    ),
    KAKYOIN(
        displayName = "KAKYOIN",
        japaneseName = "花京院 典明",
        standName = "Hierophant Green",
        title = "Mid-Range Zoning"
    ),
    GIORNO(
        displayName = "GIORNO",
        japaneseName = "ジョルノ・ジョバァーナ",
        standName = "Gold Experience",
        title = "Balanced Combatant"
    ),
    BRUNO(
        displayName = "BRUNO",
        japaneseName = "ブローノ・ブチャラティ",
        standName = "Sticky Fingers",
        title = "Mobile Zipper Melee"
    ),
    GYRO(
        displayName = "GYRO",
        japaneseName = "ジャイロ・ツェペリ",
        standName = "Ball Breaker / Spin",
        title = "Steel Ball Spin Sniper"
    )
}
