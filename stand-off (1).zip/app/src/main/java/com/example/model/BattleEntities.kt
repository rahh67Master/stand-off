package com.example.model

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color

enum class Team {
    BLUE, RED
}

enum class BattlePhase {
    COUNTDOWN,
    FIGHTING,
    DEATH_ANIMATION,
    VICTORY_DELAY,
    VICTORY_SCREEN
}

enum class FistStyle {
    STAR_PLATINUM_PURPLE,
    CRAZY_DIAMOND_PINK,
    THE_WORLD_GOLD,
    CHARIOT_RAPIER,
    STICKY_FINGERS_ZIPPER,
    GOLD_EXPERIENCE_YELLOW
}

enum class ProjectileType {
    BULLET,
    SEX_PISTOLS_BULLET,
    EMERALD,
    AERIAL_EMERALD,
    STEEL_BALL,
    GOLDEN_SPIN_BALL
}

class FighterState(
    val instanceId: String,
    val characterId: CharacterId,
    val team: Team,
    var x: Float,
    var y: Float,
    var vx: Float,
    var vy: Float,
    val radius: Float,
    initialHp: Float = 200f,
    val maxHp: Float = 200f
) {
    // Jetpack Compose Observable Real-Time HP and Rage State
    var hp: Float by mutableFloatStateOf(initialHp)
    var rage: Float by mutableFloatStateOf(0f)
    val maxRage: Float = 100f
    var isRageActive: Boolean by mutableStateOf(false)
    var isDefeated: Boolean by mutableStateOf(false)

    var rageTimeRemaining: Float = 0f
    var attackCooldownTimer: Float = 0f
    var collisionCooldownTimer: Float = 0f
    var hitStopTimer: Float = 0f
    var fadeAlpha: Float = 1f
    var comboCount: Int = 0
    var regenTimer: Float = 0f
    var rageSubTimer: Float = 0f
    var rageSubCount: Int = 0

    // Active multi-fist barrage tracking
    var isPerformingBarrage: Boolean = false
    var barrageDurationRemaining: Float = 0f
    var barrageTargetInstanceId: String? = null
    var barrageSpawnIntervalTimer: Float = 0f
    var barrageTotalFistsSpawned: Int = 0
    var barrageTargetFistCount: Int = 24
    var barrageIsOverdrive: Boolean = false

    // Death sequence physics and visual tumble
    var deathAnimationTime: Float = 0f
    var deathRotationDeg: Float = 0f
    var deathTumbleSpeed: Float = 0f

    // Mista Recoil and Muzzle Flash
    var recoilX: Float = 0f
    var recoilY: Float = 0f
    var muzzleFlashTimer: Float = 0f
    var muzzleFlashAngle: Float = 0f

    // Bruno Zipper Dash & Afterimage
    var isDashing: Boolean = false
    var afterimageX: Float = 0f
    var afterimageY: Float = 0f
    var afterimageAlpha: Float = 0f

    // Stand Arrow Collection & Buffs
    var hasCollectedStandArrow: Boolean = false
    var hasStandArrowBuff: Boolean = false
}

data class StandArrow(
    val id: Long,
    var x: Float,
    var y: Float,
    val radius: Float = 26f,
    var isCollected: Boolean = false,
    var rotation: Float = 0f,
    var pulseTime: Float = 0f
)

data class StandArrowActivation(
    val fighterInstanceId: String,
    var timeRemaining: Float = 2.5f,
    val totalDuration: Float = 2.5f,
    val arrowX: Float,
    val arrowY: Float
)

data class Projectile(
    val id: Long,
    val ownerId: String,
    val team: Team,
    var x: Float,
    var y: Float,
    var vx: Float,
    var vy: Float,
    val radius: Float,
    val type: ProjectileType,
    val damage: Float,
    var rotation: Float = 0f,
    var lifetime: Float = 0f,
    val maxLifetime: Float = 4.0f,
    val targetFighterId: String? = null,
    val bulletNumber: Int = 1
)

data class ZipperTrack(
    val id: Long,
    val startX: Float,
    val startY: Float,
    val endX: Float,
    val endY: Float,
    var openProgress: Float = 0f,
    var lifetime: Float = 0f,
    val maxLifetime: Float = 0.85f
)

data class TrapString(
    val id: Long,
    val ownerId: String,
    val team: Team,
    val x1: Float,
    val y1: Float,
    val x2: Float,
    val y2: Float,
    var triggered: Boolean = false,
    var lifetime: Float = 0f,
    val maxLifetime: Float = 7.0f,
    var tension: Float = 0f
)

data class FistVisual(
    val id: Long,
    val startX: Float,
    val startY: Float,
    val targetX: Float,
    val targetY: Float,
    var progress: Float, // 0.0 to 1.0 (forward strike stroke)
    val angleRad: Float,
    val style: FistStyle,
    val fistScale: Float = 1.0f,
    var hasStruck: Boolean = false,
    val lateralOffset: Float = 0f,
    val durationSeconds: Float = 0.18f,
    var alpha: Float = 1.0f
)

data class Particle(
    var x: Float,
    var y: Float,
    var vx: Float,
    var vy: Float,
    val color: Color,
    val size: Float,
    var alpha: Float = 1.0f,
    var life: Float = 0f,
    val maxLife: Float = 0.45f
)

data class DamagePopup(
    val id: Long,
    var x: Float,
    var y: Float,
    val text: String,
    val color: Color,
    var alpha: Float = 1.0f,
    var life: Float = 0f,
    val maxLife: Float = 0.7f,
    val isCrit: Boolean = false
)

data class MangaEffectWord(
    val id: Long,
    val x: Float,
    val y: Float,
    val word: String,
    val color: Color,
    val scale: Float = 1.2f,
    var life: Float = 0f,
    val maxLife: Float = 0.5f
)

enum class SoundType {
    BALL_BOUNCE,
    BALL_COLLISION,
    HEAVY_HIT,
    BARRAGE_CLASH,
    SWORD_SLASH,
    GUNSHOT,
    EMERALD_FIRE,
    SPIN_RELEASE,
    TIME_STOP_START,
    TIME_STOP_END,
    KO_BURST,
    RAGE_READY,
    COUNTDOWN_BEEP,
    FIGHT_BELL
}

data class BattleConfig(
    val isTwoVsTwo: Boolean = false,
    val blueTeam: List<CharacterId> = listOf(CharacterId.JOTARO),
    val redTeam: List<CharacterId> = listOf(CharacterId.DIO),
    val battleInstanceId: Long = System.currentTimeMillis(),
    val predictionConfig: PredictionConfig? = null
)

enum class PredictionTier(
    val multiplier: Float,
    val wager: Int,
    val profit: Int,
    val totalReturn: Int,
    val displayName: String
) {
    FREE(multiplier = 0f, wager = 0, profit = 25, totalReturn = 25, displayName = "FREE"),
    TIER_1_5X(multiplier = 1.5f, wager = 100, profit = 150, totalReturn = 250, displayName = "1.5×"),
    TIER_2X(multiplier = 2.0f, wager = 200, profit = 400, totalReturn = 600, displayName = "2×"),
    TIER_3X(multiplier = 3.0f, wager = 300, profit = 900, totalReturn = 1200, displayName = "3×")
}

data class PredictionConfig(
    val predictedTeam: Team,
    val tier: PredictionTier,
    val wagerAmount: Int = tier.wager,
    val potentialProfit: Int = tier.profit,
    val totalReturn: Int = tier.totalReturn
)

data class PredictionResult(
    val isWin: Boolean,
    val predictedTeam: Team,
    val winnerTeam: Team,
    val tier: PredictionTier,
    val wagerAmount: Int,
    val profitAmount: Int,
    val totalPayout: Int,
    val newBalance: Int
)
