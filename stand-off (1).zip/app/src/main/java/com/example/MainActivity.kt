package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import com.example.model.BattleConfig
import com.example.model.CharacterId
import com.example.model.CurrencyManager
import com.example.ui.screens.*
import com.example.ui.theme.MyApplicationTheme

enum class AppScreen {
    MAIN_MENU,
    CHARACTER_SELECT,
    RANDOM_BATTLE,
    PREDICTION_SELECT,
    BATTLE,
    HOW_TO_PLAY,
    SETTINGS
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        CurrencyManager.init(this)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme(darkTheme = true) {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = Color(0xFF030712)
                ) {
                    StandOffApp()
                }
            }
        }
    }

    override fun onPause() {
        super.onPause()
        com.example.audio.ThemeMusicManager.pause()
    }

    override fun onDestroy() {
        super.onDestroy()
        com.example.audio.ThemeMusicManager.release()
    }
}

@Composable
fun StandOffApp() {
    var currentScreen by remember { mutableStateOf(AppScreen.MAIN_MENU) }
    var selectScreenIs2v2 by remember { mutableStateOf(false) }
    var activeBattleConfig by remember {
        mutableStateOf(
            BattleConfig(
                isTwoVsTwo = false,
                blueTeam = listOf(CharacterId.JOTARO),
                redTeam = listOf(CharacterId.DIO)
            )
        )
    }

    when (currentScreen) {
        AppScreen.MAIN_MENU -> {
            MainMenuScreen(
                onSelect1v1 = {
                    selectScreenIs2v2 = false
                    currentScreen = AppScreen.CHARACTER_SELECT
                },
                onSelect2v2 = {
                    selectScreenIs2v2 = true
                    currentScreen = AppScreen.CHARACTER_SELECT
                },
                onSelectRandom = {
                    currentScreen = AppScreen.RANDOM_BATTLE
                },
                onSelectPrediction = {
                    currentScreen = AppScreen.PREDICTION_SELECT
                },
                onSettings = {
                    currentScreen = AppScreen.SETTINGS
                }
            )
        }
        AppScreen.CHARACTER_SELECT -> {
            CharacterSelectScreen(
                initialIs2v2 = selectScreenIs2v2,
                onStartBattle = { config ->
                    activeBattleConfig = config
                    currentScreen = AppScreen.BATTLE
                },
                onBack = {
                    currentScreen = AppScreen.MAIN_MENU
                }
            )
        }
        AppScreen.RANDOM_BATTLE -> {
            RandomBattleScreen(
                initialIs2v2 = selectScreenIs2v2,
                onStartBattle = { config ->
                    activeBattleConfig = config
                    currentScreen = AppScreen.BATTLE
                },
                onBack = {
                    currentScreen = AppScreen.MAIN_MENU
                }
            )
        }
        AppScreen.PREDICTION_SELECT -> {
            PredictionSelectScreen(
                onStartBattle = { config ->
                    activeBattleConfig = config
                    currentScreen = AppScreen.BATTLE
                },
                onBack = {
                    currentScreen = AppScreen.MAIN_MENU
                }
            )
        }
        AppScreen.BATTLE -> {
            BattleScreen(
                config = activeBattleConfig,
                onBackToSelect = {
                    if (activeBattleConfig.predictionConfig != null) {
                        currentScreen = AppScreen.PREDICTION_SELECT
                    } else {
                        currentScreen = AppScreen.CHARACTER_SELECT
                    }
                },
                onBackToMenu = {
                    currentScreen = AppScreen.MAIN_MENU
                },
                onNextPrediction = {
                    currentScreen = AppScreen.PREDICTION_SELECT
                }
            )
        }
        AppScreen.HOW_TO_PLAY -> {
            HowToPlayScreen(
                onBack = {
                    currentScreen = AppScreen.MAIN_MENU
                }
            )
        }
        AppScreen.SETTINGS -> {
            SettingsScreen(
                onBack = {
                    currentScreen = AppScreen.MAIN_MENU
                }
            )
        }
    }
}
