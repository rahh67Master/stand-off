package com.example.simulation

import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.ui.graphics.Color
import com.example.audio.SoundSynthesizer
import com.example.model.*
import java.util.concurrent.atomic.AtomicLong
import kotlin.math.*
import kotlin.random.Random

class BattleSimulator(
    val config: BattleConfig
) {
    companion object {
        const val ARENA_SIZE = 1000f
    }

    val frameTick = mutableLongStateOf(0L)

    val phaseState = mutableStateOf(BattlePhase.COUNTDOWN)
    var phase: BattlePhase
        get() = phaseState.value
        set(value) { phaseState.value = value }

    var countdownTimer: Float = 2.0f // 3.. 2.. 1.. FIGHT!
    var countdownDisplay: String = "3"
    var winnerTeam: Team? = null
    var winnerFighters: List<CharacterId> = emptyList()

    // Death animation and victory delay timers
    var deathAnimationTimeRemaining: Float = 0f
    var victoryDelayTimeRemaining: Float = 0f

    val fighters = mutableListOf<FighterState>()
    val projectiles = mutableListOf<Projectile>()
    val trapStrings = mutableListOf<TrapString>()
    val fistVisuals = mutableListOf<FistVisual>()
    val particles = mutableListOf<Particle>()
    val damagePopups = mutableListOf<DamagePopup>()
    val mangaWords = mutableListOf<MangaEffectWord>()
    val zipperTracks = mutableListOf<ZipperTrack>()

    // Stand Arrow and 20s Battle Event
    val standArrows = mutableListOf<StandArrow>()
    var activeArrowActivation: StandArrowActivation? = null
    var elapsedBattleTime: Float = 0f
    var nextArrowEventTime: Float = 20.0f

    var activeTimeStopOwner: FighterState? = null
    var timeStopRemaining: Float = 0f
    var timeStopTotalDuration: Float = 8.0f // 8 SECONDS
    var timeStopAnimationTimer: Float = 0f // Running clock for animated effects

    var screenShakeAmount: Float = 0f

    // Character theme music callbacks for Stand Arrow activations
    var onPlayTheme: ((CharacterId) -> Unit)? = null
    var onStopTheme: (() -> Unit)? = null

    private val idGen = AtomicLong(100)

    init {
        setupFighters()
    }

    private fun setupFighters() {
        fighters.clear()
        projectiles.clear()
        trapStrings.clear()
        fistVisuals.clear()
        particles.clear()
        damagePopups.clear()
        mangaWords.clear()
        zipperTracks.clear()
        standArrows.clear()
        activeArrowActivation = null
        elapsedBattleTime = 0f
        nextArrowEventTime = 20.0f

        val is2v2 = config.isTwoVsTwo
        val radius = if (is2v2) 58f else 68f

        if (!is2v2) {
            val blueId = config.blueTeam.firstOrNull() ?: CharacterId.JOTARO
            val blueDef = CharacterRegistry.get(blueId)
            val angle = Random.nextFloat() * 2f * PI.toFloat()
            fighters.add(
                FighterState(
                    instanceId = "blue_1",
                    characterId = blueId,
                    team = Team.BLUE,
                    x = 260f,
                    y = 500f,
                    vx = cos(angle) * blueDef.baseSpeed,
                    vy = sin(angle) * blueDef.baseSpeed,
                    radius = radius
                )
            )

            val redId = config.redTeam.firstOrNull() ?: CharacterId.DIO
            val redDef = CharacterRegistry.get(redId)
            val redAngle = Random.nextFloat() * 2f * PI.toFloat()
            fighters.add(
                FighterState(
                    instanceId = "red_1",
                    characterId = redId,
                    team = Team.RED,
                    x = 740f,
                    y = 500f,
                    vx = cos(redAngle) * redDef.baseSpeed,
                    vy = sin(redAngle) * redDef.baseSpeed,
                    radius = radius
                )
            )
        } else {
            val blue1Id = config.blueTeam.getOrElse(0) { CharacterId.JOTARO }
            val blue2Id = config.blueTeam.getOrElse(1) { CharacterId.MISTA }
            val red1Id = config.redTeam.getOrElse(0) { CharacterId.DIO }
            val red2Id = config.redTeam.getOrElse(1) { CharacterId.KAKYOIN }

            fighters.add(
                FighterState(
                    instanceId = "blue_1",
                    characterId = blue1Id,
                    team = Team.BLUE,
                    x = 240f,
                    y = 320f,
                    vx = cos(0.8f) * CharacterRegistry.get(blue1Id).baseSpeed,
                    vy = sin(0.8f) * CharacterRegistry.get(blue1Id).baseSpeed,
                    radius = radius
                )
            )
            fighters.add(
                FighterState(
                    instanceId = "blue_2",
                    characterId = blue2Id,
                    team = Team.BLUE,
                    x = 240f,
                    y = 680f,
                    vx = cos(-0.8f) * CharacterRegistry.get(blue2Id).baseSpeed,
                    vy = sin(-0.8f) * CharacterRegistry.get(blue2Id).baseSpeed,
                    radius = radius
                )
            )
            fighters.add(
                FighterState(
                    instanceId = "red_1",
                    characterId = red1Id,
                    team = Team.RED,
                    x = 760f,
                    y = 320f,
                    vx = cos(2.4f) * CharacterRegistry.get(red1Id).baseSpeed,
                    vy = sin(2.4f) * CharacterRegistry.get(red1Id).baseSpeed,
                    radius = radius
                )
            )
            fighters.add(
                FighterState(
                    instanceId = "red_2",
                    characterId = red2Id,
                    team = Team.RED,
                    x = 760f,
                    y = 680f,
                    vx = cos(-2.4f) * CharacterRegistry.get(red2Id).baseSpeed,
                    vy = sin(-2.4f) * CharacterRegistry.get(red2Id).baseSpeed,
                    radius = radius
                )
            )
        }
    }

    fun restart() {
        onStopTheme?.invoke()
        phase = BattlePhase.COUNTDOWN
        countdownTimer = 2.0f
        countdownDisplay = "3"
        winnerTeam = null
        winnerFighters = emptyList()
        activeTimeStopOwner = null
        timeStopRemaining = 0f
        timeStopAnimationTimer = 0f
        deathAnimationTimeRemaining = 0f
        victoryDelayTimeRemaining = 0f
        screenShakeAmount = 0f
        setupFighters()
    }

    fun update(deltaSeconds: Float) {
        val dt = deltaSeconds.coerceIn(0.001f, 0.05f)
        frameTick.value = System.nanoTime()

        // Screen shake decay
        if (screenShakeAmount > 0f) {
            screenShakeAmount = (screenShakeAmount - dt * 25f).coerceAtLeast(0f)
        }

        // Handle countdown phase (balls start moving immediately)
        if (phase == BattlePhase.COUNTDOWN) {
            val prevTimer = countdownTimer
            countdownTimer -= dt
            if (prevTimer >= 1.5f && countdownTimer < 1.5f) {
                countdownDisplay = "2"
                SoundSynthesizer.play(SoundType.COUNTDOWN_BEEP)
            } else if (prevTimer >= 1.0f && countdownTimer < 1.0f) {
                countdownDisplay = "1"
                SoundSynthesizer.play(SoundType.COUNTDOWN_BEEP)
            } else if (prevTimer >= 0.5f && countdownTimer < 0.5f) {
                countdownDisplay = "FIGHT!"
                SoundSynthesizer.play(SoundType.FIGHT_BELL)
            }

            if (countdownTimer <= 0f) {
                phase = BattlePhase.FIGHTING
            }
        }

        // Handle Death Animation Phase (2.5s)
        if (phase == BattlePhase.DEATH_ANIMATION) {
            deathAnimationTimeRemaining -= dt
            // Update defeated fighters tumbling physics
            for (fighter in fighters) {
                if (fighter.isDefeated) {
                    fighter.deathAnimationTime += dt
                    fighter.deathRotationDeg += fighter.deathTumbleSpeed * dt
                    fighter.deathTumbleSpeed *= (1f - dt * 1.5f)
                    // Knockback momentum with friction
                    fighter.x = (fighter.x + fighter.vx * dt).coerceIn(fighter.radius, ARENA_SIZE - fighter.radius)
                    fighter.y = (fighter.y + fighter.vy * dt).coerceIn(fighter.radius, ARENA_SIZE - fighter.radius)
                    fighter.vx *= (1f - dt * 3.5f)
                    fighter.vy *= (1f - dt * 3.5f)
                    if (Random.nextFloat() < 0.25f) {
                        spawnParticles(fighter.x, fighter.y, Color(0xFF64748B), 2)
                    }
                } else {
                    // Winner keeps moving and bouncing in the arena!
                    updateWinnerMovement(fighter, dt)
                }
            }
            updateVisualEffects(dt)
            updateFistVisuals(dt)
            if (deathAnimationTimeRemaining <= 0f) {
                phase = BattlePhase.VICTORY_DELAY
            }
            return
        }

        // Handle Victory Delay Phase (2.0s)
        if (phase == BattlePhase.VICTORY_DELAY) {
            victoryDelayTimeRemaining -= dt
            for (fighter in fighters) {
                if (!fighter.isDefeated) {
                    updateWinnerMovement(fighter, dt)
                }
            }
            updateVisualEffects(dt)
            if (victoryDelayTimeRemaining <= 0f) {
                phase = BattlePhase.VICTORY_SCREEN
                SoundSynthesizer.play(SoundType.FIGHT_BELL)
            }
            return
        }

        if (phase == BattlePhase.VICTORY_SCREEN) {
            // Battle finished, winner continues gentle idle bounce
            for (fighter in fighters) {
                if (!fighter.isDefeated) {
                    updateWinnerMovement(fighter, dt)
                }
            }
            updateVisualEffects(dt)
            return
        }

        // Handle Stand Arrow Piercing & Awakening Sequence (2.5s Arena Freeze)
        val activation = activeArrowActivation
        if (activation != null) {
            activation.timeRemaining -= dt
            val activatingFighter = fighters.find { it.instanceId == activation.fighterInstanceId }
            if (activatingFighter != null) {
                // Golden electrical aura particles converging on the piercing fighter
                if (Random.nextFloat() < 0.65f) {
                    val angle = Random.nextFloat() * 2f * PI.toFloat()
                    val dist = activatingFighter.radius * (1.1f + Random.nextFloat() * 0.9f)
                    particles.add(
                        Particle(
                            x = activatingFighter.x + cos(angle) * dist,
                            y = activatingFighter.y + sin(angle) * dist,
                            vx = -cos(angle) * 75f,
                            vy = -sin(angle) * 75f,
                            color = if (Random.nextBoolean()) Color(0xFFFDE047) else Color(0xFFF59E0B),
                            size = Random.nextFloat() * 6f + 3f,
                            maxLife = 0.35f
                        )
                    )
                }
            }
            updateVisualEffects(dt)

            if (activation.timeRemaining <= 0f) {
                if (activatingFighter != null && !activatingFighter.isDefeated) {
                    activatingFighter.hp = activatingFighter.maxHp
                    activatingFighter.rage = activatingFighter.maxRage
                    activatingFighter.hasStandArrowBuff = true
                    activatingFighter.hasCollectedStandArrow = true
                    SoundSynthesizer.play(SoundType.RAGE_READY)
                    spawnMangaWord(activatingFighter.x, activatingFighter.y - 50f, "STAND AWAKENED!", Color(0xFFFBBF24))
                    spawnParticles(activatingFighter.x, activatingFighter.y, Color(0xFFFDE047), 24)
                    spawnParticles(activatingFighter.x, activatingFighter.y, Color.White, 16)
                    screenShakeAmount = 6f
                }
                activeArrowActivation = null
            }
            return
        }

        // Active Battle Timer & 20-Second Event: Global Heal + Stand Arrow Spawn
        if (phase == BattlePhase.FIGHTING) {
            elapsedBattleTime += dt

            while (elapsedBattleTime >= nextArrowEventTime) {
                // A. Global Heal (30% Max HP for living fighters)
                for (fighter in fighters) {
                    if (!fighter.isDefeated) {
                        val healAmount = fighter.maxHp * 0.30f
                        fighter.hp = (fighter.hp + healAmount).coerceAtMost(fighter.maxHp)
                        spawnParticles(fighter.x, fighter.y, Color(0xFF10B981), 12)
                        spawnMangaWord(fighter.x, fighter.y - 35f, "HEAL +30%!", Color(0xFF10B981))
                    }
                }
                SoundSynthesizer.play(SoundType.RAGE_READY)

                // B. Stand Arrow Spawn inside arena boundaries
                val margin = 140f
                val spawnX = Random.nextFloat() * (ARENA_SIZE - margin * 2f) + margin
                val spawnY = Random.nextFloat() * (ARENA_SIZE - margin * 2f) + margin
                standArrows.add(
                    StandArrow(
                        id = idGen.incrementAndGet(),
                        x = spawnX,
                        y = spawnY,
                        rotation = Random.nextFloat() * 360f
                    )
                )
                spawnMangaWord(spawnX, spawnY - 35f, "STAND ARROW!", Color(0xFFFBBF24))
                SoundSynthesizer.play(SoundType.COUNTDOWN_BEEP)

                nextArrowEventTime += 20.0f
            }

            // Pulse arrows
            for (arrow in standArrows) {
                arrow.pulseTime += dt
            }

            // Check Stand Arrow collection by living fighters
            for (fighter in fighters) {
                if (!fighter.isDefeated && !fighter.hasCollectedStandArrow && activeArrowActivation == null) {
                    val arrowIt = standArrows.iterator()
                    while (arrowIt.hasNext()) {
                        val arrow = arrowIt.next()
                        if (!arrow.isCollected) {
                            val dist = hypot(fighter.x - arrow.x, fighter.y - arrow.y)
                            if (dist <= fighter.radius + arrow.radius) {
                                arrow.isCollected = true
                                arrowIt.remove()
                                SoundSynthesizer.play(SoundType.TIME_STOP_START)
                                activeArrowActivation = StandArrowActivation(
                                    fighterInstanceId = fighter.instanceId,
                                    timeRemaining = 2.5f,
                                    totalDuration = 2.5f,
                                    arrowX = arrow.x,
                                    arrowY = arrow.y
                                )
                                onPlayTheme?.invoke(fighter.characterId)
                                spawnMangaWord(fighter.x, fighter.y - 50f, "PIERCE!", Color(0xFFFBBF24))
                                break
                            }
                        }
                    }
                }
            }
        }

        // Handle active Time Stop (3 seconds)
        val isTimeStopActive = activeTimeStopOwner != null && timeStopRemaining > 0f
        if (isTimeStopActive) {
            timeStopRemaining -= dt
            timeStopAnimationTimer += dt
            if (timeStopRemaining <= 0f) {
                activeTimeStopOwner?.isRageActive = false
                activeTimeStopOwner?.rage = 0f
                activeTimeStopOwner = null
                SoundSynthesizer.play(SoundType.TIME_STOP_END)
                spawnMangaWord(500f, 500f, "TIME RESUMES!", Color.White)
            }
        }

        // Update Fighters
        for (fighter in fighters) {
            if (fighter.isDefeated) continue

            // If time stop is active and this fighter is NOT the time stopper, freeze completely!
            val isFrozen = isTimeStopActive && fighter != activeTimeStopOwner
            if (isFrozen) {
                // Enemies cannot gain Rage while frozen!
                continue
            }

            val def = CharacterRegistry.get(fighter.characterId)

            // Hit stop recovery
            if (fighter.hitStopTimer > 0f) {
                fighter.hitStopTimer -= dt
                continue
            }

            // Giorno passive regeneration
            if (fighter.characterId == CharacterId.GIORNO) {
                fighter.regenTimer += dt
                if (fighter.regenTimer >= 1.5f) {
                    fighter.regenTimer = 0f
                    if (fighter.hp < fighter.maxHp) {
                        fighter.hp = (fighter.hp + 2f).coerceAtMost(fighter.maxHp)
                        spawnParticles(fighter.x, fighter.y, Color(0xFFFACC15), 3)
                    }
                }
            }

            // RAGE METER RULES:
            // If Rage is active: Rage gain = 0, meter locked at 0%!
            if (fighter.isRageActive) {
                fighter.rage = 0f
                fighter.rageTimeRemaining -= dt
                if (fighter.rageTimeRemaining <= 0f) {
                    fighter.isRageActive = false
                    fighter.rage = 0f // Ready to start filling again
                }
            } else {
                // Normal combat: passive rage gain over time
                fighter.rage = (fighter.rage + dt * 3.8f).coerceAtMost(fighter.maxRage)
            }

            // Cooldown timers
            if (fighter.attackCooldownTimer > 0f) fighter.attackCooldownTimer -= dt
            if (fighter.collisionCooldownTimer > 0f) fighter.collisionCooldownTimer -= dt

            // Recoil and muzzle flash decay
            if (fighter.muzzleFlashTimer > 0f) {
                fighter.muzzleFlashTimer = (fighter.muzzleFlashTimer - dt).coerceAtLeast(0f)
            }
            fighter.recoilX *= 0.82f
            fighter.recoilY *= 0.82f

            // Update active multi-fist barrage for this fighter
            if (fighter.isPerformingBarrage) {
                updateFighterBarrage(fighter, dt)
            }

            // Find current active enemy targets
            val activeEnemies = fighters.filter { it.team != fighter.team && !it.isDefeated }
            if (activeEnemies.isEmpty()) continue

            // Closest enemy target
            val target = activeEnemies.minByOrNull {
                val dx = it.x - fighter.x
                val dy = it.y - fighter.y
                dx * dx + dy * dy
            } ?: activeEnemies.first()

            val distToTarget = hypot(target.x - fighter.x, target.y - fighter.y)

            // AI Decision & Movement Steering
            updateFighterMovement(fighter, def, target, distToTarget, dt, isTimeStopActive)

            // AI Combat & Attack Triggers (only if not already mid-barrage)
            if (!fighter.isPerformingBarrage) {
                updateFighterCombat(fighter, def, target, distToTarget, dt)
            }
        }

        // Ball-to-ball solid physical collisions (ONLY if not time stop frozen)
        if (!isTimeStopActive) {
            handleFighterCollisions()
        }

        // Update Projectiles
        updateProjectiles(dt, isTimeStopActive)

        // Update Traps
        updateTraps(dt, isTimeStopActive)

        // Update Visual Fists & Rapiers
        updateFistVisuals(dt)

        // Update Particles & Popups
        updateVisualEffects(dt)

        // Check Victory Condition
        checkVictoryCondition()
    }

    private fun updateWinnerMovement(fighter: FighterState, dt: Float) {
        val def = CharacterRegistry.get(fighter.characterId)
        val speed = def.baseSpeed * 0.75f
        fighter.x += fighter.vx * dt
        fighter.y += fighter.vy * dt

        val r = fighter.radius
        if (fighter.x - r < 0f) { fighter.x = r; fighter.vx = abs(fighter.vx) }
        else if (fighter.x + r > ARENA_SIZE) { fighter.x = ARENA_SIZE - r; fighter.vx = -abs(fighter.vx) }

        if (fighter.y - r < 0f) { fighter.y = r; fighter.vy = abs(fighter.vy) }
        else if (fighter.y + r > ARENA_SIZE) { fighter.y = ARENA_SIZE - r; fighter.vy = -abs(fighter.vy) }
    }

    private fun updateFighterMovement(
        fighter: FighterState,
        def: CharacterDef,
        target: FighterState,
        distToTarget: Float,
        dt: Float,
        isTimeStopActive: Boolean
    ) {
        val polnareffBonus = if (fighter.characterId == CharacterId.POLNAREFF) {
            ((elapsedBattleTime / 5f).toInt() * 0.05f).coerceAtMost(0.50f)
        } else 0f
        val arrowSpeedMult = if (fighter.hasStandArrowBuff) 1.25f else 1.0f

        val baseSpd = if (fighter.isRageActive && (def.rageType == RageType.TIME_STOP_JOTARO || def.rageType == RageType.TIME_STOP_DIO)) {
            def.baseSpeed * 1.6f
        } else if (fighter.characterId == CharacterId.POLNAREFF && fighter.isRageActive) {
            def.baseSpeed * 1.35f
        } else {
            def.baseSpeed
        }
        val targetSpeed = baseSpd * (1f + polnareffBonus) * arrowSpeedMult

        var vx = fighter.vx
        var vy = fighter.vy

        if (abs(vx) < 10f && abs(vy) < 10f) {
            val randAngle = Random.nextFloat() * 2f * PI.toFloat()
            vx = cos(randAngle) * targetSpeed
            vy = sin(randAngle) * targetSpeed
        }

        when (fighter.characterId) {
            CharacterId.MISTA, CharacterId.KAKYOIN, CharacterId.GYRO -> {
                if (distToTarget < 260f) {
                    val escapeX = fighter.x - target.x
                    val escapeY = fighter.y - target.y
                    val len = hypot(escapeX, escapeY)
                    if (len > 0.001f) {
                        vx += (escapeX / len) * 70f * dt
                        vy += (escapeY / len) * 70f * dt
                    }
                }
            }
            CharacterId.JOTARO, CharacterId.DIO, CharacterId.JOSUKE -> {
                if (distToTarget > 110f) {
                    val chaseX = target.x - fighter.x
                    val chaseY = target.y - fighter.y
                    val len = hypot(chaseX, chaseY)
                    if (len > 0.001f) {
                        val steerWeight = if (isTimeStopActive) 300f else 75f
                        vx += (chaseX / len) * steerWeight * dt
                        vy += (chaseY / len) * steerWeight * dt
                    }
                }
            }
            CharacterId.BRUNO -> {
                if (Random.nextFloat() < 0.02f) {
                    val randAngle = Random.nextFloat() * 2f * PI.toFloat()
                    vx = cos(randAngle) * targetSpeed
                    vy = sin(randAngle) * targetSpeed
                }
            }
            CharacterId.POLNAREFF -> {
                if (distToTarget < 140f && Random.nextFloat() < 0.05f) {
                    val perpX = -(target.y - fighter.y)
                    val perpY = (target.x - fighter.x)
                    val len = hypot(perpX, perpY)
                    if (len > 0.001f) {
                        vx = (perpX / len) * targetSpeed
                        vy = (perpY / len) * targetSpeed
                    }
                }
            }
            CharacterId.GIORNO -> {}
        }

        val currentSpeed = hypot(vx, vy)
        if (currentSpeed > 0.001f) {
            val speedFactor = targetSpeed / currentSpeed
            vx *= speedFactor
            vy *= speedFactor
        }

        fighter.x += vx * dt
        fighter.y += vy * dt
        fighter.vx = vx
        fighter.vy = vy

        // Wall physics: DVD screensaver bounce
        val r = fighter.radius
        var bounced = false

        if (fighter.x - r < 0f) {
            fighter.x = r
            fighter.vx = abs(fighter.vx)
            bounced = true
        } else if (fighter.x + r > ARENA_SIZE) {
            fighter.x = ARENA_SIZE - r
            fighter.vx = -abs(fighter.vx)
            bounced = true
        }

        if (fighter.y - r < 0f) {
            fighter.y = r
            fighter.vy = abs(fighter.vy)
            bounced = true
        } else if (fighter.y + r > ARENA_SIZE) {
            fighter.y = ARENA_SIZE - r
            fighter.vy = -abs(fighter.vy)
            bounced = true
        }

        if (bounced) {
            spawnParticles(fighter.x, fighter.y, def.secondaryColor, 3)
            SoundSynthesizer.play(SoundType.BALL_BOUNCE)
        }
    }

    private fun handleFighterCollisions() {
        val count = fighters.size
        for (i in 0 until count) {
            val f1 = fighters[i]
            if (f1.isDefeated) continue

            for (j in i + 1 until count) {
                val f2 = fighters[j]
                if (f2.isDefeated) continue

                val dx = f2.x - f1.x
                val dy = f2.y - f1.y
                val dist = hypot(dx, dy)
                val minDist = f1.radius + f2.radius

                if (dist < minDist && dist > 0.001f) {
                    val nx = dx / dist
                    val ny = dy / dist
                    val overlap = minDist - dist

                    // Positional separation: push apart immediately so they never overlap
                    val sep = overlap * 0.5f + 0.5f
                    f1.x -= nx * sep
                    f1.y -= ny * sep
                    f2.x += nx * sep
                    f2.y += ny * sep

                    f1.x = f1.x.coerceIn(f1.radius, ARENA_SIZE - f1.radius)
                    f1.y = f1.y.coerceIn(f1.radius, ARENA_SIZE - f1.radius)
                    f2.x = f2.x.coerceIn(f2.radius, ARENA_SIZE - f2.radius)
                    f2.y = f2.y.coerceIn(f2.radius, ARENA_SIZE - f2.radius)

                    // Elastic impulse
                    val kx = (f1.vx - f2.vx)
                    val ky = (f1.vy - f2.vy)
                    val p = 2f * (nx * kx + ny * ky) / 2f

                    f1.vx -= p * nx
                    f1.vy -= p * ny
                    f2.vx += p * nx
                    f2.vy += p * ny

                    // Strong mutual physical knockback
                    val knockbackImpulse = 180f
                    f1.vx -= nx * knockbackImpulse
                    f1.vy -= ny * knockbackImpulse
                    f2.vx += nx * knockbackImpulse
                    f2.vy += ny * knockbackImpulse

                    if (f1.collisionCooldownTimer <= 0f && f2.collisionCooldownTimer <= 0f) {
                        f1.collisionCooldownTimer = 0.25f
                        f2.collisionCooldownTimer = 0.25f

                        if (f1.team != f2.team) {
                            applyDamage(f1, 5f, false)
                            applyDamage(f2, 5f, false)
                            SoundSynthesizer.play(SoundType.BALL_COLLISION)
                            screenShakeAmount = 8f
                            spawnMangaWord((f1.x + f2.x) / 2f, (f1.y + f2.y) / 2f, "BAM!", Color.White)
                        } else {
                            SoundSynthesizer.play(SoundType.BALL_COLLISION)
                        }

                        val midX = (f1.x + f2.x) / 2f
                        val midY = (f1.y + f2.y) / 2f
                        spawnParticles(midX, midY, Color.White, 6)
                        spawnParticles(midX, midY, Color(0xFFFBBF24), 5)
                    }
                }
            }
        }
    }

    private fun updateFighterCombat(
        fighter: FighterState,
        def: CharacterDef,
        target: FighterState,
        distToTarget: Float,
        dt: Float
    ) {
        // AI Rage Activation Check
        if (fighter.rage >= fighter.maxRage && !fighter.isRageActive) {
            val shouldActivateRage = when (def.rageType) {
                RageType.TIME_STOP_JOTARO, RageType.TIME_STOP_DIO -> distToTarget < 450f
                RageType.DORARARA_OVERDRIVE -> distToTarget < 400f
                RageType.SEX_PISTOLS_VOLLEY, RageType.GOLDEN_SPIN_SPREAD -> true
                RageType.CHARIOT_FENCING_STORM -> distToTarget < 350f
                RageType.EMERALD_STRING_TRAP -> true
                RageType.LIFE_DEFENSE -> fighter.hp < 130f || distToTarget < 250f
                RageType.ZIPPER_TELEPORT_COMBO -> distToTarget > 200f
            }

            if (shouldActivateRage) {
                activateRage(fighter, def, target)
            }
        }

        // Active Rage updates
        if (fighter.isRageActive) {
            when (def.rageType) {
                RageType.SEX_PISTOLS_VOLLEY -> {
                    fighter.rageSubTimer -= dt
                    if (fighter.rageSubTimer <= 0f && fighter.rageSubCount < 6) {
                        fighter.rageSubTimer = 0.33f // Exactly 6 shots over ~2.0s
                        fighter.rageSubCount++
                        fireMistaBullet(fighter, target, isEnhanced = true, shotIndex = fighter.rageSubCount)
                        screenShakeAmount = 3.5f
                    }
                }
                RageType.CHARIOT_FENCING_STORM -> {
                    if (distToTarget <= 260f && fighter.attackCooldownTimer <= 0f) {
                        startBarrage(fighter, target, isOverdrive = true)
                        fighter.attackCooldownTimer = 1.3f
                    }
                }
                RageType.DORARARA_OVERDRIVE -> {
                    if (distToTarget <= 380f && fighter.attackCooldownTimer <= 0f) {
                        startBarrage(fighter, target, isOverdrive = true)
                        fighter.attackCooldownTimer = 1.4f
                    }
                }
                else -> {}
            }
        }

        // Normal attacks when in range
        val attackRange = if (fighter.isRageActive && def.rageType == RageType.DORARARA_OVERDRIVE) 380f else def.normalRange

        if (distToTarget <= attackRange && fighter.attackCooldownTimer <= 0f) {
            when (fighter.characterId) {
                CharacterId.JOTARO -> {
                    startBarrage(fighter, target, isOverdrive = false)
                    fighter.attackCooldownTimer = 1.4f
                }
                CharacterId.MISTA -> {
                    fireMistaBullet(fighter, target, isEnhanced = false, shotIndex = 1)
                    fighter.attackCooldownTimer = 1.0f // Approximately once per second
                }
                CharacterId.JOSUKE -> {
                    startBarrage(fighter, target, isOverdrive = false)
                    fighter.attackCooldownTimer = 1.4f
                }
                CharacterId.DIO -> {
                    startBarrage(fighter, target, isOverdrive = false)
                    fighter.attackCooldownTimer = 1.4f
                }
                CharacterId.POLNAREFF -> {
                    startBarrage(fighter, target, isOverdrive = false)
                    fighter.attackCooldownTimer = 1.2f
                }
                CharacterId.KAKYOIN -> {
                    fireKakyoinEmerald(fighter, target)
                    fighter.attackCooldownTimer = 1.1f
                }
                CharacterId.GIORNO -> {
                    startBarrage(fighter, target, isOverdrive = false)
                    fighter.attackCooldownTimer = 1.35f
                }
                CharacterId.BRUNO -> {
                    performBrunoCombo(fighter, target)
                    fighter.attackCooldownTimer = 0.42f
                }
                CharacterId.GYRO -> {
                    fireGyroSteelBall(fighter, target, isEnhanced = false)
                    fighter.attackCooldownTimer = 1.5f
                }
            }
        }
    }

    private fun activateRage(fighter: FighterState, def: CharacterDef, target: FighterState) {
        fighter.isRageActive = true
        fighter.rage = 0f // Locked to 0% during Rage
        fighter.rageTimeRemaining = def.rageDuration
        fighter.rageSubTimer = 0f
        fighter.rageSubCount = 0

        SoundSynthesizer.play(SoundType.RAGE_READY)
        spawnMangaWord(fighter.x, fighter.y - 60f, def.battleCry, def.accentColor)

        when (def.rageType) {
            RageType.TIME_STOP_JOTARO -> {
                activeTimeStopOwner = fighter
                timeStopRemaining = 8.0f // EXACTLY 8 SECONDS
                timeStopTotalDuration = 8.0f
                timeStopAnimationTimer = 0f
                SoundSynthesizer.play(SoundType.TIME_STOP_START)
                screenShakeAmount = 14f
                spawnMangaWord(fighter.x, fighter.y - 70f, "STAR PLATINUM: ZA WARUDO!", Color(0xFFA855F7))
            }
            RageType.TIME_STOP_DIO -> {
                activeTimeStopOwner = fighter
                timeStopRemaining = 8.0f // EXACTLY 8 SECONDS
                timeStopTotalDuration = 8.0f
                timeStopAnimationTimer = 0f
                SoundSynthesizer.play(SoundType.TIME_STOP_START)
                screenShakeAmount = 14f
                spawnMangaWord(fighter.x, fighter.y - 70f, "ZA WARUDO! TOMARE TOKI YO!", Color(0xFFFACC15))
            }
            RageType.DORARARA_OVERDRIVE -> {
                SoundSynthesizer.play(SoundType.HEAVY_HIT)
                spawnMangaWord(fighter.x, fighter.y - 70f, "DORARARA OVERDRIVE!", Color(0xFFEC4899))
                screenShakeAmount = 10f
                startBarrage(fighter, target, isOverdrive = true)
            }
            RageType.SEX_PISTOLS_VOLLEY -> {
                SoundSynthesizer.play(SoundType.GUNSHOT)
                screenShakeAmount = 8f
            }
            RageType.CHARIOT_FENCING_STORM -> {
                SoundSynthesizer.play(SoundType.SWORD_SLASH)
                screenShakeAmount = 9f
                spawnMangaWord(fighter.x, fighter.y - 70f, "ARMOR OFF! RAPID FENCING!", Color(0xFF38BDF8))
                startBarrage(fighter, target, isOverdrive = true)
            }
            RageType.EMERALD_STRING_TRAP -> {
                deployKakyoinStrings(fighter)
                SoundSynthesizer.play(SoundType.EMERALD_FIRE)
                spawnMangaWord(fighter.x, fighter.y - 70f, "20-METER RADIUS SPLASH!", Color(0xFF10B981))
            }
            RageType.LIFE_DEFENSE -> {
                SoundSynthesizer.play(SoundType.HEAVY_HIT)
                spawnMangaWord(fighter.x, fighter.y - 70f, "GOLDEN LIFE SHIELD!", Color(0xFFFBBF24))
            }
            RageType.ZIPPER_TELEPORT_COMBO -> {
                performBrunoTeleport(fighter, target)
            }
            RageType.GOLDEN_SPIN_SPREAD -> {
                fireGyroSpread(fighter, target)
            }
        }
    }

    // ==========================================
    // MULTI-FIST BARRAGE SYSTEM (15-25 VISIBLE FISTS)
    // ==========================================

    private fun startBarrage(fighter: FighterState, target: FighterState, isOverdrive: Boolean) {
        fighter.isPerformingBarrage = true
        fighter.barrageDurationRemaining = when (fighter.characterId) {
            CharacterId.JOTARO -> 1.5f
            CharacterId.JOSUKE -> 1.5f
            CharacterId.DIO -> 1.5f
            CharacterId.POLNAREFF -> 1.35f
            CharacterId.GIORNO -> 1.45f
            else -> 1.4f
        }
        fighter.barrageTargetInstanceId = target.instanceId
        fighter.barrageSpawnIntervalTimer = 0f
        fighter.barrageTotalFistsSpawned = 0
        fighter.barrageTargetFistCount = when (fighter.characterId) {
            CharacterId.JOTARO -> 24 // 20-25 visible fists
            CharacterId.JOSUKE -> 19 // 16-20 visible fists (slightly less powerful)
            CharacterId.DIO -> 22 // 20-22 visible fists
            CharacterId.POLNAREFF -> 20 // 18-20 visible rapier thrusts
            CharacterId.GIORNO -> 22 // Gold Experience rapid punch flurry
            else -> 18
        }
        fighter.barrageIsOverdrive = isOverdrive
        SoundSynthesizer.play(SoundType.BARRAGE_CLASH)
    }

    private fun updateFighterBarrage(fighter: FighterState, dt: Float) {
        fighter.barrageDurationRemaining -= dt
        val target = fighters.find { it.instanceId == fighter.barrageTargetInstanceId && !it.isDefeated }

        if (target == null || fighter.barrageDurationRemaining <= 0f || fighter.barrageTotalFistsSpawned >= fighter.barrageTargetFistCount) {
            fighter.isPerformingBarrage = false
            return
        }

        fighter.barrageSpawnIntervalTimer -= dt
        if (fighter.barrageSpawnIntervalTimer <= 0f) {
            // Rapid flurry spawn interval (~40ms spacing so multiple fists exist simultaneously)
            fighter.barrageSpawnIntervalTimer = 0.042f
            fighter.barrageTotalFistsSpawned++

            spawnSingleBarrageFist(fighter, target, fighter.barrageIsOverdrive)
        }
    }

    private fun spawnSingleBarrageFist(fighter: FighterState, target: FighterState, isOverdrive: Boolean) {
        val baseAngle = atan2(target.y - fighter.y, target.x - fighter.x)
        // Angular jitter creates natural manga fan of rapid punching
        val angleJitter = (Random.nextFloat() - 0.5f) * 0.55f
        val punchAngle = baseAngle + angleJitter

        // Lateral spread perpendicular to attack line
        val perpAngle = punchAngle + (PI / 2).toFloat()
        val lateralOffset = (Random.nextFloat() - 0.5f) * 70f

        // Fists emerge from distinct positions in front of fighter
        val startDist = fighter.radius * (0.6f + Random.nextFloat() * 0.45f)
        val startX = fighter.x + cos(punchAngle) * startDist + cos(perpAngle) * lateralOffset
        val startY = fighter.y + sin(punchAngle) * startDist + sin(perpAngle) * lateralOffset

        // Target impact points distributed across target ball volume
        val targetSpread = (Random.nextFloat() - 0.5f) * target.radius * 1.3f
        val targetDepth = (Random.nextFloat() - 0.5f) * target.radius * 0.4f
        val targetX = target.x + cos(perpAngle) * targetSpread + cos(punchAngle) * targetDepth
        val targetY = target.y + sin(perpAngle) * targetSpread + sin(punchAngle) * targetDepth

        val style = when (fighter.characterId) {
            CharacterId.JOTARO -> FistStyle.STAR_PLATINUM_PURPLE
            CharacterId.JOSUKE -> FistStyle.CRAZY_DIAMOND_PINK
            CharacterId.DIO -> FistStyle.THE_WORLD_GOLD
            CharacterId.POLNAREFF -> FistStyle.CHARIOT_RAPIER
            CharacterId.BRUNO -> FistStyle.STICKY_FINGERS_ZIPPER
            CharacterId.GIORNO -> FistStyle.GOLD_EXPERIENCE_YELLOW
            else -> FistStyle.STAR_PLATINUM_PURPLE
        }

        // Varied sizes (0.95x - 1.55x) for depth and rapid perspective
        val scale = when (fighter.characterId) {
            CharacterId.JOTARO -> Random.nextFloat() * 0.5f + 1.05f
            CharacterId.JOSUKE -> Random.nextFloat() * 0.4f + 0.95f
            CharacterId.DIO -> Random.nextFloat() * 0.45f + 1.05f
            CharacterId.POLNAREFF -> Random.nextFloat() * 0.35f + 0.95f
            CharacterId.GIORNO -> Random.nextFloat() * 0.4f + 1.0f
            else -> Random.nextFloat() * 0.35f + 1.0f
        }

        fistVisuals.add(
            FistVisual(
                id = idGen.incrementAndGet(),
                startX = startX,
                startY = startY,
                targetX = targetX,
                targetY = targetY,
                progress = 0f,
                angleRad = punchAngle,
                style = style,
                fistScale = scale,
                lateralOffset = lateralOffset,
                durationSeconds = 0.18f,
                alpha = 1.0f
            )
        )

        // Moderate damage per fist (18-25 fists total = ~30-45 total damage)
        val dmgPerFist = when (fighter.characterId) {
            CharacterId.JOTARO -> if (isOverdrive) 2.2f else 1.7f
            CharacterId.JOSUKE -> if (isOverdrive) 1.8f else 1.35f // Slightly less powerful than Jotaro
            CharacterId.DIO -> if (isOverdrive) 2.1f else 1.65f
            CharacterId.POLNAREFF -> 1.5f
            CharacterId.GIORNO -> if (isOverdrive) 2.1f else 1.6f
            else -> 1.4f
        }

        applyDamage(target, dmgPerFist, isCrit = false, dealer = fighter)
        target.hitStopTimer = 0.015f

        // Push impulse on target from continuous punching
        val pushDirX = cos(punchAngle)
        val pushDirY = sin(punchAngle)
        target.vx += pushDirX * 12f
        target.vy += pushDirY * 12f

        // Josuke small healing on hit
        if (fighter.characterId == CharacterId.JOSUKE) {
            val heal = if (isOverdrive) 1.5f else 0.85f
            fighter.hp = (fighter.hp + heal).coerceAtMost(fighter.maxHp)
            if (fighter.barrageTotalFistsSpawned % 3 == 0) {
                spawnParticles(fighter.x, fighter.y, Color(0xFF06B6D4), 2)
            }
        }

        // Screen shake and battle cries during strongest hits
        if (fighter.barrageTotalFistsSpawned % 5 == 0) {
            screenShakeAmount = 4f
            SoundSynthesizer.play(SoundType.BARRAGE_CLASH)
            val cry = when (fighter.characterId) {
                CharacterId.JOTARO -> "ORA!"
                CharacterId.JOSUKE -> "DORA!"
                CharacterId.DIO -> "MUDA!"
                CharacterId.POLNAREFF -> "SLASH!"
                CharacterId.GIORNO -> "MUDA!"
                else -> "HIT!"
            }
            val wordColor = when (fighter.characterId) {
                CharacterId.JOTARO -> Color(0xFFA855F7)
                CharacterId.JOSUKE -> Color(0xFFEC4899)
                CharacterId.DIO -> Color(0xFFFACC15)
                CharacterId.POLNAREFF -> Color(0xFF38BDF8)
                CharacterId.GIORNO -> Color(0xFFFBBF24)
                else -> Color.White
            }
            spawnMangaWord(target.x, target.y - 40f, cry, wordColor)
        }

        // Tiny impact debris particles and impact marks
        spawnParticles(targetX, targetY, Color.White, 3)
        spawnParticles(targetX, targetY, Color(0xFFFBBF24), 2)
    }

    private fun performGiornoCombo(fighter: FighterState, target: FighterState) {
        fighter.comboCount++
        val baseAngle = atan2(target.y - fighter.y, target.x - fighter.x)
        SoundSynthesizer.play(SoundType.HEAVY_HIT)

        val startX = fighter.x + cos(baseAngle) * (fighter.radius * 0.8f)
        val startY = fighter.y + sin(baseAngle) * (fighter.radius * 0.8f)

        fistVisuals.add(
            FistVisual(
                id = idGen.incrementAndGet(),
                startX = startX,
                startY = startY,
                targetX = target.x,
                targetY = target.y,
                progress = 0f,
                angleRad = baseAngle,
                style = FistStyle.THE_WORLD_GOLD,
                fistScale = 0.95f
            )
        )

        val isFinisher = fighter.comboCount % 5 == 0
        val dmg = if (isFinisher) 6.5f else 3.2f
        applyDamage(target, dmg, isCrit = isFinisher)
        target.hitStopTimer = 0.03f

        if (isFinisher) {
            spawnMangaWord(target.x, target.y - 40f, "GOLDEN FINISH!", Color(0xFFFBBF24))
            fighter.hp = (fighter.hp + 3f).coerceAtMost(fighter.maxHp)
        }
    }

    private fun performBrunoCombo(fighter: FighterState, target: FighterState) {
        fighter.comboCount++
        val baseAngle = atan2(target.y - fighter.y, target.x - fighter.x)
        SoundSynthesizer.play(SoundType.HEAVY_HIT)

        val startX = fighter.x + cos(baseAngle) * (fighter.radius * 0.8f)
        val startY = fighter.y + sin(baseAngle) * (fighter.radius * 0.8f)

        fistVisuals.add(
            FistVisual(
                id = idGen.incrementAndGet(),
                startX = startX,
                startY = startY,
                targetX = target.x,
                targetY = target.y,
                progress = 0f,
                angleRad = baseAngle,
                style = FistStyle.STICKY_FINGERS_ZIPPER,
                fistScale = 1.05f
            )
        )

        val isFinisher = fighter.comboCount % 4 == 0
        val dmg = 20.0f
        applyDamage(target, dmg, isCrit = isFinisher, dealer = fighter)
        target.hitStopTimer = 0.04f

        if (isFinisher) {
            spawnMangaWord(target.x, target.y - 40f, "ARRIVEDERCI!", Color(0xFFF59E0B))
            zipperTracks.add(
                ZipperTrack(
                    id = idGen.incrementAndGet(),
                    startX = target.x - 35f,
                    startY = target.y - 10f,
                    endX = target.x + 35f,
                    endY = target.y + 10f
                )
            )
        }
    }

    private fun performBrunoTeleport(fighter: FighterState, target: FighterState) {
        SoundSynthesizer.play(SoundType.SWORD_SLASH)
        spawnParticles(fighter.x, fighter.y, Color(0xFFF59E0B), 8)
        spawnMangaWord(fighter.x, fighter.y, "ZIPPER OPEN!", Color(0xFFF59E0B))

        val origX = fighter.x
        val origY = fighter.y

        val behindAngle = atan2(-target.vy, -target.vx)
        val teleportDist = target.radius + fighter.radius + 20f
        fighter.x = (target.x + cos(behindAngle) * teleportDist).coerceIn(fighter.radius, ARENA_SIZE - fighter.radius)
        fighter.y = (target.y + sin(behindAngle) * teleportDist).coerceIn(fighter.radius, ARENA_SIZE - fighter.radius)

        zipperTracks.add(
            ZipperTrack(
                id = idGen.incrementAndGet(),
                startX = origX,
                startY = origY,
                endX = fighter.x,
                endY = fighter.y
            )
        )

        val newAngle = atan2(target.y - fighter.y, target.x - fighter.x)
        val spd = CharacterRegistry.get(fighter.characterId).baseSpeed
        fighter.vx = cos(newAngle) * spd
        fighter.vy = sin(newAngle) * spd

        spawnParticles(fighter.x, fighter.y, Color(0xFFF59E0B), 8)
        spawnMangaWord(fighter.x, fighter.y, "ZIPPER CLOSE!", Color(0xFFF59E0B))

        performBrunoCombo(fighter, target)
    }

    private fun fireMistaBullet(fighter: FighterState, target: FighterState, isEnhanced: Boolean, shotIndex: Int = 1) {
        SoundSynthesizer.play(SoundType.GUNSHOT)
        val baseAngle = atan2(target.y - fighter.y, target.x - fighter.x)

        // Gun recoil animation
        val recoilForce = if (isEnhanced) 90f else 60f
        fighter.recoilX = -cos(baseAngle) * 14f
        fighter.recoilY = -sin(baseAngle) * 14f
        fighter.vx -= cos(baseAngle) * recoilForce
        fighter.vy -= sin(baseAngle) * recoilForce

        // Muzzle flash effect
        fighter.muzzleFlashTimer = 0.12f
        fighter.muzzleFlashAngle = baseAngle

        // Sex Pistols numbers: 1, 2, 3, 5, 6, 7 (no 4)
        val pistolNumber = when (shotIndex) {
            1 -> 1
            2 -> 2
            3 -> 3
            4 -> 5
            5 -> 6
            else -> 7
        }

        // Slight spread trajectory for volley
        val spreadAngle = if (isEnhanced) {
            baseAngle + ((shotIndex - 3.5f) * 0.08f) + (Random.nextFloat() - 0.5f) * 0.04f
        } else {
            baseAngle + (Random.nextFloat() - 0.5f) * 0.04f
        }

        val speed = if (isEnhanced) 720f else 540f
        val bulletRadius = if (isEnhanced) 8.5f else 7f
        val dmg = if (isEnhanced) 18f else 13f

        val spawnX = fighter.x + cos(spreadAngle) * (fighter.radius + 10f)
        val spawnY = fighter.y + sin(spreadAngle) * (fighter.radius + 10f)

        projectiles.add(
            Projectile(
                id = idGen.incrementAndGet(),
                ownerId = fighter.instanceId,
                team = fighter.team,
                x = spawnX,
                y = spawnY,
                vx = cos(spreadAngle) * speed,
                vy = sin(spreadAngle) * speed,
                radius = bulletRadius,
                type = if (isEnhanced) ProjectileType.SEX_PISTOLS_BULLET else ProjectileType.BULLET,
                damage = dmg,
                targetFighterId = if (isEnhanced) target.instanceId else null,
                bulletNumber = pistolNumber
            )
        )

        // Visible muzzle flash sparks and gun smoke puff
        spawnParticles(spawnX, spawnY, Color(0xFFFBBF24), 6)
        spawnParticles(spawnX, spawnY, Color.White, 4)

        if (isEnhanced) {
            spawnMangaWord(spawnX, spawnY - 20f, "#$pistolNumber PASS!", Color(0xFFF97316))
        }
    }

    private fun fireKakyoinEmerald(fighter: FighterState, target: FighterState) {
        SoundSynthesizer.play(SoundType.EMERALD_FIRE)
        val baseAngle = atan2(target.y - fighter.y, target.x - fighter.x)
        val speed = 500f

        // 3-emerald burst spread
        val angles = listOf(baseAngle - 0.09f, baseAngle, baseAngle + 0.09f)
        for (angle in angles) {
            val spawnX = fighter.x + cos(angle) * (fighter.radius + 10f)
            val spawnY = fighter.y + sin(angle) * (fighter.radius + 10f)

            projectiles.add(
                Projectile(
                    id = idGen.incrementAndGet(),
                    ownerId = fighter.instanceId,
                    team = fighter.team,
                    x = spawnX,
                    y = spawnY,
                    vx = cos(angle) * speed,
                    vy = sin(angle) * speed,
                    radius = 9.5f,
                    type = ProjectileType.EMERALD,
                    damage = 8f
                )
            )
        }

        spawnParticles(fighter.x, fighter.y, Color(0xFF10B981), 6)
        spawnParticles(fighter.x, fighter.y, Color(0xFF6EE7B7), 4)
    }

    private fun deployKakyoinStrings(fighter: FighterState) {
        trapStrings.clear()
        for (i in 0 until 8) {
            val x1 = Random.nextFloat() * (ARENA_SIZE - 200f) + 100f
            val y1 = Random.nextFloat() * (ARENA_SIZE - 200f) + 100f
            val angle = Random.nextFloat() * PI.toFloat()
            val length = Random.nextFloat() * 250f + 180f
            val x2 = (x1 + cos(angle) * length).coerceIn(50f, ARENA_SIZE - 50f)
            val y2 = (y1 + sin(angle) * length).coerceIn(50f, ARENA_SIZE - 50f)

            trapStrings.add(
                TrapString(
                    id = idGen.incrementAndGet(),
                    ownerId = fighter.instanceId,
                    team = fighter.team,
                    x1 = x1,
                    y1 = y1,
                    x2 = x2,
                    y2 = y2
                )
            )
        }
    }

    private fun triggerKakyoinTrap(trap: TrapString, target: FighterState) {
        trap.triggered = true
        SoundSynthesizer.play(SoundType.EMERALD_FIRE)
        screenShakeAmount = 8f
        spawnMangaWord(target.x, target.y - 50f, "TRAP TRIGGERED!", Color(0xFF10B981))

        for (k in 0 until 4) {
            val spawnX = target.x + (k - 1.5f) * 50f + (Random.nextFloat() - 0.5f) * 20f
            val spawnY = 20f + k * 15f

            projectiles.add(
                Projectile(
                    id = idGen.incrementAndGet(),
                    ownerId = trap.ownerId,
                    team = trap.team,
                    x = spawnX.coerceIn(50f, ARENA_SIZE - 50f),
                    y = spawnY,
                    vx = (target.x - spawnX) * 0.8f,
                    vy = 540f,
                    radius = 10f,
                    type = ProjectileType.AERIAL_EMERALD,
                    damage = 10f,
                    targetFighterId = target.instanceId
                )
            )
        }
    }

    private fun fireGyroSteelBall(fighter: FighterState, target: FighterState, isEnhanced: Boolean) {
        SoundSynthesizer.play(SoundType.SPIN_RELEASE)
        val angle = atan2(target.y - fighter.y, target.x - fighter.x)
        val speed = 460f

        projectiles.add(
            Projectile(
                id = idGen.incrementAndGet(),
                ownerId = fighter.instanceId,
                team = fighter.team,
                x = fighter.x + cos(angle) * (fighter.radius + 12f),
                y = fighter.y + sin(angle) * (fighter.radius + 12f),
                vx = cos(angle) * speed,
                vy = sin(angle) * speed,
                radius = 13f,
                type = if (isEnhanced) ProjectileType.GOLDEN_SPIN_BALL else ProjectileType.STEEL_BALL,
                damage = if (isEnhanced) 18f else 14f
            )
        )

        spawnParticles(fighter.x, fighter.y, Color(0xFF84CC16), 5)
    }

    private fun fireGyroSpread(fighter: FighterState, target: FighterState) {
        SoundSynthesizer.play(SoundType.SPIN_RELEASE)
        screenShakeAmount = 9f
        spawnMangaWord(fighter.x, fighter.y - 70f, "GOLDEN RATIO SPREAD!", Color(0xFF84CC16))

        val baseAngle = atan2(target.y - fighter.y, target.x - fighter.x)
        val spreadAngles = listOf(-0.35f, -0.12f, 0.12f, 0.35f)

        for (offset in spreadAngles) {
            val angle = baseAngle + offset
            val speed = 500f
            projectiles.add(
                Projectile(
                    id = idGen.incrementAndGet(),
                    ownerId = fighter.instanceId,
                    team = fighter.team,
                    x = fighter.x + cos(angle) * (fighter.radius + 12f),
                    y = fighter.y + sin(angle) * (fighter.radius + 12f),
                    vx = cos(angle) * speed,
                    vy = sin(angle) * speed,
                    radius = 14f,
                    type = ProjectileType.GOLDEN_SPIN_BALL,
                    damage = 16f
                )
            )
        }
    }

    // ==========================================
    // PROJECTILE & TRAP UPDATES
    // ==========================================

    private fun updateProjectiles(dt: Float, isTimeStopActive: Boolean) {
        val projIter = projectiles.iterator()
        while (projIter.hasNext()) {
            val proj = projIter.next()

            if (isTimeStopActive) {
                // Subtle particle quiver around frozen projectiles
                continue
            }

            proj.lifetime += dt
            if (proj.lifetime >= proj.maxLifetime) {
                projIter.remove()
                continue
            }

            if (proj.targetFighterId != null) {
                val target = fighters.find { it.instanceId == proj.targetFighterId && !it.isDefeated }
                if (target != null) {
                    val angleToTarget = atan2(target.y - proj.y, target.x - proj.x)
                    val currentSpeed = hypot(proj.vx, proj.vy)
                    val currentAngle = atan2(proj.vy, proj.vx)
                    var angleDiff = angleToTarget - currentAngle
                    while (angleDiff > PI) angleDiff -= (2 * PI).toFloat()
                    while (angleDiff < -PI) angleDiff += (2 * PI).toFloat()
                    val turnRate = 5.0f * dt
                    val newAngle = currentAngle + angleDiff.coerceIn(-turnRate, turnRate)
                    proj.vx = cos(newAngle) * currentSpeed
                    proj.vy = sin(newAngle) * currentSpeed
                }
            }

            proj.rotation += dt * 720f
            proj.x += proj.vx * dt
            proj.y += proj.vy * dt

            if (proj.x - proj.radius < 0f || proj.x + proj.radius > ARENA_SIZE ||
                proj.y - proj.radius < 0f || proj.y + proj.radius > ARENA_SIZE
            ) {
                if (proj.type == ProjectileType.SEX_PISTOLS_BULLET || proj.type == ProjectileType.STEEL_BALL) {
                    if (proj.x - proj.radius < 0f) { proj.x = proj.radius; proj.vx = abs(proj.vx) }
                    if (proj.x + proj.radius > ARENA_SIZE) { proj.x = ARENA_SIZE - proj.radius; proj.vx = -abs(proj.vx) }
                    if (proj.y - proj.radius < 0f) { proj.y = proj.radius; proj.vy = abs(proj.vy) }
                    if (proj.y + proj.radius > ARENA_SIZE) { proj.y = ARENA_SIZE - proj.radius; proj.vy = -abs(proj.vy) }
                    SoundSynthesizer.play(SoundType.BALL_BOUNCE)
                } else {
                    spawnParticles(proj.x, proj.y, Color(0xFFFBBF24), 4)
                    projIter.remove()
                    continue
                }
            }

            var hit = false
            for (fighter in fighters) {
                if (fighter.isDefeated || fighter.team == proj.team) continue

                val dist = hypot(fighter.x - proj.x, fighter.y - proj.y)
                if (dist < fighter.radius + proj.radius) {
                    applyDamage(fighter, proj.damage, isCrit = proj.type == ProjectileType.SEX_PISTOLS_BULLET || proj.type == ProjectileType.GOLDEN_SPIN_BALL)
                    SoundSynthesizer.play(SoundType.HEAVY_HIT)
                    spawnParticles(proj.x, proj.y, Color.White, 6)

                    val pAngle = atan2(proj.vy, proj.vx)
                    fighter.vx += cos(pAngle) * 60f
                    fighter.vy += sin(pAngle) * 60f

                    hit = true
                    break
                }
            }

            if (hit) {
                projIter.remove()
            }
        }
    }

    private fun updateTraps(dt: Float, isTimeStopActive: Boolean) {
        if (isTimeStopActive) return

        val trapIter = trapStrings.iterator()
        while (trapIter.hasNext()) {
            val trap = trapIter.next()
            trap.lifetime += dt
            if (trap.lifetime >= trap.maxLifetime || trap.triggered) {
                trapIter.remove()
                continue
            }

            for (fighter in fighters) {
                if (fighter.isDefeated || fighter.team == trap.team) continue

                val distToLine = distancePointToSegment(fighter.x, fighter.y, trap.x1, trap.y1, trap.x2, trap.y2)
                if (distToLine < fighter.radius) {
                    triggerKakyoinTrap(trap, fighter)
                    break
                }
            }
        }
    }

    private fun distancePointToSegment(px: Float, py: Float, x1: Float, y1: Float, x2: Float, y2: Float): Float {
        val dx = x2 - x1
        val dy = y2 - y1
        val lenSq = dx * dx + dy * dy
        if (lenSq < 0.0001f) return hypot(px - x1, py - y1)
        val t = (((px - x1) * dx + (py - y1) * dy) / lenSq).coerceIn(0f, 1f)
        val projX = x1 + t * dx
        val projY = y1 + t * dy
        return hypot(px - projX, py - projY)
    }

    private fun updateFistVisuals(dt: Float) {
        val fistIter = fistVisuals.iterator()
        while (fistIter.hasNext()) {
            val fist = fistIter.next()
            fist.progress += dt / fist.durationSeconds
            fist.alpha = when {
                fist.progress < 0.2f -> fist.progress / 0.2f
                fist.progress > 0.8f -> ((1f - fist.progress) / 0.2f).coerceIn(0f, 1f)
                else -> 1f
            }
            if (!fist.hasStruck && fist.progress >= 0.7f) {
                fist.hasStruck = true
                spawnParticles(fist.targetX, fist.targetY, Color.White, 3)
            }
            if (fist.progress >= 1f) {
                fistIter.remove()
            }
        }
    }

    private fun updateVisualEffects(dt: Float) {
        val pIter = particles.iterator()
        while (pIter.hasNext()) {
            val p = pIter.next()
            p.life += dt
            if (p.life >= p.maxLife) {
                pIter.remove()
                continue
            }
            p.x += p.vx * dt
            p.y += p.vy * dt
            p.alpha = 1f - (p.life / p.maxLife)
        }

        val dIter = damagePopups.iterator()
        while (dIter.hasNext()) {
            val d = dIter.next()
            d.life += dt
            if (d.life >= d.maxLife) {
                dIter.remove()
                continue
            }
            d.y -= dt * 45f
            d.alpha = 1f - (d.life / d.maxLife)
        }

        val mIter = mangaWords.iterator()
        while (mIter.hasNext()) {
            val m = mIter.next()
            m.life += dt
            if (m.life >= m.maxLife) {
                mIter.remove()
            }
        }

        val zIter = zipperTracks.iterator()
        while (zIter.hasNext()) {
            val z = zIter.next()
            z.lifetime += dt
            z.openProgress = (z.lifetime / z.maxLifetime).coerceIn(0f, 1f)
            if (z.lifetime >= z.maxLifetime) {
                zIter.remove()
            }
        }
    }

    // ==========================================
    // REAL-TIME DAMAGE, DEATH ANIMATION & VICTORY SEQUENCE
    // ==========================================

    private fun applyDamage(target: FighterState, rawDamage: Float, isCrit: Boolean, dealer: FighterState? = null) {
        if (target.isDefeated) return

        val targetDef = CharacterRegistry.get(target.characterId)
        var actualDmg = rawDamage * targetDef.defenseMultiplier

        if (dealer?.hasStandArrowBuff == true) {
            actualDmg *= 1.20f // 20% Stand Arrow damage buff
        }

        if (target.characterId == CharacterId.GIORNO && target.isRageActive) {
            actualDmg *= 0.5f
        }

        target.hp = (target.hp - actualDmg).coerceIn(0f, target.maxHp)

        // RAGE METER RULE:
        // Do NOT gain rage if Rage ability is active or if frozen in Time Stop!
        if (!target.isRageActive && activeTimeStopOwner == null) {
            target.rage = (target.rage + actualDmg * 1.0f).coerceIn(0f, target.maxRage)
        }

        // Spawn floating damage popup
        val text = if (isCrit) "${actualDmg.toInt()}!" else "${actualDmg.toInt()}"
        val color = if (isCrit) Color(0xFFEF4444) else Color(0xFFFBBF24)
        damagePopups.add(
            DamagePopup(
                id = idGen.incrementAndGet(),
                x = target.x + (Random.nextFloat() - 0.5f) * 20f,
                y = target.y - target.radius - 12f,
                text = text,
                color = color,
                isCrit = isCrit
            )
        )

        // Check if HP reached 0 -> Start Death Sequence
        if (target.hp <= 0f && !target.isDefeated) {
            target.isDefeated = true
            target.hp = 0f
            target.rage = 0f
            target.isPerformingBarrage = false
            target.isRageActive = false
            target.deathTumbleSpeed = 480f // spins as it is knocked back
            target.vx = (if (target.vx >= 0) -1 else 1) * 120f
            target.vy = -140f

            SoundSynthesizer.play(SoundType.KO_BURST)
            screenShakeAmount = 18f
            spawnParticles(target.x, target.y, Color(0xFFEF4444), 16)
            spawnParticles(target.x, target.y, Color.White, 12)
            spawnMangaWord(target.x, target.y - 50f, "RETIRED / KO!", Color(0xFFEF4444))
        }
    }

    private fun checkVictoryCondition() {
        if (phase == BattlePhase.DEATH_ANIMATION || phase == BattlePhase.VICTORY_DELAY || phase == BattlePhase.VICTORY_SCREEN) return

        val blueAlive = fighters.filter { it.team == Team.BLUE && !it.isDefeated }
        val redAlive = fighters.filter { it.team == Team.RED && !it.isDefeated }

        // Trigger Death Animation sequence when one team is completely defeated
        if (blueAlive.isEmpty() || redAlive.isEmpty()) {
            onStopTheme?.invoke()
            for (f in fighters) {
                f.isPerformingBarrage = false
                f.isRageActive = false
            }
            projectiles.clear()
            trapStrings.clear()
            activeTimeStopOwner = null
            activeArrowActivation = null

            phase = BattlePhase.DEATH_ANIMATION
            deathAnimationTimeRemaining = 2.5f // 2.5s death sequence
            victoryDelayTimeRemaining = 1.0f   // then 1.0s pause before victory screen

            if (blueAlive.isEmpty() && redAlive.isNotEmpty()) {
                winnerTeam = Team.RED
                winnerFighters = redAlive.map { it.characterId }
            } else if (redAlive.isEmpty() && blueAlive.isNotEmpty()) {
                winnerTeam = Team.BLUE
                winnerFighters = blueAlive.map { it.characterId }
            } else {
                winnerTeam = Team.BLUE
                winnerFighters = emptyList()
            }
        }
    }

    private fun spawnParticles(x: Float, y: Float, color: Color, count: Int) {
        for (i in 0 until count) {
            val angle = Random.nextFloat() * 2f * PI.toFloat()
            val speed = Random.nextFloat() * 140f + 40f
            particles.add(
                Particle(
                    x = x,
                    y = y,
                    vx = cos(angle) * speed,
                    vy = sin(angle) * speed,
                    color = color,
                    size = Random.nextFloat() * 5f + 3f,
                    maxLife = Random.nextFloat() * 0.25f + 0.2f
                )
            )
        }
    }

    private fun spawnMangaWord(x: Float, y: Float, word: String, color: Color) {
        mangaWords.add(
            MangaEffectWord(
                id = idGen.incrementAndGet(),
                x = x.coerceIn(80f, ARENA_SIZE - 80f),
                y = y.coerceIn(80f, ARENA_SIZE - 80f),
                word = word,
                color = color
            )
        )
    }
}
