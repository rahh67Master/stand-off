package com.example.audio

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import com.example.model.SoundType
import kotlinx.coroutines.*
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.*
import kotlin.random.Random

object SoundSynthesizer {
    @Volatile
    var isSoundEnabled: Boolean = true

    @Volatile
    var sfxVolumeScale: Float = 1.0f

    private const val SAMPLE_RATE = 22050
    private val scope = CoroutineScope(Dispatchers.Default + SupervisorJob())

    // Cached pre-generated sound buffers
    private val soundBuffers = ConcurrentHashMap<SoundType, ShortArray>()

    // Atomic flag to ensure at most 1 AudioTrack runs at any time
    private val isAudioTrackBusy = AtomicBoolean(false)
    private var lastPlayTimestamp = 0L

    init {
        // Pre-generate standard sounds asynchronously in background
        scope.launch {
            try {
                for (type in SoundType.values()) {
                    soundBuffers[type] = generateSoundBuffer(type)
                }
            } catch (_: Throwable) {
            }
        }
    }

    fun play(soundType: SoundType) {
        if (!isSoundEnabled) return

        val now = System.currentTimeMillis()
        // Rate limiter: max 1 sound per 65ms to prevent audio queue saturation
        if (now - lastPlayTimestamp < 65L && soundType != SoundType.FIGHT_BELL && soundType != SoundType.TIME_STOP_START) {
            return
        }

        // Only 1 AudioTrack concurrently to strictly stay within Android's system limits
        if (!isAudioTrackBusy.compareAndSet(false, true)) {
            return
        }

        lastPlayTimestamp = now

        scope.launch {
            var track: AudioTrack? = null
            try {
                val buffer = soundBuffers.getOrPut(soundType) { generateSoundBuffer(soundType) }
                val minBufSize = AudioTrack.getMinBufferSize(
                    SAMPLE_RATE,
                    AudioFormat.CHANNEL_OUT_MONO,
                    AudioFormat.ENCODING_PCM_16BIT
                )
                val bufferSizeBytes = max(buffer.size * 2, max(minBufSize, 2048))

                track = AudioTrack.Builder()
                    .setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_GAME)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                            .build()
                    )
                    .setAudioFormat(
                        AudioFormat.Builder()
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setSampleRate(SAMPLE_RATE)
                            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                            .build()
                    )
                    .setBufferSizeInBytes(bufferSizeBytes)
                    .setTransferMode(AudioTrack.MODE_STATIC)
                    .build()

                val scale = sfxVolumeScale
                if (scale < 0.99f) {
                    val scaled = ShortArray(buffer.size) { i ->
                        (buffer[i] * scale).toInt().coerceIn(-32767, 32767).toShort()
                    }
                    track.write(scaled, 0, scaled.size)
                } else {
                    track.write(buffer, 0, buffer.size)
                }
                track.play()

                val durationMs = ((buffer.size * 1000L) / SAMPLE_RATE).coerceIn(40L, 400L)
                delay(durationMs)
            } catch (_: Throwable) {
                // If native audio device is unavailable in emulator, fail silently
            } finally {
                try {
                    track?.stop()
                    track?.release()
                } catch (_: Throwable) {
                }
                isAudioTrackBusy.set(false)
            }
        }
    }

    private fun generateSoundBuffer(type: SoundType): ShortArray {
        return when (type) {
            SoundType.BALL_BOUNCE -> generateBounceSound()
            SoundType.BALL_COLLISION -> generateCollisionSound()
            SoundType.HEAVY_HIT -> generateHeavyHitSound()
            SoundType.BARRAGE_CLASH -> generateBarrageClashSound()
            SoundType.SWORD_SLASH -> generateSlashSound()
            SoundType.GUNSHOT -> generateGunshotSound()
            SoundType.EMERALD_FIRE -> generateEmeraldSound()
            SoundType.SPIN_RELEASE -> generateSpinSound()
            SoundType.TIME_STOP_START -> generateTimeStopSound()
            SoundType.TIME_STOP_END -> generateTimeStopEndSound()
            SoundType.KO_BURST -> generateKoSound()
            SoundType.RAGE_READY -> generateRageReadySound()
            SoundType.COUNTDOWN_BEEP -> generateBeepSound(520.0, 0.08)
            SoundType.FIGHT_BELL -> generateFightBellSound()
        }
    }

    private fun generateBounceSound(): ShortArray {
        val duration = 0.05
        val totalSamples = (SAMPLE_RATE * duration).toInt()
        val buffer = ShortArray(totalSamples)
        for (i in 0 until totalSamples) {
            val t = i.toDouble() / SAMPLE_RATE
            val freq = 260.0 - (t / duration) * 80.0
            val env = exp(-t * 40.0)
            val sample = (sin(2.0 * PI * freq * t) * env * 24000).toInt()
            buffer[i] = sample.coerceIn(-32767, 32767).toShort()
        }
        return buffer
    }

    private fun generateCollisionSound(): ShortArray {
        val duration = 0.09
        val totalSamples = (SAMPLE_RATE * duration).toInt()
        val buffer = ShortArray(totalSamples)
        for (i in 0 until totalSamples) {
            val t = i.toDouble() / SAMPLE_RATE
            val freq = 140.0 - (t / duration) * 80.0
            val noise = (Random.nextDouble() * 2.0 - 1.0) * 0.3
            val env = exp(-t * 22.0)
            val tone = sin(2.0 * PI * freq * t) * 0.7 + noise
            val sample = (tone * env * 28000).toInt()
            buffer[i] = sample.coerceIn(-32767, 32767).toShort()
        }
        return buffer
    }

    private fun generateHeavyHitSound(): ShortArray {
        val duration = 0.1
        val totalSamples = (SAMPLE_RATE * duration).toInt()
        val buffer = ShortArray(totalSamples)
        for (i in 0 until totalSamples) {
            val t = i.toDouble() / SAMPLE_RATE
            val freq = 180.0 - (t / duration) * 120.0
            val noise = (Random.nextDouble() * 2.0 - 1.0) * 0.45
            val env = exp(-t * 25.0)
            val tone = sin(2.0 * PI * freq * t) * 0.55 + noise
            val sample = (tone * env * 30000).toInt()
            buffer[i] = sample.coerceIn(-32767, 32767).toShort()
        }
        return buffer
    }

    private fun generateBarrageClashSound(): ShortArray {
        val duration = 0.04
        val totalSamples = (SAMPLE_RATE * duration).toInt()
        val buffer = ShortArray(totalSamples)
        for (i in 0 until totalSamples) {
            val t = i.toDouble() / SAMPLE_RATE
            val noise = (Random.nextDouble() * 2.0 - 1.0) * 0.7
            val freq = 420.0
            val env = exp(-t * 50.0)
            val tone = sin(2.0 * PI * freq * t) * 0.3 + noise
            val sample = (tone * env * 22000).toInt()
            buffer[i] = sample.coerceIn(-32767, 32767).toShort()
        }
        return buffer
    }

    private fun generateSlashSound(): ShortArray {
        val duration = 0.06
        val totalSamples = (SAMPLE_RATE * duration).toInt()
        val buffer = ShortArray(totalSamples)
        for (i in 0 until totalSamples) {
            val t = i.toDouble() / SAMPLE_RATE
            val freq = 1200.0 - (t / duration) * 600.0
            val noise = (Random.nextDouble() * 2.0 - 1.0) * 0.5
            val env = sin(PI * (t / duration)) * exp(-t * 15.0)
            val tone = sin(2.0 * PI * freq * t) * 0.5 + noise
            val sample = (tone * env * 25000).toInt()
            buffer[i] = sample.coerceIn(-32767, 32767).toShort()
        }
        return buffer
    }

    private fun generateGunshotSound(): ShortArray {
        val duration = 0.08
        val totalSamples = (SAMPLE_RATE * duration).toInt()
        val buffer = ShortArray(totalSamples)
        for (i in 0 until totalSamples) {
            val t = i.toDouble() / SAMPLE_RATE
            val noise = (Random.nextDouble() * 2.0 - 1.0)
            val env = exp(-t * 35.0)
            val sample = (noise * env * 29000).toInt()
            buffer[i] = sample.coerceIn(-32767, 32767).toShort()
        }
        return buffer
    }

    private fun generateEmeraldSound(): ShortArray {
        val duration = 0.07
        val totalSamples = (SAMPLE_RATE * duration).toInt()
        val buffer = ShortArray(totalSamples)
        for (i in 0 until totalSamples) {
            val t = i.toDouble() / SAMPLE_RATE
            val f1 = 880.0
            val f2 = 1320.0
            val env = exp(-t * 28.0)
            val tone = (sin(2.0 * PI * f1 * t) + sin(2.0 * PI * f2 * t)) * 0.5
            val sample = (tone * env * 24000).toInt()
            buffer[i] = sample.coerceIn(-32767, 32767).toShort()
        }
        return buffer
    }

    private fun generateSpinSound(): ShortArray {
        val duration = 0.08
        val totalSamples = (SAMPLE_RATE * duration).toInt()
        val buffer = ShortArray(totalSamples)
        for (i in 0 until totalSamples) {
            val t = i.toDouble() / SAMPLE_RATE
            val freq = 340.0 + sin(2.0 * PI * 18.0 * t) * 60.0
            val env = exp(-t * 18.0)
            val tone = sin(2.0 * PI * freq * t)
            val sample = (tone * env * 22000).toInt()
            buffer[i] = sample.coerceIn(-32767, 32767).toShort()
        }
        return buffer
    }

    private fun generateTimeStopSound(): ShortArray {
        val duration = 0.35
        val totalSamples = (SAMPLE_RATE * duration).toInt()
        val buffer = ShortArray(totalSamples)
        for (i in 0 until totalSamples) {
            val t = i.toDouble() / SAMPLE_RATE
            val freq = 160.0 * (1.0 - t / duration) + 38.0
            val env = if (t < 0.28) 1.0 else (0.35 - t) / 0.07
            val tone = sin(2.0 * PI * freq * t)
            val sample = (tone * env * 31000).toInt()
            buffer[i] = sample.coerceIn(-32767, 32767).toShort()
        }
        return buffer
    }

    private fun generateTimeStopEndSound(): ShortArray {
        val duration = 0.18
        val totalSamples = (SAMPLE_RATE * duration).toInt()
        val buffer = ShortArray(totalSamples)
        for (i in 0 until totalSamples) {
            val t = i.toDouble() / SAMPLE_RATE
            val freq = 80.0 + (t / duration) * 350.0
            val env = sin(PI * (t / duration))
            val tone = sin(2.0 * PI * freq * t)
            val sample = (tone * env * 26000).toInt()
            buffer[i] = sample.coerceIn(-32767, 32767).toShort()
        }
        return buffer
    }

    private fun generateKoSound(): ShortArray {
        val duration = 0.4
        val totalSamples = (SAMPLE_RATE * duration).toInt()
        val buffer = ShortArray(totalSamples)
        for (i in 0 until totalSamples) {
            val t = i.toDouble() / SAMPLE_RATE
            val freq = 90.0 - (t / duration) * 50.0
            val noise = (Random.nextDouble() * 2.0 - 1.0) * 0.4
            val env = exp(-t * 6.0)
            val tone = sin(2.0 * PI * freq * t) * 0.6 + noise
            val sample = (tone * env * 30000).toInt()
            buffer[i] = sample.coerceIn(-32767, 32767).toShort()
        }
        return buffer
    }

    private fun generateRageReadySound(): ShortArray {
        val duration = 0.15
        val totalSamples = (SAMPLE_RATE * duration).toInt()
        val buffer = ShortArray(totalSamples)
        for (i in 0 until totalSamples) {
            val t = i.toDouble() / SAMPLE_RATE
            val freq = 440.0 + (t / duration) * 440.0
            val env = exp(-t * 8.0)
            val tone = sin(2.0 * PI * freq * t)
            val sample = (tone * env * 24000).toInt()
            buffer[i] = sample.coerceIn(-32767, 32767).toShort()
        }
        return buffer
    }

    private fun generateBeepSound(freq: Double, duration: Double): ShortArray {
        val totalSamples = (SAMPLE_RATE * duration).toInt()
        val buffer = ShortArray(totalSamples)
        for (i in 0 until totalSamples) {
            val t = i.toDouble() / SAMPLE_RATE
            val env = sin(PI * (t / duration))
            val tone = sin(2.0 * PI * freq * t)
            val sample = (tone * env * 22000).toInt()
            buffer[i] = sample.coerceIn(-32767, 32767).toShort()
        }
        return buffer
    }

    private fun generateFightBellSound(): ShortArray {
        val duration = 0.3
        val totalSamples = (SAMPLE_RATE * duration).toInt()
        val buffer = ShortArray(totalSamples)
        for (i in 0 until totalSamples) {
            val t = i.toDouble() / SAMPLE_RATE
            val f1 = 659.25
            val f2 = 880.0
            val env = exp(-t * 8.0)
            val tone = (sin(2.0 * PI * f1 * t) * 0.6 + sin(2.0 * PI * f2 * t) * 0.4)
            val sample = (tone * env * 28000).toInt()
            buffer[i] = sample.coerceIn(-32767, 32767).toShort()
        }
        return buffer
    }
}
