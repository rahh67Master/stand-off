package com.example.audio

import android.content.Context
import android.media.MediaPlayer
import android.util.Log
import com.example.model.CharacterId
import kotlinx.coroutines.*

/**
 * Centralized theme music manager for STAND-OFF Stand Arrow activations.
 * Manages character-specific anime themes with 0.5-second crossfades,
 * seamless looping, pause/resume synchronization, combat SFX ducking,
 * and robust missing-file safety.
 */
object ThemeMusicManager {
    private const val TAG = "ThemeMusicManager"
    private const val CROSSFADE_DURATION_MS = 500L

    @Volatile
    private var activePlayer: MediaPlayer? = null

    @Volatile
    private var fadingPlayer: MediaPlayer? = null

    @Volatile
    var currentPlayingCharacterId: CharacterId? = null
        private set

    private var crossfadeJob: Job? = null
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())

    /**
     * Resolves the resource name for a given character.
     */
    fun getThemeResourceName(characterId: CharacterId): String {
        return when (characterId) {
            CharacterId.JOTARO -> "jotaro_theme"
            CharacterId.DIO -> "dio_theme"
            CharacterId.GIORNO -> "giorno_theme"
            CharacterId.BRUNO -> "bruno_theme"
            CharacterId.POLNAREFF -> "polnareff_theme"
            CharacterId.KAKYOIN -> "kakyoin_theme"
            CharacterId.MISTA -> "mista_theme"
            CharacterId.JOSUKE -> "josuke_theme"
            CharacterId.GYRO -> "gyro_theme"
        }
    }

    /**
     * Plays the character-specific theme song at the start of a Stand Arrow activation.
     * If another theme is already playing, smoothly crossfades over 0.5s.
     * Avoids restarting repeatedly from collisions or AI loops.
     */
    fun playTheme(context: Context, characterId: CharacterId) {
        val appContext = context.applicationContext

        // If the same character's theme is already actively playing, do not restart
        if (currentPlayingCharacterId == characterId && activePlayer?.isPlaying == true) {
            return
        }

        val resName = getThemeResourceName(characterId)
        val resId = appContext.resources.getIdentifier(resName, "raw", appContext.packageName)

        if (resId == 0) {
            Log.w(TAG, "Theme audio resource '$resName' not found in res/raw. Continuing battle normally.")
            return
        }

        scope.launch {
            try {
                val newPlayer = try {
                    MediaPlayer.create(appContext, resId)
                } catch (e: Exception) {
                    Log.w(TAG, "Failed to create MediaPlayer for '$resName': ${e.message}", e)
                    null
                }

                if (newPlayer == null) {
                    Log.w(TAG, "MediaPlayer returned null for '$resName'. Continuing battle without crash.")
                    return@launch
                }

                newPlayer.isLooping = true

                // Cancel any ongoing crossfade
                crossfadeJob?.cancel()

                val oldPlayer = activePlayer
                if (oldPlayer != null && oldPlayer.isPlaying) {
                    // Snappy 0.5-second crossfade between current and new theme
                    fadingPlayer = oldPlayer
                    activePlayer = newPlayer
                    currentPlayingCharacterId = characterId

                    newPlayer.setVolume(0.0f, 0.0f)
                    newPlayer.start()

                    crossfadeJob = launch {
                        val steps = 10
                        val stepDelay = CROSSFADE_DURATION_MS / steps
                        for (i in 1..steps) {
                            val progress = i.toFloat() / steps
                            try {
                                oldPlayer.setVolume(1.0f - progress, 1.0f - progress)
                                newPlayer.setVolume(progress, progress)
                            } catch (_: Exception) {
                            }
                            delay(stepDelay)
                        }

                        // Safely release the old player
                        try {
                            if (oldPlayer.isPlaying) oldPlayer.stop()
                            oldPlayer.release()
                        } catch (_: Exception) {
                        }
                        if (fadingPlayer === oldPlayer) {
                            fadingPlayer = null
                        }
                        newPlayer.setVolume(1.0f, 1.0f)
                    }
                } else {
                    // Direct start at full volume
                    try {
                        oldPlayer?.stop()
                        oldPlayer?.release()
                    } catch (_: Exception) {
                    }
                    activePlayer = newPlayer
                    currentPlayingCharacterId = characterId
                    newPlayer.setVolume(1.0f, 1.0f)
                    newPlayer.start()
                }

                // Slightly duck combat sound effects to highlight theme music
                SoundSynthesizer.sfxVolumeScale = 0.55f
                Log.d(TAG, "Now playing Stand Arrow theme for $characterId ($resName)")
            } catch (e: Exception) {
                Log.e(TAG, "Error playing theme for $characterId: ${e.message}", e)
            }
        }
    }

    /**
     * Pauses the theme music when the battle is paused.
     */
    fun pause() {
        scope.launch {
            try {
                if (activePlayer?.isPlaying == true) {
                    activePlayer?.pause()
                    Log.d(TAG, "Theme music paused at current position")
                }
            } catch (e: Exception) {
                Log.w(TAG, "Error pausing theme music: ${e.message}")
            }
        }
    }

    /**
     * Resumes the theme music from its exact position when unpausing.
     */
    fun resume() {
        scope.launch {
            try {
                activePlayer?.let { player ->
                    if (!player.isPlaying && currentPlayingCharacterId != null) {
                        player.start()
                        Log.d(TAG, "Theme music resumed from paused position")
                    }
                }
            } catch (e: Exception) {
                Log.w(TAG, "Error resuming theme music: ${e.message}")
            }
        }
    }

    /**
     * Stops the active theme and resets audio states for match end or restart.
     */
    fun stopAndReset() {
        crossfadeJob?.cancel()
        currentPlayingCharacterId = null

        val playerToStop = activePlayer
        val fadingToStop = fadingPlayer
        activePlayer = null
        fadingPlayer = null

        scope.launch {
            try {
                playerToStop?.let { p ->
                    try {
                        if (p.isPlaying) p.stop()
                        p.release()
                    } catch (_: Exception) {
                    }
                }
                fadingToStop?.let { p ->
                    try {
                        if (p.isPlaying) p.stop()
                        p.release()
                    } catch (_: Exception) {
                    }
                }
            } finally {
                // Restore combat SFX to full volume
                SoundSynthesizer.sfxVolumeScale = 1.0f
                Log.d(TAG, "Theme music stopped and reset to normal")
            }
        }
    }

    /**
     * Releases all MediaPlayer resources completely.
     */
    fun release() {
        stopAndReset()
    }
}
