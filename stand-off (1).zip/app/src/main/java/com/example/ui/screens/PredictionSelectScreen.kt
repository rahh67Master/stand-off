package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.audio.SoundSynthesizer
import com.example.model.*
import kotlinx.coroutines.delay
import kotlin.random.Random

@Composable
fun PredictionSelectScreen(
    onBack: () -> Unit,
    onStartBattle: (BattleConfig) -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler { onBack() }

    val currentCoins by CurrencyManager.coins.collectAsState()

    var blue1 by remember { mutableStateOf(CharacterId.JOTARO) }
    var blue2 by remember { mutableStateOf(CharacterId.GYRO) }
    var red1 by remember { mutableStateOf(CharacterId.KAKYOIN) }
    var red2 by remember { mutableStateOf(CharacterId.BRUNO) }

    var isShuffling by remember { mutableStateOf(true) }
    var selectedTeam by remember { mutableStateOf<Team?>(null) }
    var selectedTier by remember { mutableStateOf(PredictionTier.FREE) }
    var showConfirmDialog by remember { mutableStateOf(false) }

    fun generateFairMatchup() {
        val allChars = CharacterId.values().toList().shuffled()
        blue1 = allChars[0]
        blue2 = allChars[1]
        red1 = allChars[2]
        red2 = allChars[3]
    }

    LaunchedEffect(Unit) {
        val allChars = CharacterId.values().toList()
        for (i in 0 until 10) {
            blue1 = allChars.random()
            blue2 = allChars.random()
            red1 = allChars.random()
            red2 = allChars.random()
            delay(60)
        }
        generateFairMatchup()
        isShuffling = false
        SoundSynthesizer.play(SoundType.COUNTDOWN_BEEP)
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(
                        Color(0xFF030712),
                        Color(0xFF0F172A),
                        Color(0xFF020617)
                    )
                )
            )
            .systemBarsPadding()
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 10.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // HEADER BAR
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = {
                        SoundSynthesizer.play(SoundType.COUNTDOWN_BEEP)
                        onBack()
                    },
                    modifier = Modifier.testTag("prediction_back_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.ArrowBack,
                        contentDescription = "Back",
                        tint = Color.White
                    )
                }

                Text(
                    text = "2V2 PREDICTION",
                    color = Color.White,
                    fontWeight = FontWeight.Black,
                    fontSize = 18.sp,
                    letterSpacing = 1.sp
                )

                // Currency Badge
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(16.dp))
                        .background(Color(0xFF1E293B))
                        .border(1.dp, Color(0xFFF59E0B), RoundedCornerShape(16.dp))
                        .padding(horizontal = 10.dp, vertical = 4.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("🪙", fontSize = 13.sp)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = String.format("%,d", currentCoins),
                            color = Color(0xFFFDE047),
                            fontWeight = FontWeight.Black,
                            fontSize = 12.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Bankruptcy relief notice if balance is 0
            if (currentCoins <= 0) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF7F1D1D)),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "OUT OF STAND COINS!",
                                color = Color.White,
                                fontWeight = FontWeight.Black,
                                fontSize = 11.5.sp
                            )
                            Text(
                                text = "Play Free Mode or claim an emergency 100 🪙 bailout.",
                                color = Color(0xFFFCA5A5),
                                fontSize = 9.5.sp
                            )
                        }
                        Button(
                            onClick = {
                                CurrencyManager.checkAndApplyBailout()
                                SoundSynthesizer.play(SoundType.COUNTDOWN_BEEP)
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFF59E0B)),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Text("CLAIM 100 🪙", color = Color.Black, fontWeight = FontWeight.Black, fontSize = 10.sp)
                        }
                    }
                }
                Spacer(modifier = Modifier.height(8.dp))
            }

            // TEAMS COMPARISON DISPLAY
            Text(
                text = "RANDOMLY GENERATED 2V2 MATCHUP",
                color = Color(0xFF94A3B8),
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace
            )

            Spacer(modifier = Modifier.height(8.dp))

            // BLUE TEAM BOX
            TeamDisplayCard(
                teamName = "BLUE TEAM",
                teamColor = Color(0xFF0284C7),
                char1 = blue1,
                char2 = blue2,
                isSelected = selectedTeam == Team.BLUE,
                onSelect = {
                    selectedTeam = Team.BLUE
                    SoundSynthesizer.play(SoundType.BALL_BOUNCE)
                }
            )

            Spacer(modifier = Modifier.height(6.dp))

            // VS SEPARATOR
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center,
                modifier = Modifier.fillMaxWidth()
            ) {
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .height(1.dp)
                        .background(Color(0xFF334155))
                )
                Box(
                    modifier = Modifier
                        .clip(CircleShape)
                        .background(Color(0xFF1E293B))
                        .border(1.dp, Color(0xFFFBBF24), CircleShape)
                        .padding(horizontal = 10.dp, vertical = 3.dp)
                ) {
                    Text(
                        text = "VS",
                        color = Color(0xFFFBBF24),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Black,
                        fontFamily = FontFamily.Monospace
                    )
                }
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .height(1.dp)
                        .background(Color(0xFF334155))
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            // RED TEAM BOX
            TeamDisplayCard(
                teamName = "RED TEAM",
                teamColor = Color(0xFFDC2626),
                char1 = red1,
                char2 = red2,
                isSelected = selectedTeam == Team.RED,
                onSelect = {
                    selectedTeam = Team.RED
                    SoundSynthesizer.play(SoundType.BALL_BOUNCE)
                }
            )

            Spacer(modifier = Modifier.height(16.dp))

            // PREDICTION QUESTION
            Text(
                text = "WHO WILL WIN?",
                color = Color.White,
                fontSize = 15.sp,
                fontWeight = FontWeight.Black,
                letterSpacing = 1.sp
            )

            Spacer(modifier = Modifier.height(10.dp))

            // TEAM PICKER BUTTONS
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Button(
                    onClick = {
                        selectedTeam = Team.BLUE
                        SoundSynthesizer.play(SoundType.COUNTDOWN_BEEP)
                    },
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .testTag("predict_blue_button"),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (selectedTeam == Team.BLUE) Color(0xFF0284C7) else Color(0xFF1E293B)
                    ),
                    shape = RoundedCornerShape(10.dp),
                    border = androidx.compose.foundation.BorderStroke(
                        width = if (selectedTeam == Team.BLUE) 2.dp else 1.dp,
                        color = if (selectedTeam == Team.BLUE) Color(0xFF38BDF8) else Color(0xFF334155)
                    )
                ) {
                    Text(
                        text = "🔵 BLUE TEAM",
                        color = Color.White,
                        fontWeight = FontWeight.Black,
                        fontSize = 13.sp
                    )
                }

                Button(
                    onClick = {
                        selectedTeam = Team.RED
                        SoundSynthesizer.play(SoundType.COUNTDOWN_BEEP)
                    },
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .testTag("predict_red_button"),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (selectedTeam == Team.RED) Color(0xFFDC2626) else Color(0xFF1E293B)
                    ),
                    shape = RoundedCornerShape(10.dp),
                    border = androidx.compose.foundation.BorderStroke(
                        width = if (selectedTeam == Team.RED) 2.dp else 1.dp,
                        color = if (selectedTeam == Team.RED) Color(0xFFF87171) else Color(0xFF334155)
                    )
                ) {
                    Text(
                        text = "🔴 RED TEAM",
                        color = Color.White,
                        fontWeight = FontWeight.Black,
                        fontSize = 13.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            // REWARD TIERS SECTION
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "SELECT REWARD TIER",
                    color = Color(0xFFFBBF24),
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Black,
                    fontFamily = FontFamily.Monospace,
                    letterSpacing = 1.sp
                )
                Text(
                    text = "FAIR & AUTONOMOUS",
                    color = Color(0xFF64748B),
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            // 4 TIERS GRID
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                PredictionTier.values().forEach { tier ->
                    val hasEnough = currentCoins >= tier.wager
                    val isSelected = selectedTier == tier

                    Card(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(8.dp))
                            .border(
                                width = if (isSelected) 2.dp else 1.dp,
                                color = if (isSelected) Color(0xFFF59E0B) else if (!hasEnough) Color(0xFF334155) else Color(0xFF475569),
                                shape = RoundedCornerShape(8.dp)
                            )
                            .clickable(enabled = hasEnough) {
                                selectedTier = tier
                                SoundSynthesizer.play(SoundType.COUNTDOWN_BEEP)
                            }
                            .testTag("tier_${tier.name.lowercase()}"),
                        colors = CardDefaults.cardColors(
                            containerColor = if (isSelected) Color(0xFF1E293B) else Color(0xFF0F172A)
                        )
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 8.dp, horizontal = 4.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                text = tier.displayName,
                                color = if (isSelected) Color(0xFFFDE047) else if (!hasEnough) Color(0xFF64748B) else Color.White,
                                fontWeight = FontWeight.Black,
                                fontSize = 12.sp
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = if (tier.wager == 0) "0 🪙" else "${tier.wager} 🪙",
                                color = if (!hasEnough) Color(0xFFEF4444) else Color(0xFF94A3B8),
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "+${tier.profit} 🪙",
                                color = if (hasEnough) Color(0xFF10B981) else Color(0xFF64748B),
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Black,
                                fontFamily = FontFamily.Monospace
                            )
                            if (!hasEnough) {
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = "LOCKED",
                                    color = Color(0xFFEF4444),
                                    fontSize = 7.5.sp,
                                    fontWeight = FontWeight.Black
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // BREAKDOWN SUMMARY BOX
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(10.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF334155))
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("WAGER:", color = Color(0xFF94A3B8), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        Text(
                            text = if (selectedTier.wager == 0) "0 🪙 (FREE)" else "${selectedTier.wager} 🪙",
                            color = Color.White,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Black,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("POTENTIAL PROFIT:", color = Color(0xFF94A3B8), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        Text(
                            text = "+${selectedTier.profit} 🪙",
                            color = Color(0xFF10B981),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Black,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("TOTAL RETURN (IF CORRECT):", color = Color(0xFFFBBF24), fontSize = 11.sp, fontWeight = FontWeight.Black)
                        Text(
                            text = "${selectedTier.totalReturn} 🪙",
                            color = Color(0xFFFDE047),
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Black,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            // ACTION BUTTONS
            Button(
                onClick = {
                    if (selectedTeam != null) {
                        SoundSynthesizer.play(SoundType.COUNTDOWN_BEEP)
                        showConfirmDialog = true
                    }
                },
                enabled = selectedTeam != null && currentCoins >= selectedTier.wager,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .testTag("confirm_prediction_open_button"),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFFF59E0B),
                    disabledContainerColor = Color(0xFF334155)
                ),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text(
                    text = if (selectedTeam == null) "SELECT A WINNER TO PREDICT" else "REVIEW & CONFIRM PREDICTION",
                    color = if (selectedTeam == null) Color(0xFF94A3B8) else Color.Black,
                    fontWeight = FontWeight.Black,
                    fontSize = 13.5.sp,
                    letterSpacing = 0.5.sp
                )
            }

            Spacer(modifier = Modifier.height(12.dp))
        }
    }

    // CONFIRMATION MODAL DIALOG
    if (showConfirmDialog && selectedTeam != null) {
        val teamColor = if (selectedTeam == Team.BLUE) Color(0xFF0284C7) else Color(0xFFDC2626)
        val teamName = if (selectedTeam == Team.BLUE) "BLUE TEAM" else "RED TEAM"

        AlertDialog(
            onDismissRequest = { showConfirmDialog = false },
            containerColor = Color(0xFF0F172A),
            title = {
                Text(
                    text = "CONFIRM PREDICTION",
                    color = Color.White,
                    fontWeight = FontWeight.Black,
                    fontSize = 16.sp
                )
            },
            text = {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Text(
                        text = "YOUR PREDICTION:",
                        color = Color(0xFF94A3B8),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = teamName,
                        color = teamColor,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Black
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = "TIER: ${selectedTier.displayName}",
                        color = Color.White,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "WAGER: ${if (selectedTier.wager == 0) "0 🪙 (FREE)" else "${selectedTier.wager} 🪙"}",
                        color = Color.White,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "POTENTIAL PROFIT: +${selectedTier.profit} 🪙",
                        color = Color(0xFF10B981),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "TOTAL RETURN IF CORRECT: ${selectedTier.totalReturn} 🪙",
                        color = Color(0xFFFDE047),
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Black
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = "Once confirmed, the wager is locked and the autonomous 2V2 simulation begins. The simulation is 100% fair and unmanipulated.",
                        color = Color(0xFF64748B),
                        fontSize = 10.sp
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val success = CurrencyManager.deductWager(selectedTier.wager)
                        if (success) {
                            showConfirmDialog = false
                            val config = BattleConfig(
                                isTwoVsTwo = true,
                                blueTeam = listOf(blue1, blue2),
                                redTeam = listOf(red1, red2),
                                battleInstanceId = System.currentTimeMillis(),
                                predictionConfig = PredictionConfig(
                                    predictedTeam = selectedTeam!!,
                                    tier = selectedTier,
                                    wagerAmount = selectedTier.wager,
                                    potentialProfit = selectedTier.profit,
                                    totalReturn = selectedTier.totalReturn
                                )
                            )
                            SoundSynthesizer.play(SoundType.FIGHT_BELL)
                            onStartBattle(config)
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFF59E0B)),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("CONFIRM PREDICTION", color = Color.Black, fontWeight = FontWeight.Black)
                }
            },
            dismissButton = {
                TextButton(onClick = { showConfirmDialog = false }) {
                    Text("CHANGE PREDICTION", color = Color(0xFF94A3B8))
                }
            }
        )
    }
}

@Composable
private fun TeamDisplayCard(
    teamName: String,
    teamColor: Color,
    char1: CharacterId,
    char2: CharacterId,
    isSelected: Boolean,
    onSelect: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .border(
                width = if (isSelected) 2.dp else 1.dp,
                color = if (isSelected) teamColor else teamColor.copy(alpha = 0.4f),
                shape = RoundedCornerShape(12.dp)
            )
            .clickable { onSelect() },
        colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .clip(CircleShape)
                            .background(teamColor)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = teamName,
                        color = teamColor,
                        fontWeight = FontWeight.Black,
                        fontSize = 12.sp,
                        letterSpacing = 1.sp
                    )
                }

                if (isSelected) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(teamColor)
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = "PREDICTED ✓",
                            color = Color.White,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Black
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FighterDetailMiniCard(charId = char1, teamColor = teamColor, modifier = Modifier.weight(1f))
                FighterDetailMiniCard(charId = char2, teamColor = teamColor, modifier = Modifier.weight(1f))
            }
        }
    }
}

@Composable
private fun FighterDetailMiniCard(
    charId: CharacterId,
    teamColor: Color,
    modifier: Modifier = Modifier
) {
    val def = CharacterRegistry.get(charId)

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(Color(0xFF1E293B).copy(alpha = 0.8f))
            .border(0.5.dp, Color(0xFF334155), RoundedCornerShape(8.dp))
            .padding(8.dp)
    ) {
        Column {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(24.dp)
                        .clip(CircleShape)
                        .background(def.primaryColor)
                        .border(1.dp, def.accentColor, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = charId.displayName.take(1),
                        color = Color.White,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Black
                    )
                }
                Spacer(modifier = Modifier.width(6.dp))
                Column {
                    Text(
                        text = charId.displayName,
                        color = Color.White,
                        fontWeight = FontWeight.Black,
                        fontSize = 11.sp,
                        maxLines = 1
                    )
                    Text(
                        text = charId.standName,
                        color = def.accentColor,
                        fontWeight = FontWeight.Bold,
                        fontSize = 9.sp,
                        maxLines = 1
                    )
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            // Role & Stats
            Text(
                text = "ROLE: ${charId.title}",
                color = Color(0xFF94A3B8),
                fontSize = 8.5.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 1
            )
            Text(
                text = "HP: 200 • ${def.attackType.name.replace("_", " ")}",
                color = Color(0xFFCBD5E1),
                fontSize = 8.5.sp,
                fontWeight = FontWeight.Medium,
                maxLines = 1
            )
            Text(
                text = "RAGE: ${def.rageName}",
                color = Color(0xFFFDE047),
                fontSize = 8.5.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 1
            )
        }
    }
}
