package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.audio.SoundSynthesizer
import com.example.model.CurrencyManager
import com.example.model.SoundType

@Composable
fun MainMenuScreen(
    onSelect1v1: () -> Unit,
    onSelect2v2: () -> Unit,
    onSelectRandom: () -> Unit,
    onSelectPrediction: () -> Unit,
    onSettings: () -> Unit,
    modifier: Modifier = Modifier
) {
    val coins by CurrencyManager.coins.collectAsState()

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(
                        Color(0xFF030712),
                        Color(0xFF0F172A),
                        Color(0xFF020617)
                    )
                )
            )
            .systemBarsPadding()
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 14.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // TOP HEADER: Currency display in top-right
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 4.dp),
                horizontalArrangement = Arrangement.End,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(20.dp))
                        .background(Color(0xFF1E293B).copy(alpha = 0.9f))
                        .border(1.2.dp, Color(0xFFF59E0B), RoundedCornerShape(20.dp))
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                        .testTag("currency_header_pill"),
                    contentAlignment = Alignment.Center
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Text(
                            text = "🪙",
                            fontSize = 15.sp
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = String.format("%,d", coins),
                            color = Color(0xFFFDE047),
                            fontWeight = FontWeight.Black,
                            fontSize = 13.5.sp,
                            fontFamily = FontFamily.Monospace,
                            letterSpacing = 0.5.sp
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "STAND COINS",
                            color = Color(0xFF94A3B8),
                            fontWeight = FontWeight.Bold,
                            fontSize = 8.5.sp,
                            letterSpacing = 0.5.sp
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // TITLE AREA
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.padding(vertical = 12.dp)
            ) {
                Text(
                    text = "スタンド・オフ",
                    color = Color(0xFFFBBF24),
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Black,
                    letterSpacing = 3.sp
                )

                Spacer(modifier = Modifier.height(4.dp))

                Text(
                    text = "STAND-OFF",
                    color = Color.White,
                    fontSize = 44.sp,
                    fontWeight = FontWeight.Black,
                    letterSpacing = 3.sp
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // BATTLE MODE MENU BUTTONS
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .height(1.dp)
                            .background(Color(0xFF334155))
                    )
                    Text(
                        text = "  BATTLE MODE  ",
                        color = Color(0xFFFBBF24),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Black,
                        letterSpacing = 2.sp,
                        fontFamily = FontFamily.Monospace
                    )
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .height(1.dp)
                            .background(Color(0xFF334155))
                    )
                }

                Spacer(modifier = Modifier.height(2.dp))

                ArcadeMenuButton(
                    title = "1V1 MODE",
                    subtitle = "Select 1 Blue Fighter vs 1 Red Fighter",
                    icon = Icons.Default.SportsMma,
                    accentColor = Color(0xFF0284C7),
                    testTag = "menu_1v1_button",
                    onClick = {
                        SoundSynthesizer.play(SoundType.COUNTDOWN_BEEP)
                        onSelect1v1()
                    }
                )

                ArcadeMenuButton(
                    title = "2V2 MODE",
                    subtitle = "Select 2 Blue Fighters vs 2 Red Fighters",
                    icon = Icons.Default.Groups,
                    accentColor = Color(0xFFDC2626),
                    testTag = "menu_2v2_button",
                    onClick = {
                        SoundSynthesizer.play(SoundType.COUNTDOWN_BEEP)
                        onSelect2v2()
                    }
                )

                ArcadeMenuButton(
                    title = "RANDOM MODE",
                    subtitle = "Randomly select fighters",
                    icon = Icons.Default.Casino,
                    accentColor = Color(0xFFA855F7),
                    testTag = "menu_random_button",
                    onClick = {
                        SoundSynthesizer.play(SoundType.COUNTDOWN_BEEP)
                        onSelectRandom()
                    }
                )

                ArcadeMenuButton(
                    title = "2V2 PREDICTION",
                    subtitle = "Bet fictional coins on which team will win",
                    icon = Icons.Default.Paid,
                    accentColor = Color(0xFFF59E0B),
                    badgeText = "NEW",
                    testTag = "menu_prediction_button",
                    onClick = {
                        SoundSynthesizer.play(SoundType.COUNTDOWN_BEEP)
                        onSelectPrediction()
                    }
                )

                ArcadeMenuButton(
                    title = "SETTINGS",
                    subtitle = "Audio, Screen Shake & Speed",
                    icon = Icons.Default.Settings,
                    accentColor = Color(0xFF64748B),
                    testTag = "menu_settings_button",
                    onClick = {
                        SoundSynthesizer.play(SoundType.COUNTDOWN_BEEP)
                        onSettings()
                    }
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Subdued subtle bottom spacer (no clutter or unnecessary text)
            Box(
                modifier = Modifier
                    .width(40.dp)
                    .height(3.dp)
                    .clip(RoundedCornerShape(2.dp))
                    .background(Color(0xFF334155))
            )
        }
    }
}

@Composable
private fun ArcadeMenuButton(
    title: String,
    subtitle: String,
    icon: ImageVector,
    accentColor: Color,
    testTag: String,
    badgeText: String? = null,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .height(58.dp)
            .clip(RoundedCornerShape(12.dp))
            .border(1.5.dp, accentColor.copy(alpha = 0.65f), RoundedCornerShape(12.dp))
            .clickable { onClick() }
            .testTag(testTag),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A))
    ) {
        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(accentColor.copy(alpha = 0.2f))
                        .border(1.dp, accentColor, RoundedCornerShape(8.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = accentColor,
                        modifier = Modifier.size(19.dp)
                    )
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = title,
                            color = Color.White,
                            fontWeight = FontWeight.Black,
                            fontSize = 13.5.sp,
                            letterSpacing = 0.8.sp
                        )
                        if (badgeText != null) {
                            Spacer(modifier = Modifier.width(6.dp))
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(Color(0xFFF59E0B))
                                    .padding(horizontal = 5.dp, vertical = 1.dp)
                            ) {
                                Text(
                                    text = badgeText,
                                    color = Color.Black,
                                    fontSize = 8.5.sp,
                                    fontWeight = FontWeight.Black
                                )
                            }
                        }
                    }
                    Text(
                        text = subtitle,
                        color = Color(0xFF94A3B8),
                        fontSize = 9.5.sp
                    )
                }
            }

            Icon(
                imageVector = Icons.Default.ChevronRight,
                contentDescription = null,
                tint = accentColor,
                modifier = Modifier.size(20.dp)
            )
        }
    }
}
