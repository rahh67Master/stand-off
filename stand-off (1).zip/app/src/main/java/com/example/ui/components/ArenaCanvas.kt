package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.*
import androidx.compose.ui.text.*
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import com.example.model.*
import com.example.simulation.BattleSimulator
import kotlin.math.*

@OptIn(ExperimentalTextApi::class)
@Composable
fun ArenaCanvas(
    simulator: BattleSimulator,
    tick: Long,
    textMeasurer: TextMeasurer,
    modifier: Modifier = Modifier
) {
    BoxWithConstraints(
        modifier = modifier
            .aspectRatio(1f) // STRICT 1:1 PERFECT SQUARE
            .fillMaxSize()
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            @Suppress("UNUSED_VARIABLE")
            val frame = simulator.frameTick.value // Observed in draw phase to guarantee 60fps redraw every frame!
            val canvasSize = size.minDimension
            val scale = canvasSize / BattleSimulator.ARENA_SIZE

            // Screen shake offset
            val shake = simulator.screenShakeAmount
            val shakeOffsetX = if (shake > 0f) (kotlin.random.Random.nextFloat() - 0.5f) * shake * scale * 2f else 0f
            val shakeOffsetY = if (shake > 0f) (kotlin.random.Random.nextFloat() - 0.5f) * shake * scale * 2f else 0f

            translate(left = shakeOffsetX, top = shakeOffsetY) {
                // 1. Draw Arena Background & Border
                drawArenaBackground(canvasSize, scale, simulator.activeTimeStopOwner)

                // 2. Draw Kakyoin's Emerald Trap Strings
                drawTrapStrings(simulator.trapStrings, scale)

                // 2.5 Draw Bruno's Sticky Fingers Zipper Tracks
                drawZipperTracks(simulator.zipperTracks, scale)

                // 3. Draw Projectiles
                drawProjectiles(simulator.projectiles, scale)

                // 3.5 Draw Stand Arrows
                drawStandArrows(simulator.standArrows, scale, textMeasurer)

                // 4. Draw Ball Fighters
                drawFighters(simulator.fighters, scale, textMeasurer)

                // 5. Draw Sculpted Fists & Rapiers (Barrages)
                drawFistVisuals(simulator.fistVisuals, scale)

                // 6. Draw Particles
                drawParticles(simulator.particles, scale)

                // 7. Draw Manga Words & Popups
                drawMangaWords(simulator.mangaWords, scale, textMeasurer)
                drawDamagePopups(simulator.damagePopups, scale, textMeasurer)

                // 8. Time Stop Manga Atmosphere Overlay with Moving Clock & Speedlines
                if (simulator.activeTimeStopOwner != null) {
                    drawTimeStopOverlay(
                        canvasSize = canvasSize,
                        scale = scale,
                        owner = simulator.activeTimeStopOwner!!,
                        animTime = simulator.timeStopAnimationTimer,
                        remaining = simulator.timeStopRemaining,
                        textMeasurer = textMeasurer
                    )
                }

                // 8.5 Stand Arrow Activation Arena Freeze Overlay
                if (simulator.activeArrowActivation != null) {
                    drawStandArrowActivationOverlay(
                        canvasSize = canvasSize,
                        scale = scale,
                        activation = simulator.activeArrowActivation!!,
                        fighters = simulator.fighters,
                        textMeasurer = textMeasurer
                    )
                }

                // 9. Countdown Overlay
                if (simulator.phase == BattlePhase.COUNTDOWN) {
                    drawCountdownOverlay(canvasSize, simulator.countdownDisplay, textMeasurer)
                }
            }
        }
    }
}

private fun DrawScope.drawArenaBackground(canvasSize: Float, scale: Float, timeStopOwner: FighterState?) {
    // Dark anime dojo arena floor
    val baseFloorColor = if (timeStopOwner != null) {
        if (timeStopOwner.characterId == CharacterId.DIO) Color(0xFF1E1B10) else Color(0xFF0F172A)
    } else {
        Color(0xFF0B0E17)
    }

    drawRect(
        color = baseFloorColor,
        size = Size(canvasSize, canvasSize)
    )

    // Manga isometric crosshatch floor grid lines
    val gridSpacing = 100f * scale
    var pos = gridSpacing
    while (pos < canvasSize) {
        drawLine(
            color = Color(0x1A64748B),
            start = Offset(pos, 0f),
            end = Offset(pos, canvasSize),
            strokeWidth = 1.5f
        )
        drawLine(
            color = Color(0x1A64748B),
            start = Offset(0f, pos),
            end = Offset(canvasSize, pos),
            strokeWidth = 1.5f
        )
        pos += gridSpacing
    }

    // Center arena battle emblem (Double circle + manga star)
    val center = Offset(canvasSize / 2f, canvasSize / 2f)
    drawCircle(
        color = Color(0x1538BDF8),
        radius = 160f * scale,
        center = center,
        style = Stroke(width = 3f * scale)
    )
    drawCircle(
        color = Color(0x10EF4444),
        radius = 280f * scale,
        center = center,
        style = Stroke(width = 2f * scale)
    )

    // Outer Manga Border Frame
    val borderThickness = 6f * scale
    drawRect(
        brush = Brush.linearGradient(
            colors = listOf(Color(0xFF38BDF8), Color(0xFFA855F7), Color(0xFFEF4444)),
            start = Offset(0f, 0f),
            end = Offset(canvasSize, canvasSize)
        ),
        topLeft = Offset(borderThickness / 2f, borderThickness / 2f),
        size = Size(canvasSize - borderThickness, canvasSize - borderThickness),
        style = Stroke(width = borderThickness)
    )

    // Dramatic corner bracket accents
    val bracketLen = 40f * scale
    val bracketWidth = 4f * scale
    val bracketColor = Color(0xFFFBBF24)

    // Top-Left
    drawLine(bracketColor, Offset(0f, 0f), Offset(bracketLen, 0f), bracketWidth)
    drawLine(bracketColor, Offset(0f, 0f), Offset(0f, bracketLen), bracketWidth)

    // Top-Right
    drawLine(bracketColor, Offset(canvasSize, 0f), Offset(canvasSize - bracketLen, 0f), bracketWidth)
    drawLine(bracketColor, Offset(canvasSize, 0f), Offset(canvasSize, bracketLen), bracketWidth)

    // Bottom-Left
    drawLine(bracketColor, Offset(0f, canvasSize), Offset(bracketLen, canvasSize), bracketWidth)
    drawLine(bracketColor, Offset(0f, canvasSize), Offset(0f, canvasSize - bracketLen), bracketWidth)

    // Bottom-Right
    drawLine(bracketColor, Offset(canvasSize, canvasSize), Offset(canvasSize - bracketLen, canvasSize), bracketWidth)
    drawLine(bracketColor, Offset(canvasSize, canvasSize), Offset(canvasSize, canvasSize - bracketLen), bracketWidth)
}

private fun DrawScope.drawTrapStrings(trapStrings: List<TrapString>, scale: Float) {
    for (trap in trapStrings) {
        if (trap.triggered) continue
        val start = Offset(trap.x1 * scale, trap.y1 * scale)
        val end = Offset(trap.x2 * scale, trap.y2 * scale)

        // Emerald tripwire glow
        drawLine(
            color = Color(0x8010B981),
            start = start,
            end = end,
            strokeWidth = 6f * scale
        )
        drawLine(
            color = Color(0xFF34D399),
            start = start,
            end = end,
            strokeWidth = 2.5f * scale
        )

        // Nodes
        drawCircle(color = Color(0xFF10B981), radius = 5f * scale, center = start)
        drawCircle(color = Color(0xFF10B981), radius = 5f * scale, center = end)
    }
}

private fun DrawScope.drawZipperTracks(tracks: List<ZipperTrack>, scale: Float) {
    for (track in tracks) {
        val start = Offset(track.startX * scale, track.startY * scale)
        val end = Offset(track.endX * scale, track.endY * scale)
        val progress = track.openProgress
        val alpha = (1f - (track.lifetime / track.maxLifetime)).coerceIn(0f, 1f)

        val dx = end.x - start.x
        val dy = end.y - start.y
        val dist = hypot(dx, dy)
        if (dist < 1f) continue

        val angle = atan2(dy, dx)
        val currentEnd = Offset(start.x + cos(angle) * dist * progress, start.y + sin(angle) * dist * progress)

        // Dark zipper seam (void inside)
        drawLine(
            color = Color(0xFF030712).copy(alpha = alpha),
            start = start,
            end = currentEnd,
            strokeWidth = 10f * scale
        )
        drawLine(
            color = Color(0xFF38BDF8).copy(alpha = alpha * 0.6f),
            start = start,
            end = currentEnd,
            strokeWidth = 14f * scale
        )

        // Zipper golden teeth along the seam
        val step = 10f * scale
        var d = 0f
        var side = 1
        while (d <= dist * progress) {
            val toothCenter = Offset(start.x + cos(angle) * d, start.y + sin(angle) * d)
            val perpAngle = angle + (PI.toFloat() / 2f) * side
            val toothEnd = Offset(toothCenter.x + cos(perpAngle) * 5f * scale, toothCenter.y + sin(perpAngle) * 5f * scale)
            drawLine(
                color = Color(0xFFF59E0B).copy(alpha = alpha),
                start = toothCenter,
                end = toothEnd,
                strokeWidth = 2.5f * scale
            )
            d += step
            side = -side
        }

        // Golden zipper pull slider tab at head of zipper
        drawCircle(
            color = Color(0xFFFBBF24).copy(alpha = alpha),
            radius = 6f * scale,
            center = currentEnd
        )
    }
}

private fun DrawScope.drawProjectiles(projectiles: List<Projectile>, scale: Float) {
    for (proj in projectiles) {
        val center = Offset(proj.x * scale, proj.y * scale)
        val r = proj.radius * scale

        when (proj.type) {
            ProjectileType.BULLET, ProjectileType.SEX_PISTOLS_BULLET -> {
                val isPistol = proj.type == ProjectileType.SEX_PISTOLS_BULLET
                val angle = atan2(proj.vy, proj.vx)
                val tailLen = if (isPistol) 32f * scale else 22f * scale
                val tail = Offset(center.x - cos(angle) * tailLen, center.y - sin(angle) * tailLen)

                // High speed tracer motion trail
                drawLine(
                    brush = Brush.linearGradient(
                        colors = if (isPistol) {
                            listOf(Color(0x00EF4444), Color(0xFFF97316), Color(0xFFFBBF24))
                        } else {
                            listOf(Color(0x00F59E0B), Color(0xFFFBBF24), Color.White)
                        },
                        start = tail,
                        end = center
                    ),
                    start = tail,
                    end = center,
                    strokeWidth = (if (isPistol) 6f else 4.5f) * scale
                )

                // Physical metallic brass bullet casing and pointed head
                rotate(degrees = angle * (180f / PI.toFloat()), pivot = center) {
                    val bWidth = r * 1.8f
                    val bHeight = r * 1.1f
                    drawOval(
                        brush = Brush.horizontalGradient(
                            colors = if (isPistol) {
                                listOf(Color(0xFFEA580C), Color(0xFFF59E0B), Color(0xFFFEF08A))
                            } else {
                                listOf(Color(0xFFB45309), Color(0xFFF59E0B), Color(0xFFFEF9C3))
                            }
                        ),
                        topLeft = Offset(center.x - bWidth * 0.5f, center.y - bHeight * 0.5f),
                        size = Size(bWidth, bHeight)
                    )
                    // Bullet tip gleam
                    drawCircle(
                        color = Color.White,
                        radius = r * 0.35f,
                        center = Offset(center.x + bWidth * 0.3f, center.y)
                    )
                }

                // If Sex Pistols bullet: show small spirit tag or number
                if (isPistol) {
                    val badgePos = Offset(center.x, center.y - 13f * scale)
                    drawCircle(
                        color = Color(0xFFEA580C),
                        radius = 5.5f * scale,
                        center = badgePos
                    )
                    drawCircle(
                        color = Color(0xFFFDE047),
                        radius = 3.5f * scale,
                        center = badgePos
                    )
                }
            }
            ProjectileType.EMERALD, ProjectileType.AERIAL_EMERALD -> {
                val angle = atan2(proj.vy, proj.vx)
                val tailLen = 24f * scale
                val tail = Offset(center.x - cos(angle) * tailLen, center.y - sin(angle) * tailLen)

                // Green emerald energy streak
                drawLine(
                    brush = Brush.linearGradient(
                        colors = listOf(Color(0x0010B981), Color(0xFF34D399), Color(0xFF6EE7B7)),
                        start = tail,
                        end = center
                    ),
                    start = tail,
                    end = center,
                    strokeWidth = 5f * scale
                )

                // Faceted diamond gemstone
                val path = Path().apply {
                    moveTo(center.x, center.y - r * 1.2f)
                    lineTo(center.x + r, center.y)
                    lineTo(center.x, center.y + r * 1.2f)
                    lineTo(center.x - r, center.y)
                    close()
                }
                drawPath(path, Color(0xFF059669))
                // Inner facet
                val inner = Path().apply {
                    moveTo(center.x, center.y - r * 0.7f)
                    lineTo(center.x + r * 0.6f, center.y)
                    lineTo(center.x, center.y + r * 0.7f)
                    lineTo(center.x - r * 0.6f, center.y)
                    close()
                }
                drawPath(inner, Color(0xFF6EE7B7))
                drawCircle(color = Color.White, radius = r * 0.25f, center = center)
            }
            ProjectileType.STEEL_BALL, ProjectileType.GOLDEN_SPIN_BALL -> {
                // Spinning steel ball with spiral lines
                drawCircle(color = Color(0xFF64748B), radius = r, center = center)
                drawCircle(
                    color = if (proj.type == ProjectileType.GOLDEN_SPIN_BALL) Color(0xFFFACC15) else Color(0xFF84CC16),
                    radius = r,
                    center = center,
                    style = Stroke(width = 2.5f * scale)
                )

                // Rotating spiral mark
                val spinAngle = proj.rotation * (PI.toFloat() / 180f)
                val p1 = Offset(center.x + cos(spinAngle) * r * 0.7f, center.y + sin(spinAngle) * r * 0.7f)
                val p2 = Offset(center.x - cos(spinAngle) * r * 0.7f, center.y - sin(spinAngle) * r * 0.7f)
                drawLine(
                    color = if (proj.type == ProjectileType.GOLDEN_SPIN_BALL) Color(0xFFFEF08A) else Color(0xFFBEF264),
                    start = p1,
                    end = p2,
                    strokeWidth = 2.5f * scale
                )
            }
        }
    }
}

private fun DrawScope.drawFighters(
    fighters: List<FighterState>,
    scale: Float,
    textMeasurer: TextMeasurer
) {
    for (fighter in fighters) {
        val center = Offset((fighter.x + fighter.recoilX) * scale, (fighter.y + fighter.recoilY) * scale)
        val r = fighter.radius * scale
        val def = CharacterRegistry.get(fighter.characterId)
        val alpha = fighter.fadeAlpha

        if (alpha <= 0.01f) continue

        // If defeated, draw ground impact cracks underneath
        if (fighter.isDefeated) {
            val crackR = r * 1.3f
            for (i in 0 until 6) {
                val angle = (i * 60f + 15f) * (PI.toFloat() / 180f)
                val end = Offset(center.x + cos(angle) * crackR, center.y + sin(angle) * crackR)
                drawLine(
                    color = Color(0x66475569),
                    start = center,
                    end = end,
                    strokeWidth = 2f * scale
                )
            }
        }

        rotate(degrees = if (fighter.isDefeated) fighter.deathRotationDeg else 0f, pivot = center) {
            // 1. Team Glow & Rage Aura
            val teamColor = if (fighter.team == Team.BLUE) Color(0xFF38BDF8) else Color(0xFFEF4444)
            val glowColor = if (fighter.isRageActive) def.accentColor else if (fighter.isDefeated) Color(0x3364748B) else teamColor

            drawCircle(
                color = glowColor.copy(alpha = (if (fighter.isDefeated) 0.15f else 0.35f) * alpha),
                radius = r * 1.35f,
                center = center
            )

            // 2. Ball Core Circle
            val corePrimary = if (fighter.isDefeated) Color(0xFF1E293B) else def.primaryColor
            val coreSecondary = if (fighter.isDefeated) Color(0xFF334155) else def.secondaryColor
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(coreSecondary.copy(alpha = alpha), corePrimary.copy(alpha = alpha)),
                    center = center,
                    radius = r
                ),
                radius = r,
                center = center
            )

            // 3. Thick Outline
            val outlineColor = if (fighter.isDefeated) Color(0xFF475569) else teamColor
            drawCircle(
                color = outlineColor.copy(alpha = alpha),
                radius = r,
                center = center,
                style = Stroke(width = 4.5f * scale)
            )

            // 4. Character-Specific Face / Iconic Emblem
            drawCharacterIcon(fighter.characterId, center, r, scale, alpha)

            // Defeated Red 'X' Eyes on character face
            if (fighter.isDefeated) {
                val eyeSize = r * 0.22f
                val leftEye = Offset(center.x - r * 0.3f, center.y - r * 0.1f)
                val rightEye = Offset(center.x + r * 0.3f, center.y - r * 0.1f)

                // Left X
                drawLine(Color(0xFFEF4444), Offset(leftEye.x - eyeSize, leftEye.y - eyeSize), Offset(leftEye.x + eyeSize, leftEye.y + eyeSize), 3f * scale)
                drawLine(Color(0xFFEF4444), Offset(leftEye.x - eyeSize, leftEye.y + eyeSize), Offset(leftEye.x + eyeSize, leftEye.y - eyeSize), 3f * scale)

                // Right X
                drawLine(Color(0xFFEF4444), Offset(rightEye.x - eyeSize, rightEye.y - eyeSize), Offset(rightEye.x + eyeSize, rightEye.y + eyeSize), 3f * scale)
                drawLine(Color(0xFFEF4444), Offset(rightEye.x - eyeSize, rightEye.y + eyeSize), Offset(rightEye.x + eyeSize, rightEye.y - eyeSize), 3f * scale)
            }
        }

        // 5. Health & Rage Perimeter Arcs (only when alive)
        if (!fighter.isDefeated) {
            val healthPct = (fighter.hp / fighter.maxHp).coerceIn(0f, 1f)
            val ragePct = (fighter.rage / fighter.maxRage).coerceIn(0f, 1f)

            val hpColor = when {
                healthPct > 0.5f -> Color(0xFF22C55E)
                healthPct > 0.25f -> Color(0xFFF59E0B)
                else -> Color(0xFFEF4444)
            }
            drawArc(
                color = hpColor.copy(alpha = alpha),
                startAngle = 180f,
                sweepAngle = 180f * healthPct,
                useCenter = false,
                topLeft = Offset(center.x - r - 6f * scale, center.y - r - 6f * scale),
                size = Size((r + 6f * scale) * 2f, (r + 6f * scale) * 2f),
                style = Stroke(width = 3.5f * scale, cap = StrokeCap.Round)
            )

            drawArc(
                color = Color(0xFFFACC15).copy(alpha = alpha),
                startAngle = 0f,
                sweepAngle = 180f * ragePct,
                useCenter = false,
                topLeft = Offset(center.x - r - 6f * scale, center.y - r - 6f * scale),
                size = Size((r + 6f * scale) * 2f, (r + 6f * scale) * 2f),
                style = Stroke(width = 2.5f * scale, cap = StrokeCap.Round)
            )
        }

        // 6. Name Label above Ball
        val labelText = if (fighter.isDefeated) "${def.id.displayName} (KO)" else def.id.displayName
        val textResult = textMeasurer.measure(
            text = AnnotatedString(labelText),
            style = TextStyle(
                color = if (fighter.isDefeated) Color(0xFFEF4444) else Color.White.copy(alpha = alpha),
                fontSize = (11f * scale).sp,
                fontWeight = FontWeight.Black,
                fontFamily = FontFamily.SansSerif
            )
        )
        drawText(
            textLayoutResult = textResult,
            topLeft = Offset(center.x - textResult.size.width / 2f, center.y - r - 26f * scale)
        )

        // Muzzle flash when firing bullets
        if (fighter.muzzleFlashTimer > 0f) {
            val flashAngle = fighter.muzzleFlashAngle
            val flashStart = Offset(center.x + cos(flashAngle) * (r * 0.95f), center.y + sin(flashAngle) * (r * 0.95f))
            val flashLen = (24f + (fighter.muzzleFlashTimer / 0.12f) * 16f) * scale
            val flashTip = Offset(flashStart.x + cos(flashAngle) * flashLen, flashStart.y + sin(flashAngle) * flashLen)

            // Starburst cone
            drawLine(
                brush = Brush.linearGradient(
                    colors = listOf(Color.White, Color(0xFFFBBF24), Color(0xFFEA580C)),
                    start = flashStart,
                    end = flashTip
                ),
                start = flashStart,
                end = flashTip,
                strokeWidth = 6f * scale
            )
            drawCircle(
                color = Color.White,
                radius = 6f * scale,
                center = flashStart
            )
            drawCircle(
                color = Color(0xFFFDE047),
                radius = 11f * scale,
                center = flashStart
            )
        }
    }
}

private fun DrawScope.drawCharacterIcon(
    characterId: CharacterId,
    center: Offset,
    r: Float,
    scale: Float,
    alpha: Float
) {
    val iconSize = r * 0.65f

    when (characterId) {
        CharacterId.JOTARO -> {
            // Jotaro's Visor Cap + Palm Emblem
            drawRect(
                color = Color(0xFF0F172A).copy(alpha = alpha),
                topLeft = Offset(center.x - iconSize * 0.9f, center.y - iconSize * 0.4f),
                size = Size(iconSize * 1.8f, iconSize * 0.6f)
            )
            // Golden Hand Emblem on Cap
            drawCircle(color = Color(0xFFFBBF24).copy(alpha = alpha), radius = iconSize * 0.35f, center = Offset(center.x, center.y - iconSize * 0.2f))
            drawLine(Color(0xFF0F172A).copy(alpha = alpha), Offset(center.x, center.y - iconSize * 0.45f), Offset(center.x, center.y + iconSize * 0.05f), 2f * scale)
        }
        CharacterId.MISTA -> {
            // Mista Arrow Helmet
            val path = Path().apply {
                moveTo(center.x, center.y - iconSize * 0.8f)
                lineTo(center.x + iconSize * 0.7f, center.y + iconSize * 0.6f)
                lineTo(center.x - iconSize * 0.7f, center.y + iconSize * 0.6f)
                close()
            }
            drawPath(path, Color(0xFFEA580C).copy(alpha = alpha))
            // Arrow indicator pointing forward
            drawLine(Color.White.copy(alpha = alpha), Offset(center.x, center.y + iconSize * 0.4f), Offset(center.x, center.y - iconSize * 0.5f), 3.5f * scale)
        }
        CharacterId.JOSUKE -> {
            // Josuke Pompadour wave + Heart
            val path = Path().apply {
                moveTo(center.x - iconSize * 0.9f, center.y)
                cubicTo(
                    center.x - iconSize * 0.9f, center.y - iconSize * 1.1f,
                    center.x + iconSize * 0.9f, center.y - iconSize * 1.1f,
                    center.x + iconSize * 0.9f, center.y
                )
                close()
            }
            drawPath(path, Color(0xFF1E1B4B).copy(alpha = alpha))
            // Crazy Diamond Pink Heart
            drawCircle(color = Color(0xFFEC4899).copy(alpha = alpha), radius = iconSize * 0.32f, center = Offset(center.x, center.y + iconSize * 0.1f))
        }
        CharacterId.DIO -> {
            // Golden Hair & Green Heart Forehead Band
            drawCircle(color = Color(0xFFFACC15).copy(alpha = alpha), radius = iconSize * 0.75f, center = center)
            // Green heart emblem
            val heartCenter = Offset(center.x, center.y - iconSize * 0.2f)
            drawCircle(color = Color(0xFF10B981).copy(alpha = alpha), radius = iconSize * 0.32f, center = heartCenter)
            // Menacing vampire red eyes
            drawCircle(color = Color(0xFFEF4444).copy(alpha = alpha), radius = 3.5f * scale, center = Offset(center.x - iconSize * 0.35f, center.y + iconSize * 0.25f))
            drawCircle(color = Color(0xFFEF4444).copy(alpha = alpha), radius = 3.5f * scale, center = Offset(center.x + iconSize * 0.35f, center.y + iconSize * 0.25f))
        }
        CharacterId.POLNAREFF -> {
            // Silver Chariot tall silver hair + rapier tip
            drawRect(
                color = Color(0xFFE2E8F0).copy(alpha = alpha),
                topLeft = Offset(center.x - iconSize * 0.4f, center.y - iconSize * 0.9f),
                size = Size(iconSize * 0.8f, iconSize * 1.4f)
            )
            // Rapier needle
            drawLine(Color(0xFF38BDF8).copy(alpha = alpha), Offset(center.x, center.y + iconSize * 0.7f), Offset(center.x, center.y - iconSize * 0.8f), 3f * scale)
        }
        CharacterId.KAKYOIN -> {
            // Red tuft + Emerald Splash Crystal
            drawCircle(color = Color(0xFF10B981).copy(alpha = alpha), radius = iconSize * 0.6f, center = center)
            // Faceted crystal inside
            drawCircle(color = Color(0xFF6EE7B7).copy(alpha = alpha), radius = iconSize * 0.3f, center = center)
            // Cherry red swirl
            drawCircle(color = Color(0xFFEF4444).copy(alpha = alpha), radius = iconSize * 0.25f, center = Offset(center.x - iconSize * 0.4f, center.y - iconSize * 0.4f))
        }
        CharacterId.GIORNO -> {
            // 3 Golden Hair Curls & Ladybug brooch
            val curlR = iconSize * 0.22f
            drawCircle(color = Color(0xFFFDE047).copy(alpha = alpha), radius = curlR, center = Offset(center.x - iconSize * 0.45f, center.y - iconSize * 0.4f))
            drawCircle(color = Color(0xFFFDE047).copy(alpha = alpha), radius = curlR, center = Offset(center.x, center.y - iconSize * 0.55f))
            drawCircle(color = Color(0xFFFDE047).copy(alpha = alpha), radius = curlR, center = Offset(center.x + iconSize * 0.45f, center.y - iconSize * 0.4f))
            // Ladybug brooch (Magenta / cyan)
            drawCircle(color = Color(0xFFC026D3).copy(alpha = alpha), radius = iconSize * 0.35f, center = Offset(center.x, center.y + iconSize * 0.2f))
        }
        CharacterId.BRUNO -> {
            // White bob haircut & Golden Zipper tab
            val path = Path().apply {
                moveTo(center.x - iconSize * 0.8f, center.y)
                lineTo(center.x - iconSize * 0.8f, center.y - iconSize * 0.6f)
                lineTo(center.x + iconSize * 0.8f, center.y - iconSize * 0.6f)
                lineTo(center.x + iconSize * 0.8f, center.y)
                close()
            }
            drawPath(path, Color(0xFF0F172A).copy(alpha = alpha))
            // Golden Zipper
            drawLine(Color(0xFFF59E0B).copy(alpha = alpha), Offset(center.x, center.y - iconSize * 0.4f), Offset(center.x, center.y + iconSize * 0.7f), 4f * scale)
        }
        CharacterId.GYRO -> {
            // Green wide hat with slit & Steel Ball swirl
            drawRect(
                color = Color(0xFF15803D).copy(alpha = alpha),
                topLeft = Offset(center.x - iconSize * 1.0f, center.y - iconSize * 0.3f),
                size = Size(iconSize * 2.0f, iconSize * 0.4f)
            )
            // Green steel ball with golden spin spiral
            drawCircle(color = Color(0xFF84CC16).copy(alpha = alpha), radius = iconSize * 0.38f, center = Offset(center.x, center.y + iconSize * 0.3f))
        }
    }
}

// ==========================================
// ==========================================
// SCULPTED INDIVIDUAL FISTS & RAPIERS
// ==========================================

private fun DrawScope.drawFistVisuals(fistVisuals: List<FistVisual>, scale: Float) {
    for (fist in fistVisuals) {
        val currX = (fist.startX + (fist.targetX - fist.startX) * fist.progress) * scale
        val currY = (fist.startY + (fist.targetY - fist.startY) * fist.progress) * scale
        val angle = fist.angleRad
        val fScale = fist.fistScale * scale
        val alpha = fist.alpha.coerceIn(0.1f, 1f)

        when (fist.style) {
            FistStyle.STAR_PLATINUM_PURPLE -> {
                // Purple/Indigo heavy clenched fists with knuckles and blue speed trails
                drawSculptedFist(
                    pos = Offset(currX, currY),
                    angle = angle,
                    scale = fScale,
                    palmColor = Color(0xFF4338CA).copy(alpha = alpha),
                    knuckleColor = Color(0xFFA855F7).copy(alpha = alpha),
                    trailColor = Color(0xFF6366F1).copy(alpha = alpha * 0.7f),
                    highlightColor = Color(0xFFE0E7FF).copy(alpha = alpha),
                    isImpact = fist.progress >= 0.65f,
                    accentHeart = false
                )
            }
            FistStyle.CRAZY_DIAMOND_PINK -> {
                // Pink / Cyan explosive fists with hearts (Josuke)
                drawSculptedFist(
                    pos = Offset(currX, currY),
                    angle = angle,
                    scale = fScale * 0.95f,
                    palmColor = Color(0xFFBE185D).copy(alpha = alpha),
                    knuckleColor = Color(0xFFF472B6).copy(alpha = alpha),
                    trailColor = Color(0xFF06B6D4).copy(alpha = alpha * 0.7f),
                    highlightColor = Color(0xFFECFEFF).copy(alpha = alpha),
                    isImpact = fist.progress >= 0.65f,
                    accentHeart = true
                )
            }
            FistStyle.THE_WORLD_GOLD -> {
                // Golden yellow aggressive fists (DIO)
                drawSculptedFist(
                    pos = Offset(currX, currY),
                    angle = angle,
                    scale = fScale,
                    palmColor = Color(0xFFB45309).copy(alpha = alpha),
                    knuckleColor = Color(0xFFFACC15).copy(alpha = alpha),
                    trailColor = Color(0xFFFEF08A).copy(alpha = alpha * 0.7f),
                    highlightColor = Color(0xFFFFFFFF).copy(alpha = alpha),
                    isImpact = fist.progress >= 0.65f,
                    accentHeart = false
                )
            }
            FistStyle.CHARIOT_RAPIER -> {
                // Polnareff's visible rapier thrusts (blade, guard, tip, trails)
                drawSculptedRapier(
                    pos = Offset(currX, currY),
                    angle = angle,
                    scale = fScale,
                    alpha = alpha
                )
            }
            FistStyle.STICKY_FINGERS_ZIPPER -> {
                // Bruno's zipper fists
                drawSculptedFist(
                    pos = Offset(currX, currY),
                    angle = angle,
                    scale = fScale,
                    palmColor = Color(0xFF1E3A8A).copy(alpha = alpha),
                    knuckleColor = Color(0xFF3B82F6).copy(alpha = alpha),
                    trailColor = Color(0xFFF59E0B).copy(alpha = alpha * 0.7f),
                    highlightColor = Color(0xFFFDE68A).copy(alpha = alpha),
                    isImpact = fist.progress >= 0.65f,
                    accentHeart = false
                )
            }
            FistStyle.GOLD_EXPERIENCE_YELLOW -> {
                // Gold Experience golden fist with amber and warm glow
                drawSculptedFist(
                    pos = Offset(currX, currY),
                    angle = angle,
                    scale = fScale,
                    palmColor = Color(0xFFD97706).copy(alpha = alpha),
                    knuckleColor = Color(0xFFFDE047).copy(alpha = alpha),
                    trailColor = Color(0xFFF59E0B).copy(alpha = alpha * 0.7f),
                    highlightColor = Color(0xFFFEF08A).copy(alpha = alpha),
                    isImpact = fist.progress >= 0.65f,
                    accentHeart = false
                )
            }
        }
    }
}

private fun DrawScope.drawSculptedFist(
    pos: Offset,
    angle: Float,
    scale: Float,
    palmColor: Color,
    knuckleColor: Color,
    trailColor: Color,
    highlightColor: Color,
    isImpact: Boolean,
    accentHeart: Boolean
) {
    rotate(degrees = (angle * 180f / PI).toFloat(), pivot = pos) {
        // 1. Multiple sharp speed lines trailing behind the punch
        val trailLen = 42f * scale
        val lineOffsets = listOf(-9f, -3f, 3f, 9f)
        for (offY in lineOffsets) {
            drawLine(
                brush = Brush.linearGradient(
                    colors = listOf(Color.Transparent, trailColor),
                    start = Offset(pos.x - trailLen - abs(offY) * 2f * scale, pos.y + offY * scale),
                    end = Offset(pos.x - 4f * scale, pos.y + offY * scale)
                ),
                start = Offset(pos.x - trailLen - abs(offY) * 2f * scale, pos.y + offY * scale),
                end = Offset(pos.x - 4f * scale, pos.y + offY * scale),
                strokeWidth = 2.2f * scale,
                cap = StrokeCap.Round
            )
        }

        // 2. Heavy motion blur body
        drawLine(
            brush = Brush.linearGradient(
                colors = listOf(Color.Transparent, trailColor.copy(alpha = 0.45f)),
                start = Offset(pos.x - trailLen * 0.8f, pos.y),
                end = pos
            ),
            start = Offset(pos.x - trailLen * 0.8f, pos.y),
            end = pos,
            strokeWidth = 16f * scale
        )

        // 3. Wrist forearm segment
        drawRoundRect(
            color = palmColor,
            topLeft = Offset(pos.x - 22f * scale, pos.y - 8f * scale),
            size = Size(16f * scale, 16f * scale),
            cornerRadius = androidx.compose.ui.geometry.CornerRadius(4f * scale)
        )

        // 4. Palm base
        drawOval(
            color = palmColor,
            topLeft = Offset(pos.x - 11f * scale, pos.y - 12f * scale),
            size = Size(22f * scale, 24f * scale)
        )

        // 5. Clenched Knuckles (4 distinct physical finger joints)
        val knuckleYOffsets = listOf(-7.5f, -2.5f, 2.5f, 7.5f)
        for (yOff in knuckleYOffsets) {
            drawCircle(
                color = knuckleColor,
                radius = 4.6f * scale,
                center = Offset(pos.x + 11f * scale, pos.y + yOff * scale)
            )
            // Knuckle highlight reflection
            drawCircle(
                color = highlightColor,
                radius = 1.8f * scale,
                center = Offset(pos.x + 12.5f * scale, pos.y + (yOff - 1.2f) * scale)
            )
        }

        // 6. Thumb folded securely across the fingers
        drawOval(
            color = knuckleColor,
            topLeft = Offset(pos.x + 3f * scale, pos.y + 4f * scale),
            size = Size(8.5f * scale, 10f * scale)
        )

        // Josuke Crazy Diamond Heart Emblem on back of hand
        if (accentHeart) {
            drawCircle(
                color = Color(0xFF06B6D4),
                radius = 3.5f * scale,
                center = Offset(pos.x - 1f * scale, pos.y - 2f * scale)
            )
        }

        // 7. Manga Impact Mark / Flash star when fist reaches target
        if (isImpact) {
            val impactX = pos.x + 18f * scale
            val impactY = pos.y
            // 4-point impact star
            val starSize = 12f * scale
            drawLine(highlightColor, Offset(impactX - starSize, impactY), Offset(impactX + starSize, impactY), 2.5f * scale)
            drawLine(highlightColor, Offset(impactX, impactY - starSize), Offset(impactX, impactY + starSize), 2.5f * scale)
            drawLine(trailColor, Offset(impactX - starSize * 0.7f, impactY - starSize * 0.7f), Offset(impactX + starSize * 0.7f, impactY + starSize * 0.7f), 1.8f * scale)
            drawLine(trailColor, Offset(impactX - starSize * 0.7f, impactY + starSize * 0.7f), Offset(impactX + starSize * 0.7f, impactY - starSize * 0.7f), 1.8f * scale)
        }
    }
}

private fun DrawScope.drawSculptedRapier(
    pos: Offset,
    angle: Float,
    scale: Float,
    alpha: Float = 1.0f
) {
    rotate(degrees = (angle * 180f / PI).toFloat(), pivot = pos) {
        // Silver Chariot Rapier:
        // Motion speed trail
        val trailLen = 52f * scale
        drawLine(
            brush = Brush.linearGradient(
                colors = listOf(Color.Transparent, Color(0xFF38BDF8).copy(alpha = alpha * 0.6f)),
                start = Offset(pos.x - trailLen, pos.y),
                end = pos
            ),
            start = Offset(pos.x - trailLen, pos.y),
            end = pos,
            strokeWidth = 3.5f * scale
        )

        // Rapier Basket Guard (Bell hilt)
        drawArc(
            color = Color(0xFFCBD5E1).copy(alpha = alpha),
            startAngle = 90f,
            sweepAngle = 180f,
            useCenter = false,
            topLeft = Offset(pos.x - 22f * scale, pos.y - 12f * scale),
            size = Size(18f * scale, 24f * scale),
            style = Stroke(width = 3.5f * scale)
        )

        // Metallic Blade
        val bladeLen = 44f * scale
        drawLine(
            color = Color.White.copy(alpha = alpha),
            start = Offset(pos.x - 12f * scale, pos.y),
            end = Offset(pos.x + bladeLen, pos.y),
            strokeWidth = 3f * scale
        )

        // Sharp rapier tip glow & spark
        drawCircle(
            color = Color(0xFF38BDF8).copy(alpha = alpha),
            radius = 3.5f * scale,
            center = Offset(pos.x + bladeLen, pos.y)
        )
        drawCircle(
            color = Color.White.copy(alpha = alpha),
            radius = 1.8f * scale,
            center = Offset(pos.x + bladeLen, pos.y)
        )
    }
}

private fun DrawScope.drawParticles(particles: List<Particle>, scale: Float) {
    for (p in particles) {
        drawCircle(
            color = p.color.copy(alpha = p.alpha),
            radius = p.size * scale,
            center = Offset(p.x * scale, p.y * scale)
        )
    }
}

private fun DrawScope.drawMangaWords(words: List<MangaEffectWord>, scale: Float, textMeasurer: TextMeasurer) {
    for (m in words) {
        val alpha = (1f - (m.life / m.maxLife)).coerceIn(0f, 1f)
        val textResult = textMeasurer.measure(
            text = AnnotatedString(m.word),
            style = TextStyle(
                color = m.color.copy(alpha = alpha),
                fontSize = (15f * scale * m.scale).sp,
                fontWeight = FontWeight.Black,
                fontFamily = FontFamily.SansSerif
            )
        )
        drawText(
            textLayoutResult = textResult,
            topLeft = Offset(m.x * scale - textResult.size.width / 2f, m.y * scale - textResult.size.height / 2f)
        )
    }
}

private fun DrawScope.drawDamagePopups(popups: List<DamagePopup>, scale: Float, textMeasurer: TextMeasurer) {
    for (d in popups) {
        val textResult = textMeasurer.measure(
            text = AnnotatedString(d.text),
            style = TextStyle(
                color = d.color.copy(alpha = d.alpha),
                fontSize = ((if (d.isCrit) 16f else 12f) * scale).sp,
                fontWeight = FontWeight.ExtraBold,
                fontFamily = FontFamily.Monospace
            )
        )
        drawText(
            textLayoutResult = textResult,
            topLeft = Offset(d.x * scale - textResult.size.width / 2f, d.y * scale)
        )
    }
}

private fun DrawScope.drawTimeStopOverlay(
    canvasSize: Float,
    scale: Float,
    owner: FighterState,
    animTime: Float,
    remaining: Float,
    textMeasurer: TextMeasurer
) {
    val ownerCenter = Offset(owner.x * scale, owner.y * scale)
    val arenaCenter = Offset(canvasSize / 2f, canvasSize / 2f)

    // 1. High-contrast monochrome / inverted manga vignette filter
    val pulse = (sin(animTime * 6f) * 0.1f + 0.5f).coerceIn(0.3f, 0.7f)
    drawRect(
        brush = Brush.radialGradient(
            colors = listOf(
                Color.Transparent,
                Color(0x99000000),
                Color(0xE605050A)
            ),
            center = ownerCenter,
            radius = canvasSize * 0.85f
        ),
        size = Size(canvasSize, canvasSize)
    )

    // 2. Large Central Rotating Clock Face with Ticking Gear Hands
    val clockRadius = 180f * scale
    drawCircle(
        color = Color(0x33FFFFFF),
        radius = clockRadius,
        center = arenaCenter,
        style = Stroke(width = 3f * scale)
    )

    // 12 Clock Hour Ticks
    for (i in 0 until 12) {
        val tickAngle = (i * 30.0 * PI / 180.0).toFloat()
        val p1 = Offset(arenaCenter.x + cos(tickAngle) * (clockRadius - 14f * scale), arenaCenter.y + sin(tickAngle) * (clockRadius - 14f * scale))
        val p2 = Offset(arenaCenter.x + cos(tickAngle) * clockRadius, arenaCenter.y + sin(tickAngle) * clockRadius)
        drawLine(
            color = Color.White.copy(alpha = 0.6f),
            start = p1,
            end = p2,
            strokeWidth = 3f * scale
        )
    }

    // Rotating Minute & Hour Hands (Continuously moving for the full 3 seconds!)
    val hourAngle = (animTime * 90f) * (PI.toFloat() / 180f)
    val minuteAngle = (animTime * 360f) * (PI.toFloat() / 180f)
    val secondAngle = (animTime * 720f) * (PI.toFloat() / 180f)

    // Hour Hand
    drawLine(
        color = Color(0xFFFBBF24),
        start = arenaCenter,
        end = Offset(arenaCenter.x + cos(hourAngle) * (clockRadius * 0.55f), arenaCenter.y + sin(hourAngle) * (clockRadius * 0.55f)),
        strokeWidth = 4.5f * scale,
        cap = StrokeCap.Round
    )

    // Minute Hand
    drawLine(
        color = Color.White,
        start = arenaCenter,
        end = Offset(arenaCenter.x + cos(minuteAngle) * (clockRadius * 0.85f), arenaCenter.y + sin(minuteAngle) * (clockRadius * 0.85f)),
        strokeWidth = 3f * scale,
        cap = StrokeCap.Round
    )

    // Second Hand (rapid sweep)
    drawLine(
        color = Color(0xFFEF4444),
        start = arenaCenter,
        end = Offset(arenaCenter.x + cos(secondAngle) * (clockRadius * 0.92f), arenaCenter.y + sin(secondAngle) * (clockRadius * 0.92f)),
        strokeWidth = 1.5f * scale,
        cap = StrokeCap.Round
    )

    drawCircle(color = Color.White, radius = 5f * scale, center = arenaCenter)

    // 3. Rotating Concentric Dial Rings around the Time Stopper
    val ringR = owner.radius * scale * 1.8f
    rotate(degrees = animTime * 120f, pivot = ownerCenter) {
        drawCircle(
            color = Color(0xFFFACC15).copy(alpha = pulse),
            radius = ringR,
            center = ownerCenter,
            style = Stroke(width = 2.5f * scale, pathEffect = PathEffect.dashPathEffect(floatArrayOf(18f * scale, 12f * scale)))
        )
    }

    rotate(degrees = -animTime * 80f, pivot = ownerCenter) {
        drawCircle(
            color = Color.White.copy(alpha = 0.5f),
            radius = ringR * 1.35f,
            center = ownerCenter,
            style = Stroke(width = 1.5f * scale, pathEffect = PathEffect.dashPathEffect(floatArrayOf(12f * scale, 16f * scale)))
        )
    }

    // 4. Moving Inward Speed Lines Converging on Jotaro / DIO
    for (i in 0 until 16) {
        val baseAngle = (i * 22.5f + animTime * 25f) * (PI.toFloat() / 180f)
        val outerDist = canvasSize * 0.65f
        val innerDist = ringR * 1.5f + (sin(animTime * 10f + i) * 15f * scale)
        val pOuter = Offset(ownerCenter.x + cos(baseAngle) * outerDist, ownerCenter.y + sin(baseAngle) * outerDist)
        val pInner = Offset(ownerCenter.x + cos(baseAngle) * innerDist, ownerCenter.y + sin(baseAngle) * innerDist)

        drawLine(
            brush = Brush.linearGradient(
                colors = listOf(Color.Transparent, Color.White.copy(alpha = 0.35f)),
                start = pOuter,
                end = pInner
            ),
            start = pOuter,
            end = pInner,
            strokeWidth = 1.5f * scale
        )
    }

    // 5. Slowly Moving Manga-Style Floating Symbols ("ゴ ゴ ゴ ゴ")
    val symbolPositions = listOf(
        Pair(40f * scale, (canvasSize - 80f * scale) - ((animTime * 35f * scale) % (canvasSize * 0.5f))),
        Pair(canvasSize - 160f * scale, (80f * scale) + ((animTime * 25f * scale) % (canvasSize * 0.5f))),
        Pair(60f * scale, (120f * scale) - ((animTime * 20f * scale) % 100f * scale))
    )

    for (pos in symbolPositions) {
        val kanjiResult = textMeasurer.measure(
            text = AnnotatedString("ゴ ゴ ゴ ゴ"),
            style = TextStyle(
                color = Color.White.copy(alpha = 0.55f),
                fontSize = (26f * scale).sp,
                fontWeight = FontWeight.Black
            )
        )
        drawText(kanjiResult, topLeft = Offset(pos.first, pos.second))
    }

    // 6. Dynamic Animated TIME STOP Banner Top Bar
    val titleText = if (owner.characterId == CharacterId.DIO) "THE WORLD: TIME STOP!" else "STAR PLATINUM: TIME STOP!"
    val bannerResult = textMeasurer.measure(
        text = AnnotatedString("$titleText (${String.format("%.1f", remaining)}s)"),
        style = TextStyle(
            color = if (owner.characterId == CharacterId.DIO) Color(0xFFFACC15) else Color(0xFFA855F7),
            fontSize = (15f * scale).sp,
            fontWeight = FontWeight.Black,
            fontFamily = FontFamily.Monospace
        )
    )
    drawText(
        bannerResult,
        topLeft = Offset((canvasSize - bannerResult.size.width) / 2f, 18f * scale)
    )
}

private fun DrawScope.drawCountdownOverlay(
    canvasSize: Float,
    text: String,
    textMeasurer: TextMeasurer
) {
    // Darken backdrop during countdown
    drawRect(color = Color(0x4D000000), size = Size(canvasSize, canvasSize))

    val isFight = text == "FIGHT!"
    val fontSize = if (isFight) 68.sp else 84.sp
    val textColor = if (isFight) Color(0xFFEF4444) else Color(0xFFFBBF24)

    val layoutResult = textMeasurer.measure(
        text = AnnotatedString(text),
        style = TextStyle(
            color = textColor,
            fontSize = fontSize,
            fontWeight = FontWeight.Black,
            fontFamily = FontFamily.SansSerif
        )
    )

    drawText(
        textLayoutResult = layoutResult,
        topLeft = Offset(
            (canvasSize - layoutResult.size.width) / 2f,
            (canvasSize - layoutResult.size.height) / 2f
        )
    )
}

@OptIn(ExperimentalTextApi::class)
private fun DrawScope.drawStandArrows(
    arrows: List<StandArrow>,
    scale: Float,
    textMeasurer: TextMeasurer
) {
    for (arrow in arrows) {
        val cx = arrow.x * scale
        val cy = arrow.y * scale
        val pulse = sin(arrow.pulseTime * 5f)
        val outerRadius = (32f + pulse * 6f) * scale

        // 1. Golden pulsing aura rings
        drawCircle(
            color = Color(0xFFFBBF24).copy(alpha = (0.22f + pulse * 0.08f).coerceIn(0.1f, 0.4f)),
            radius = outerRadius,
            center = Offset(cx, cy)
        )
        drawCircle(
            color = Color(0xFFF59E0B).copy(alpha = 0.5f),
            radius = 24f * scale,
            center = Offset(cx, cy),
            style = Stroke(width = 2.5f * scale)
        )

        // 2. Stand Arrow Vector (pointed diagonally up-right at 45 degrees)
        rotate(degrees = 45f, pivot = Offset(cx, cy)) {
            val arrowLength = 46f * scale
            val halfLen = arrowLength / 2f

            // Wooden/bronze shaft
            drawLine(
                color = Color(0xFFB45309),
                start = Offset(cx, cy + halfLen),
                end = Offset(cx, cy - halfLen * 0.4f),
                strokeWidth = 4.5f * scale,
                cap = StrokeCap.Round
            )
            // Golden metal highlight on shaft
            drawLine(
                color = Color(0xFFFDE047),
                start = Offset(cx, cy + halfLen * 0.8f),
                end = Offset(cx, cy - halfLen * 0.3f),
                strokeWidth = 2f * scale,
                cap = StrokeCap.Round
            )

            // Stand Arrow Golden Beetle wings ornament
            val wingWidth = 14f * scale
            val wingY = cy - 2f * scale
            val wingPath = Path().apply {
                moveTo(cx, wingY - 8f * scale)
                cubicTo(cx - wingWidth, wingY - 4f * scale, cx - wingWidth, wingY + 8f * scale, cx, wingY + 12f * scale)
                cubicTo(cx + wingWidth, wingY + 8f * scale, cx + wingWidth, wingY - 4f * scale, cx, wingY - 8f * scale)
                close()
            }
            drawPath(wingPath, color = Color(0xFFF59E0B))
            drawPath(wingPath, color = Color(0xFFFEF08A), style = Stroke(width = 1.2f * scale))
            // Central beetle jewel
            drawCircle(
                color = Color(0xFFDC2626),
                radius = 3f * scale,
                center = Offset(cx, wingY + 2f * scale)
            )

            // Broad triangular golden arrowhead
            val headTopY = cy - halfLen
            val headBaseY = cy - halfLen * 0.3f
            val headWidth = 16f * scale
            val headPath = Path().apply {
                moveTo(cx, headTopY)
                lineTo(cx - headWidth, headBaseY)
                lineTo(cx, headBaseY - 3f * scale)
                lineTo(cx + headWidth, headBaseY)
                close()
            }
            drawPath(headPath, color = Color(0xFFFBBF24))
            drawPath(headPath, color = Color.White, style = Stroke(width = 1.2f * scale))
        }

        // Floating label "STAND ARROW"
        val label = textMeasurer.measure(
            text = "STAND ARROW",
            style = TextStyle(
                color = Color(0xFFFDE047),
                fontSize = (8.5f * scale).sp,
                fontWeight = FontWeight.Black,
                fontFamily = FontFamily.Monospace
            )
        )
        drawText(
            textLayoutResult = label,
            topLeft = Offset(cx - label.size.width / 2f, cy + 28f * scale)
        )
    }
}

@OptIn(ExperimentalTextApi::class)
private fun DrawScope.drawStandArrowActivationOverlay(
    canvasSize: Float,
    scale: Float,
    activation: StandArrowActivation,
    fighters: List<FighterState>,
    textMeasurer: TextMeasurer
) {
    // 1. Darken the entire arena for dramatic time freeze
    drawRect(
        color = Color(0xAA000000),
        size = Size(canvasSize, canvasSize)
    )

    val fighter = fighters.find { it.instanceId == activation.fighterInstanceId } ?: return
    val fx = fighter.x * scale
    val fy = fighter.y * scale

    // 2. Converging golden shockwave rings
    val pulseRing = (1f - (activation.timeRemaining % 0.6f) / 0.6f)
    drawCircle(
        color = Color(0xFFFBBF24).copy(alpha = (1f - pulseRing) * 0.7f),
        radius = (fighter.radius + pulseRing * 70f) * scale,
        center = Offset(fx, fy),
        style = Stroke(width = 3.5f * scale)
    )

    // 3. Golden electrical aura rays from fighter
    for (i in 0 until 12) {
        val angle = (i * 30f + activation.timeRemaining * 120f) * (PI.toFloat() / 180f)
        val innerDist = fighter.radius * scale
        val outerDist = (fighter.radius + 40f + sin(activation.timeRemaining * 15f + i) * 15f) * scale
        drawLine(
            color = if (i % 2 == 0) Color(0xFFFDE047) else Color(0xFFF59E0B),
            start = Offset(fx + cos(angle) * innerDist, fy + sin(angle) * innerDist),
            end = Offset(fx + cos(angle) * outerDist, fy + sin(angle) * outerDist),
            strokeWidth = 2.5f * scale,
            cap = StrokeCap.Round
        )
    }

    // 4. Piercing Stand Arrow stabbing directly into the ball body
    val pierceAngle = -35f * (PI.toFloat() / 180f)
    val startX = fx + cos(pierceAngle) * (fighter.radius + 60f) * scale
    val startY = fy + sin(pierceAngle) * (fighter.radius + 60f) * scale
    val pierceDepth = (fighter.radius * 0.35f) * scale
    val tipX = fx + cos(pierceAngle) * (fighter.radius * scale - pierceDepth)
    val tipY = fy + sin(pierceAngle) * (fighter.radius * scale - pierceDepth)

    // Shaft
    drawLine(
        color = Color(0xFFF59E0B),
        start = Offset(startX, startY),
        end = Offset(tipX, tipY),
        strokeWidth = 6f * scale,
        cap = StrokeCap.Round
    )
    drawLine(
        color = Color(0xFFFEF08A),
        start = Offset(startX, startY),
        end = Offset(tipX, tipY),
        strokeWidth = 2.5f * scale,
        cap = StrokeCap.Round
    )

    // Pierce impact explosion sparks
    drawCircle(
        color = Color(0xFFFDE047),
        radius = (14f + sin(activation.timeRemaining * 20f) * 4f) * scale,
        center = Offset(tipX, tipY)
    )
    drawCircle(
        color = Color.White,
        radius = 7f * scale,
        center = Offset(tipX, tipY)
    )

    // 5. Manga text banner across arena
    val headerText = textMeasurer.measure(
        text = "STAND AWAKENING!",
        style = TextStyle(
            color = Color(0xFFFDE047),
            fontSize = (22f * scale).sp,
            fontWeight = FontWeight.Black,
            fontFamily = FontFamily.Monospace,
            letterSpacing = (2.5f * scale).sp
        )
    )
    drawText(
        textLayoutResult = headerText,
        topLeft = Offset((canvasSize - headerText.size.width) / 2f, 90f * scale)
    )

    val subtitle = textMeasurer.measure(
        text = "PIERCED BY THE STAND ARROW",
        style = TextStyle(
            color = Color.White,
            fontSize = (11f * scale).sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace
        )
    )
    drawText(
        textLayoutResult = subtitle,
        topLeft = Offset((canvasSize - subtitle.size.width) / 2f, 125f * scale)
    )
}
