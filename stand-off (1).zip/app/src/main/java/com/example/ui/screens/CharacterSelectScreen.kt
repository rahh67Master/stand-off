package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.audio.SoundSynthesizer
import com.example.model.*

@Composable
fun CharacterSelectScreen(
    initialIs2v2: Boolean,
    onStartBattle: (BattleConfig) -> Unit,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler { onBack() }

    var is2v2 by remember { mutableStateOf(initialIs2v2) }

    // Slots start UNSELECTED (null) - NO AUTOMATIC MATCHUP
    var blueSlot1 by remember { mutableStateOf<CharacterId?>(null) }
    var blueSlot2 by remember { mutableStateOf<CharacterId?>(null) }
    var redSlot1 by remember { mutableStateOf<CharacterId?>(null) }
    var redSlot2 by remember { mutableStateOf<CharacterId?>(null) }

    // Active selection slot:
    // In 1V1: 0 = Blue Slot, 1 = Red Slot
    // In 2V2: 0 = Blue Slot 1, 1 = Blue Slot 2, 2 = Red Slot 1, 3 = Red Slot 2
    var activeSlotIndex by remember { mutableIntStateOf(0) }

    val isAllSelected = if (is2v2) {
        blueSlot1 != null && blueSlot2 != null && redSlot1 != null && redSlot2 != null
    } else {
        blueSlot1 != null && redSlot1 != null
    }

    // 3x3 Character Grid Roster:
    // Row 1: JOTARO, MISTA, JOSUKE
    // Row 2: DIO, POLNAREFF, KAKYOIN
    // Row 3: GIORNO, BRUNO, GYRO
    val gridRows = remember {
        listOf(
            listOf(CharacterId.JOTARO, CharacterId.MISTA, CharacterId.JOSUKE),
            listOf(CharacterId.DIO, CharacterId.POLNAREFF, CharacterId.KAKYOIN),
            listOf(CharacterId.GIORNO, CharacterId.BRUNO, CharacterId.GYRO)
        )
    }

    var inspectingId by remember { mutableStateOf(CharacterId.JOTARO) }
    val inspectingDef = CharacterRegistry.get(inspectingId)

    val currentSlotPrompt = if (!is2v2) {
        when (activeSlotIndex) {
            0 -> if (blueSlot1 == null) "SELECT BLUE FIGHTER" else "REPLACE BLUE FIGHTER"
            else -> if (redSlot1 == null) "SELECT RED FIGHTER" else "REPLACE RED FIGHTER"
        }
    } else {
        when (activeSlotIndex) {
            0 -> if (blueSlot1 == null) "SELECT BLUE SLOT 1" else "REPLACE BLUE SLOT 1"
            1 -> if (blueSlot2 == null) "SELECT BLUE SLOT 2" else "REPLACE BLUE SLOT 2"
            2 -> if (redSlot1 == null) "SELECT RED SLOT 1" else "REPLACE RED SLOT 1"
            else -> if (redSlot2 == null) "SELECT RED SLOT 2" else "REPLACE RED SLOT 2"
        }
    }

    val currentSlotColor = if (!is2v2) {
        if (activeSlotIndex == 0) Color(0xFF38BDF8) else Color(0xFFEF4444)
    } else {
        if (activeSlotIndex <= 1) Color(0xFF38BDF8) else Color(0xFFEF4444)
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(
                        Color(0xFF030712),
                        Color(0xFF0B1120),
                        Color(0xFF020617)
                    )
                )
            )
            .systemBarsPadding()
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 12.dp, vertical = 8.dp)
        ) {
            // 1. TOP HEADER & MODE SWITCHER
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = onBack,
                    modifier = Modifier.testTag("back_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.ArrowBack,
                        contentDescription = "Back",
                        tint = Color.White
                    )
                }

                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = if (is2v2) "2V2 CHARACTER SELECT" else "1V1 CHARACTER SELECT",
                        color = Color.White,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Black,
                        letterSpacing = 1.2.sp
                    )
                    Text(
                        text = currentSlotPrompt,
                        color = currentSlotColor,
                        fontSize = 10.5.sp,
                        fontWeight = FontWeight.ExtraBold,
                        fontFamily = FontFamily.Monospace,
                        maxLines = 1,
                        softWrap = false
                    )
                }

                // 1V1 / 2V2 Toggle
                Row(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color(0xFF1E293B))
                        .padding(2.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(if (!is2v2) Color(0xFF0284C7) else Color.Transparent)
                            .clickable {
                                is2v2 = false
                                activeSlotIndex = if (blueSlot1 == null) 0 else if (redSlot1 == null) 1 else 0
                                SoundSynthesizer.play(SoundType.COUNTDOWN_BEEP)
                            }
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text("1V1", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Black)
                    }

                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(if (is2v2) Color(0xFFDC2626) else Color.Transparent)
                            .clickable {
                                is2v2 = true
                                activeSlotIndex = when {
                                    blueSlot1 == null -> 0
                                    blueSlot2 == null -> 1
                                    redSlot1 == null -> 2
                                    else -> 3
                                }
                                SoundSynthesizer.play(SoundType.COUNTDOWN_BEEP)
                            }
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text("2V2", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Black)
                    }
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            // 2. TEAMS VERSUS DISPLAY (SLOTS)
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .border(1.dp, Color(0xFF334155), RoundedCornerShape(12.dp)),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF0B1120))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Blue Team Column
                    Column(
                        modifier = Modifier.weight(1f),
                        horizontalAlignment = Alignment.Start
                    ) {
                        Text(
                            text = "BLUE TEAM",
                            color = Color(0xFF38BDF8),
                            fontWeight = FontWeight.Black,
                            fontSize = 11.sp
                        )
                        Spacer(modifier = Modifier.height(3.dp))
                        TeamSlotRow(
                            characterId = blueSlot1,
                            isActive = activeSlotIndex == 0,
                            teamColor = Color(0xFF0284C7),
                            label = if (is2v2) "BLUE 1" else "BLUE",
                            onClick = { activeSlotIndex = 0 }
                        )
                        if (is2v2) {
                            Spacer(modifier = Modifier.height(3.dp))
                            TeamSlotRow(
                                characterId = blueSlot2,
                                isActive = activeSlotIndex == 1,
                                teamColor = Color(0xFF0284C7),
                                label = "BLUE 2",
                                onClick = { activeSlotIndex = 1 }
                            )
                        }
                    }

                    // VS Center Emblem
                    Box(
                        modifier = Modifier
                            .padding(horizontal = 8.dp)
                            .clip(CircleShape)
                            .background(Color(0xFF1E293B))
                            .border(1.5.dp, Color(0xFFFBBF24), CircleShape)
                            .padding(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = "VS",
                            color = Color(0xFFFBBF24),
                            fontWeight = FontWeight.Black,
                            fontSize = 15.sp
                        )
                    }

                    // Red Team Column
                    Column(
                        modifier = Modifier.weight(1f),
                        horizontalAlignment = Alignment.End
                    ) {
                        Text(
                            text = "RED TEAM",
                            color = Color(0xFFEF4444),
                            fontWeight = FontWeight.Black,
                            fontSize = 11.sp
                        )
                        Spacer(modifier = Modifier.height(3.dp))
                        TeamSlotRow(
                            characterId = redSlot1,
                            isActive = activeSlotIndex == (if (is2v2) 2 else 1),
                            teamColor = Color(0xFFDC2626),
                            label = if (is2v2) "RED 1" else "RED",
                            onClick = { activeSlotIndex = if (is2v2) 2 else 1 }
                        )
                        if (is2v2) {
                            Spacer(modifier = Modifier.height(3.dp))
                            TeamSlotRow(
                                characterId = redSlot2,
                                isActive = activeSlotIndex == 3,
                                teamColor = Color(0xFFDC2626),
                                label = "RED 2",
                                onClick = { activeSlotIndex = 3 }
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // 3. 3x3 CHARACTER GRID (ALWAYS HORIZONTAL NAMES, NEVER SQUEEZED)
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                for (row in gridRows) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        for (charId in row) {
                            val def = CharacterRegistry.get(charId)
                            val isBlueP1 = blueSlot1 == charId
                            val isBlueP2 = is2v2 && blueSlot2 == charId
                            val isRedP1 = redSlot1 == charId
                            val isRedP2 = is2v2 && redSlot2 == charId
                            val isInspecting = inspectingId == charId

                            Box(modifier = Modifier.weight(1f)) {
                                CharacterGridTile(
                                    character = def,
                                    isBlueP1 = isBlueP1,
                                    isBlueP2 = isBlueP2,
                                    isRedP1 = isRedP1,
                                    isRedP2 = isRedP2,
                                    isInspecting = isInspecting,
                                    onClick = {
                                        inspectingId = charId
                                        SoundSynthesizer.play(SoundType.COUNTDOWN_BEEP)

                                        // Assign to active slot and advance cursor to next unfilled slot
                                        if (!is2v2) {
                                            if (activeSlotIndex == 0) {
                                                blueSlot1 = charId
                                                if (redSlot1 == null) activeSlotIndex = 1
                                            } else {
                                                redSlot1 = charId
                                                if (blueSlot1 == null) activeSlotIndex = 0
                                            }
                                        } else {
                                            when (activeSlotIndex) {
                                                0 -> {
                                                    blueSlot1 = charId
                                                    if (blueSlot2 == null) activeSlotIndex = 1
                                                    else if (redSlot1 == null) activeSlotIndex = 2
                                                    else if (redSlot2 == null) activeSlotIndex = 3
                                                }
                                                1 -> {
                                                    blueSlot2 = charId
                                                    if (redSlot1 == null) activeSlotIndex = 2
                                                    else if (redSlot2 == null) activeSlotIndex = 3
                                                    else if (blueSlot1 == null) activeSlotIndex = 0
                                                }
                                                2 -> {
                                                    redSlot1 = charId
                                                    if (redSlot2 == null) activeSlotIndex = 3
                                                    else if (blueSlot1 == null) activeSlotIndex = 0
                                                    else if (blueSlot2 == null) activeSlotIndex = 1
                                                }
                                                3 -> {
                                                    redSlot2 = charId
                                                    if (blueSlot1 == null) activeSlotIndex = 0
                                                    else if (blueSlot2 == null) activeSlotIndex = 1
                                                    else if (redSlot1 == null) activeSlotIndex = 2
                                                }
                                            }
                                        }
                                    }
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // 4. CHARACTER INFORMATION PANEL
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .border(1.dp, Color(0xFF334155), RoundedCornerShape(10.dp)),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A))
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 10.dp, vertical = 8.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = inspectingDef.id.displayName,
                                color = Color.White,
                                fontWeight = FontWeight.Black,
                                fontSize = 15.sp,
                                maxLines = 1,
                                softWrap = false
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = inspectingDef.id.japaneseName,
                                color = Color(0xFF94A3B8),
                                fontSize = 12.sp,
                                maxLines = 1,
                                softWrap = false
                            )
                        }

                        Text(
                            text = "Speed: ${inspectingDef.baseSpeed.toInt()}",
                            color = Color(0xFF38BDF8),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }

                    Spacer(modifier = Modifier.height(2.dp))

                    Text(
                        text = "Stand: ${inspectingDef.id.standName} • ${inspectingDef.id.title}",
                        color = Color(0xFFFBBF24),
                        fontSize = 11.5.sp,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        softWrap = false
                    )

                    Spacer(modifier = Modifier.height(2.dp))

                    Text(
                        text = "Rage (${inspectingDef.rageDuration.toInt()}s): ${inspectingDef.rageName} - ${inspectingDef.rageDescription}",
                        color = Color(0xFFCBD5E1),
                        fontSize = 10.5.sp,
                        lineHeight = 14.sp,
                        maxLines = 3,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // 5. START SIMULATION BUTTON (ENABLED ONLY WHEN ALL SLOTS FILLED)
            val buttonText = when {
                isAllSelected -> "START SIMULATION"
                !is2v2 -> {
                    when {
                        blueSlot1 == null && redSlot1 == null -> "SELECT BLUE & RED FIGHTERS"
                        blueSlot1 == null -> "SELECT BLUE FIGHTER"
                        else -> "SELECT RED FIGHTER"
                    }
                }
                else -> {
                    val count = listOfNotNull(blueSlot1, blueSlot2, redSlot1, redSlot2).size
                    "SELECT ALL 4 FIGHTERS ($count/4)"
                }
            }

            Button(
                onClick = {
                    if (isAllSelected) {
                        SoundSynthesizer.play(SoundType.FIGHT_BELL)
                        val config = BattleConfig(
                            isTwoVsTwo = is2v2,
                            blueTeam = if (is2v2) listOfNotNull(blueSlot1, blueSlot2) else listOfNotNull(blueSlot1),
                            redTeam = if (is2v2) listOfNotNull(redSlot1, redSlot2) else listOfNotNull(redSlot1),
                            battleInstanceId = System.currentTimeMillis()
                        )
                        onStartBattle(config)
                    }
                },
                enabled = isAllSelected,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
                    .shadow(if (isAllSelected) 10.dp else 0.dp, RoundedCornerShape(8.dp))
                    .testTag("start_simulation_button"),
                shape = RoundedCornerShape(8.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFFDC2626),
                    disabledContainerColor = Color(0xFF1E293B)
                )
            ) {
                Icon(
                    imageVector = Icons.Default.PlayArrow,
                    contentDescription = null,
                    tint = if (isAllSelected) Color.White else Color(0xFF64748B),
                    modifier = Modifier.size(22.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = buttonText,
                    color = if (isAllSelected) Color.White else Color(0xFF94A3B8),
                    fontWeight = FontWeight.Black,
                    fontSize = 15.sp,
                    letterSpacing = 1.sp
                )
            }

            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}

@Composable
private fun TeamSlotRow(
    characterId: CharacterId?,
    isActive: Boolean,
    teamColor: Color,
    label: String,
    onClick: () -> Unit
) {
    val charName = characterId?.displayName ?: "TAP TO SELECT"
    val isFilled = characterId != null
    val borderCol = if (isActive) Color(0xFFFBBF24) else if (isFilled) teamColor else Color(0xFF334155)

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(30.dp)
            .clip(RoundedCornerShape(6.dp))
            .background(if (isActive) Color(0xFF1E293B) else Color(0xFF0F172A))
            .border(if (isActive) 1.5.dp else 1.dp, borderCol, RoundedCornerShape(6.dp))
            .clickable { onClick() }
            .padding(horizontal = 6.dp),
        contentAlignment = Alignment.CenterStart
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.fillMaxWidth()
        ) {
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(3.dp))
                    .background(if (isFilled) teamColor else Color(0xFF334155))
                    .padding(horizontal = 4.dp, vertical = 1.dp)
            ) {
                Text(
                    text = label,
                    color = Color.White,
                    fontSize = 8.sp,
                    fontWeight = FontWeight.Black,
                    maxLines = 1,
                    softWrap = false
                )
            }
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = charName,
                color = if (isFilled) Color.White else Color(0xFF64748B),
                fontSize = 11.sp,
                fontWeight = if (isFilled) FontWeight.Black else FontWeight.Bold,
                maxLines = 1,
                softWrap = false,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
private fun CharacterGridTile(
    character: CharacterDef,
    isBlueP1: Boolean,
    isBlueP2: Boolean,
    isRedP1: Boolean,
    isRedP2: Boolean,
    isInspecting: Boolean,
    onClick: () -> Unit
) {
    val isBlue = isBlueP1 || isBlueP2
    val isRed = isRedP1 || isRedP2

    val borderColor = when {
        isBlue && isRed -> Color(0xFFA855F7)
        isBlue -> Color(0xFF38BDF8)
        isRed -> Color(0xFFEF4444)
        isInspecting -> Color(0xFFFBBF24)
        else -> Color(0xFF334155)
    }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(110.dp)
            .clip(RoundedCornerShape(10.dp))
            .background(
                Brush.verticalGradient(
                    listOf(
                        character.secondaryColor.copy(alpha = 0.35f),
                        character.primaryColor.copy(alpha = 0.85f),
                        Color(0xFF0B1120)
                    )
                )
            )
            .border(
                width = if (isBlue || isRed || isInspecting) 2.dp else 1.dp,
                color = borderColor,
                shape = RoundedCornerShape(10.dp)
            )
            .clickable { onClick() }
            .padding(horizontal = 4.dp, vertical = 4.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.SpaceBetween,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Badges row: BLUE ✓ / RED ✓ indicators
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(15.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (isBlue) {
                    val blueLabel = when {
                        isBlueP1 && isBlueP2 -> "BLUE 1+2 ✓"
                        isBlueP1 -> "BLUE 1 ✓"
                        else -> "BLUE 2 ✓"
                    }
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(3.dp))
                            .background(Color(0xFF0284C7))
                            .padding(horizontal = 3.dp, vertical = 1.dp)
                    ) {
                        Text(blueLabel, color = Color.White, fontSize = 7.5.sp, fontWeight = FontWeight.Black)
                    }
                } else {
                    Spacer(modifier = Modifier.width(1.dp))
                }

                if (isRed) {
                    val redLabel = when {
                        isRedP1 && isRedP2 -> "RED 1+2 ✓"
                        isRedP1 -> "RED 1 ✓"
                        else -> "RED 2 ✓"
                    }
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(3.dp))
                            .background(Color(0xFFDC2626))
                            .padding(horizontal = 3.dp, vertical = 1.dp)
                    ) {
                        Text(redLabel, color = Color.White, fontSize = 7.5.sp, fontWeight = FontWeight.Black)
                    }
                }
            }

            // Stylized Circular Avatar Emblem
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(character.secondaryColor)
                    .border(1.5.dp, character.accentColor, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = character.id.displayName.take(2),
                    color = Color.White,
                    fontWeight = FontWeight.Black,
                    fontSize = 13.sp
                )
            }

            // Character Name & Stand Name: STRICTLY HORIZONTAL TEXT, NEVER SQUEEZED VERTICALLY
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = character.id.displayName,
                    color = Color.White,
                    fontWeight = FontWeight.Black,
                    fontSize = 11.5.sp,
                    maxLines = 1,
                    softWrap = false,
                    overflow = TextOverflow.Ellipsis,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )
                Text(
                    text = character.id.standName,
                    color = Color(0xFF94A3B8),
                    fontSize = 8.5.sp,
                    maxLines = 1,
                    softWrap = false,
                    overflow = TextOverflow.Ellipsis,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }
    }
}
