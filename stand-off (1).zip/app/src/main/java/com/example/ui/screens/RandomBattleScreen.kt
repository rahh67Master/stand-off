package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Casino
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.audio.SoundSynthesizer
import com.example.model.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.random.Random

@Composable
fun RandomBattleScreen(
    initialIs2v2: Boolean = false,
    onStartBattle: (BattleConfig) -> Unit,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler { onBack() }

    var is2v2 by remember { mutableStateOf(initialIs2v2) }
    val allCharacters = remember { CharacterId.values().toList() }

    // Slots
    var blue1 by remember { mutableStateOf(allCharacters.random()) }
    var blue2 by remember { mutableStateOf(allCharacters.random()) }
    var red1 by remember { mutableStateOf(allCharacters.random()) }
    var red2 by remember { mutableStateOf(allCharacters.random()) }

    var isSpinning by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    // Spin function: cycles rapidly through fighters and locks them in independently
    fun spinSlots() {
        if (isSpinning) return
        isSpinning = true
        scope.launch {
            SoundSynthesizer.play(SoundType.COUNTDOWN_BEEP)

            // Slot 1: Blue 1 (finishes first ~ 0.5s)
            launch {
                var stepDelay = 50L
                for (i in 0 until 10) {
                    blue1 = allCharacters.random()
                    delay(stepDelay)
                    stepDelay = (stepDelay * 1.15f).toLong()
                }
                blue1 = allCharacters.random()
                SoundSynthesizer.play(SoundType.BALL_BOUNCE)
            }

            // Slot 2: Blue 2 (if 2v2, finishes ~ 0.8s)
            if (is2v2) {
                launch {
                    var stepDelay = 50L
                    for (i in 0 until 14) {
                        blue2 = allCharacters.random()
                        delay(stepDelay)
                        stepDelay = (stepDelay * 1.12f).toLong()
                    }
                    blue2 = allCharacters.random()
                    SoundSynthesizer.play(SoundType.BALL_BOUNCE)
                }
            }

            // Slot 3: Red 1 (finishes ~ 0.95s)
            launch {
                var stepDelay = 50L
                val steps = if (is2v2) 16 else 14
                for (i in 0 until steps) {
                    red1 = allCharacters.random()
                    delay(stepDelay)
                    stepDelay = (stepDelay * 1.12f).toLong()
                }
                red1 = allCharacters.random()
                SoundSynthesizer.play(SoundType.BALL_BOUNCE)
            }

            // Slot 4: Red 2 (if 2v2, finishes ~ 1.2s)
            if (is2v2) {
                launch {
                    var stepDelay = 50L
                    for (i in 0 until 18) {
                        red2 = allCharacters.random()
                        delay(stepDelay)
                        stepDelay = (stepDelay * 1.12f).toLong()
                    }
                    red2 = allCharacters.random()
                    SoundSynthesizer.play(SoundType.BALL_BOUNCE)
                }
            }

            delay(if (is2v2) 1300L else 900L)
            SoundSynthesizer.play(SoundType.FIGHT_BELL)
            isSpinning = false
        }
    }

    // Auto spin once on first entry
    LaunchedEffect(Unit) {
        spinSlots()
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(
                        Color(0xFF030712),
                        Color(0xFF0F172A),
                        Color(0xFF020617)
                    )
                )
            )
            .systemBarsPadding()
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 10.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // TOP BAR
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = onBack,
                    modifier = Modifier.testTag("random_back_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.ArrowBack,
                        contentDescription = "Back",
                        tint = Color.White
                    )
                }

                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = "RANDOM BATTLE",
                        color = Color.White,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Black,
                        letterSpacing = 1.2.sp
                    )
                    Text(
                        text = if (isSpinning) "GENERATING MATCHUP..." else "MATCHUP READY",
                        color = if (isSpinning) Color(0xFFFBBF24) else Color(0xFF10B981),
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }

                // 1V1 / 2V2 Mode Toggle
                Row(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color(0xFF1E293B))
                        .padding(2.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(if (!is2v2) Color(0xFF0284C7) else Color.Transparent)
                            .clickable {
                                if (!isSpinning && is2v2) {
                                    is2v2 = false
                                    spinSlots()
                                }
                            }
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text("1V1", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Black)
                    }

                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(if (is2v2) Color(0xFFDC2626) else Color.Transparent)
                            .clickable {
                                if (!isSpinning && !is2v2) {
                                    is2v2 = true
                                    spinSlots()
                                }
                            }
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text("2V2", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Black)
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // RE-SPIN BUTTON
            OutlinedButton(
                onClick = { spinSlots() },
                enabled = !isSpinning,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(44.dp)
                    .testTag("respin_button"),
                colors = ButtonDefaults.outlinedButtonColors(
                    containerColor = Color(0xFF1E293B).copy(alpha = 0.8f),
                    contentColor = Color(0xFFFBBF24)
                ),
                border = ButtonDefaults.outlinedButtonBorder.copy(
                    brush = Brush.horizontalGradient(listOf(Color(0xFF38BDF8), Color(0xFFEF4444)))
                ),
                shape = RoundedCornerShape(10.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Refresh,
                    contentDescription = null,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = if (isSpinning) "SPINNING FIGHTERS..." else "RE-ROLL MATCHUP",
                    fontWeight = FontWeight.Black,
                    fontSize = 13.sp,
                    letterSpacing = 1.sp
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // BLUE TEAM SECTION
            RandomTeamSection(
                teamName = "BLUE TEAM",
                teamColor = Color(0xFF0284C7),
                accentColor = Color(0xFF38BDF8),
                characters = if (is2v2) listOf(blue1, blue2) else listOf(blue1)
            )

            Spacer(modifier = Modifier.height(12.dp))

            // VS BANNER
            Box(
                modifier = Modifier
                    .clip(CircleShape)
                    .background(Color(0xFF1E293B))
                    .border(2.dp, Color(0xFFFBBF24), CircleShape)
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "VS",
                    color = Color(0xFFFBBF24),
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Black
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // RED TEAM SECTION
            RandomTeamSection(
                teamName = "RED TEAM",
                teamColor = Color(0xFFDC2626),
                accentColor = Color(0xFFEF4444),
                characters = if (is2v2) listOf(red1, red2) else listOf(red1)
            )

            Spacer(modifier = Modifier.height(20.dp))

            // START RANDOM BATTLE BUTTON
            Button(
                onClick = {
                    SoundSynthesizer.play(SoundType.FIGHT_BELL)
                    val config = BattleConfig(
                        isTwoVsTwo = is2v2,
                        blueTeam = if (is2v2) listOf(blue1, blue2) else listOf(blue1),
                        redTeam = if (is2v2) listOf(red1, red2) else listOf(red1),
                        battleInstanceId = System.currentTimeMillis()
                    )
                    onStartBattle(config)
                },
                enabled = !isSpinning,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(54.dp)
                    .shadow(12.dp, RoundedCornerShape(10.dp))
                    .testTag("start_random_battle_button"),
                shape = RoundedCornerShape(10.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFFDC2626),
                    disabledContainerColor = Color(0xFF334155)
                )
            ) {
                Icon(
                    imageVector = Icons.Default.PlayArrow,
                    contentDescription = null,
                    tint = Color.White,
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = if (isSpinning) "PREPARING BATTLE..." else "START RANDOM BATTLE",
                    color = Color.White,
                    fontWeight = FontWeight.Black,
                    fontSize = 16.sp,
                    letterSpacing = 1.sp
                )
            }

            Spacer(modifier = Modifier.height(20.dp))
        }
    }
}

@Composable
private fun RandomTeamSection(
    teamName: String,
    teamColor: Color,
    accentColor: Color,
    characters: List<CharacterId>
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .border(1.5.dp, accentColor.copy(alpha = 0.7f), RoundedCornerShape(14.dp)),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(teamColor)
                        .padding(horizontal = 8.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = teamName,
                        color = Color.White,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Black
                    )
                }

                Text(
                    text = "${characters.size} FIGHTER${if (characters.size > 1) "S" else ""}",
                    color = Color(0xFF94A3B8),
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                characters.forEachIndexed { index, charId ->
                    RandomFighterCard(
                        slotNumber = index + 1,
                        charId = charId,
                        accentColor = accentColor
                    )
                }
            }
        }
    }
}

@Composable
private fun RandomFighterCard(
    slotNumber: Int,
    charId: CharacterId,
    accentColor: Color
) {
    val def = CharacterRegistry.get(charId)

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .border(1.dp, Color(0xFF334155), RoundedCornerShape(10.dp)),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Slot tag
            Box(
                modifier = Modifier
                    .size(24.dp)
                    .clip(CircleShape)
                    .background(Color(0xFF0F172A))
                    .border(1.dp, accentColor, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "$slotNumber",
                    color = Color.White,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Black
                )
            }

            Spacer(modifier = Modifier.width(10.dp))

            // Character Icon Avatar
            Box(
                modifier = Modifier
                    .size(42.dp)
                    .clip(CircleShape)
                    .background(def.secondaryColor)
                    .border(1.5.dp, def.accentColor, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = def.id.displayName.take(2),
                    color = Color.White,
                    fontWeight = FontWeight.Black,
                    fontSize = 14.sp
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            // Character Info: ALWAYS HORIZONTAL
            Column(modifier = Modifier.weight(1f)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = def.id.displayName,
                        color = Color.White,
                        fontWeight = FontWeight.Black,
                        fontSize = 15.sp,
                        maxLines = 1,
                        softWrap = false,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = "SPD: ${def.baseSpeed.toInt()}",
                        color = Color(0xFF38BDF8),
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    )
                }

                Spacer(modifier = Modifier.height(2.dp))

                Text(
                    text = "STAND: ${def.id.standName}",
                    color = Color(0xFFFBBF24),
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    softWrap = false,
                    overflow = TextOverflow.Ellipsis
                )

                Text(
                    text = def.rageName,
                    color = Color(0xFF94A3B8),
                    fontSize = 10.sp,
                    maxLines = 1,
                    softWrap = false,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}
