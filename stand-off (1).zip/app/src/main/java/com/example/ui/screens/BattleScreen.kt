package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.audio.SoundSynthesizer
import com.example.audio.ThemeMusicManager
import com.example.model.*
import com.example.simulation.BattleSimulator
import com.example.ui.components.ArenaCanvas
import kotlinx.coroutines.isActive

@Composable
fun BattleScreen(
    config: BattleConfig,
    onBackToSelect: () -> Unit,
    onBackToMenu: () -> Unit,
    onNextPrediction: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    BackHandler {
        ThemeMusicManager.stopAndReset()
        onBackToMenu()
    }

    val simulator = remember(config.battleInstanceId) { BattleSimulator(config) }
    val textMeasurer = rememberTextMeasurer()
    val currentPhase by simulator.phaseState

    // Connect Stand Arrow theme music callbacks and lifecycle cleanup
    DisposableEffect(simulator) {
        simulator.onPlayTheme = { characterId ->
            ThemeMusicManager.playTheme(context, characterId)
        }
        simulator.onStopTheme = {
            ThemeMusicManager.stopAndReset()
        }
        onDispose {
            ThemeMusicManager.stopAndReset()
            ThemeMusicManager.release()
        }
    }

    var isPaused by remember { mutableStateOf(false) }
    var speedMultiplier by remember { mutableFloatStateOf(1.0f) }

    // Synchronize pause and resume with theme music playback
    LaunchedEffect(isPaused) {
        if (isPaused) {
            ThemeMusicManager.pause()
        } else {
            ThemeMusicManager.resume()
        }
    }

    // Android Choreographer VSYNC-aligned simulation loop (smooth, guaranteed non-stalling 60fps)
    LaunchedEffect(simulator, isPaused, speedMultiplier) {
        var lastTimeNanos = 0L
        while (isActive) {
            withFrameNanos { frameTimeNanos ->
                if (lastTimeNanos != 0L) {
                    val elapsedSeconds = (frameTimeNanos - lastTimeNanos) / 1_000_000_000f
                    if (!isPaused) {
                        val dt = (elapsedSeconds * speedMultiplier).coerceIn(0.005f, 0.05f)
                        simulator.update(dt)
                    }
                }
                lastTimeNanos = frameTimeNanos
            }
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF030712))
            .systemBarsPadding()
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 12.dp, vertical = 8.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // 1. TOP HUD (Blue vs Red Fighters HP & Rage)
            TopBattleHud(
                simulator = simulator,
                isPaused = isPaused,
                speedMultiplier = speedMultiplier,
                onTogglePause = { isPaused = !isPaused },
                onCycleSpeed = {
                    speedMultiplier = when (speedMultiplier) {
                        1.0f -> 1.5f
                        1.5f -> 2.0f
                        else -> 1.0f
                    }
                },
                onExit = {
                    ThemeMusicManager.stopAndReset()
                    onBackToMenu()
                }
            )

            // Prediction HUD indicator
            val pred = config.predictionConfig
            if (pred != null) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 2.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color(0xFF1E293B).copy(alpha = 0.85f))
                        .border(
                            1.dp,
                            if (pred.predictedTeam == Team.BLUE) Color(0xFF0284C7) else Color(0xFFDC2626),
                            RoundedCornerShape(8.dp)
                        )
                        .padding(horizontal = 10.dp, vertical = 4.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "PREDICTION: ${if (pred.predictedTeam == Team.BLUE) "🔵 BLUE TEAM" else "🔴 RED TEAM"} • TIER: ${pred.tier.displayName}",
                        color = Color.White,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Black,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }

            // 2. Active Time Stop Notice Banner
            if (simulator.activeTimeStopOwner != null) {
                TimeStopBanner(
                    owner = simulator.activeTimeStopOwner!!,
                    remaining = simulator.timeStopRemaining
                )
            }

            // 3. PERFECT SQUARE ARENA (1:1 Ratio, Fixed Camera)
            Box(
                modifier = Modifier
                    .weight(1f)
                    .aspectRatio(1f)
                    .padding(vertical = 4.dp),
                contentAlignment = Alignment.Center
            ) {
                ArenaCanvas(
                    simulator = simulator,
                    tick = 0L,
                    textMeasurer = textMeasurer,
                    modifier = Modifier
                        .fillMaxSize()
                        .shadow(16.dp, RoundedCornerShape(8.dp))
                )
            }

            // 4. BOTTOM STATUS BAR / CONTROLS HINT
            BottomBattleStatus(simulator = simulator)
        }

        // 5. VICTORY OVERLAY (Only displayed AFTER death animation + victory delay)
        if (currentPhase == BattlePhase.VICTORY_SCREEN) {
            VictoryOverlay(
                simulator = simulator,
                config = config,
                onRematch = {
                    ThemeMusicManager.stopAndReset()
                    simulator.restart()
                },
                onSelectFighters = {
                    ThemeMusicManager.stopAndReset()
                    onBackToSelect()
                },
                onMainMenu = {
                    ThemeMusicManager.stopAndReset()
                    onBackToMenu()
                },
                onNextPrediction = {
                    ThemeMusicManager.stopAndReset()
                    onNextPrediction?.invoke()
                }
            )
        }
    }
}

@Composable
private fun TopBattleHud(
    simulator: BattleSimulator,
    isPaused: Boolean,
    speedMultiplier: Float,
    onTogglePause: () -> Unit,
    onCycleSpeed: () -> Unit,
    onExit: () -> Unit
) {
    val blueFighters = simulator.fighters.filter { it.team == Team.BLUE }
    val redFighters = simulator.fighters.filter { it.team == Team.RED }
    @Suppress("UNUSED_VARIABLE")
    val currentFrame = simulator.frameTick.value

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(Color(0xFF0F172A).copy(alpha = 0.95f))
            .border(1.dp, Color(0xFF334155), RoundedCornerShape(12.dp))
            .padding(8.dp)
    ) {
        // Control Bar Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = if (simulator.config.isTwoVsTwo) "2V2 SIMULATION" else "1V1 SIMULATION",
                color = Color(0xFFFBBF24),
                fontWeight = FontWeight.Black,
                fontSize = 12.sp,
                fontFamily = FontFamily.Monospace
            )

            Row(verticalAlignment = Alignment.CenterVertically) {
                // Speed Button
                OutlinedButton(
                    onClick = onCycleSpeed,
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                    modifier = Modifier
                        .height(30.dp)
                        .testTag("speed_button")
                ) {
                    Text(
                        text = "${speedMultiplier}x",
                        color = Color.White,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Spacer(modifier = Modifier.width(6.dp))

                // Pause Button
                IconButton(
                    onClick = onTogglePause,
                    modifier = Modifier
                        .size(30.dp)
                        .testTag("pause_button")
                ) {
                    Icon(
                        imageVector = if (isPaused) Icons.Default.PlayArrow else Icons.Default.Pause,
                        contentDescription = if (isPaused) "Resume" else "Pause",
                        tint = Color.White,
                        modifier = Modifier.size(18.dp)
                    )
                }

                Spacer(modifier = Modifier.width(6.dp))

                // Exit Button
                IconButton(
                    onClick = onExit,
                    modifier = Modifier
                        .size(30.dp)
                        .testTag("exit_battle_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Exit to Menu",
                        tint = Color(0xFF94A3B8),
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(4.dp))

        // Teams Real-time Health Display
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // Blue Team
            Column(modifier = Modifier.weight(1f)) {
                for (f in blueFighters) {
                    FighterHudRow(
                        fighter = f,
                        isLeft = true
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                }
            }

            // VS center tag
            Box(
                modifier = Modifier
                    .padding(horizontal = 8.dp)
                    .align(Alignment.CenterVertically)
            ) {
                Text(
                    text = "VS",
                    color = Color(0xFF94A3B8),
                    fontWeight = FontWeight.Black,
                    fontSize = 14.sp
                )
            }

            // Red Team
            Column(modifier = Modifier.weight(1f)) {
                for (f in redFighters) {
                    FighterHudRow(
                        fighter = f,
                        isLeft = false
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                }
            }
        }
    }
}

@Composable
private fun FighterHudRow(
    fighter: FighterState,
    isLeft: Boolean
) {
    val def = CharacterRegistry.get(fighter.characterId)
    val hp = fighter.hp
    val maxHp = fighter.maxHp
    val rage = fighter.rage
    val isDead = fighter.isDefeated
    val hpPct = (hp / maxHp).coerceIn(0f, 1f)
    val ragePct = (rage / fighter.maxRage).coerceIn(0f, 1f)

    Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = if (isLeft) Alignment.Start else Alignment.End
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = if (isLeft) Arrangement.Start else Arrangement.End,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = def.id.displayName + if (isDead) " (KO)" else "",
                color = if (isDead) Color(0xFFEF4444) else if (isLeft) Color(0xFF38BDF8) else Color(0xFFEF4444),
                fontWeight = FontWeight.Black,
                fontSize = 11.sp,
                fontFamily = FontFamily.SansSerif,
                maxLines = 1
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = "${hp.toInt()} / ${maxHp.toInt()}",
                color = Color.White,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace
            )
        }

        Spacer(modifier = Modifier.height(3.dp))

        // Health Bar (Shrinks immediately with actual HP value)
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(9.dp)
                .clip(RoundedCornerShape(4.dp))
                .background(Color(0xFF1E293B))
                .border(0.5.dp, Color(0xFF475569), RoundedCornerShape(4.dp))
        ) {
            if (hpPct > 0f) {
                Box(
                    modifier = Modifier
                        .fillMaxHeight()
                        .fillMaxWidth(fraction = hpPct)
                        .clip(RoundedCornerShape(4.dp))
                        .background(
                            Brush.horizontalGradient(
                                listOf(
                                    when {
                                        hpPct > 0.5f -> Color(0xFF22C55E)
                                        hpPct > 0.25f -> Color(0xFFF59E0B)
                                        else -> Color(0xFFEF4444)
                                    },
                                    when {
                                        hpPct > 0.5f -> Color(0xFF16A34A)
                                        hpPct > 0.25f -> Color(0xFFD97706)
                                        else -> Color(0xFFDC2626)
                                    }
                                )
                            )
                        )
                )
            }
        }

        Spacer(modifier = Modifier.height(2.dp))

        // Rage Bar
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(4.dp)
                .clip(RoundedCornerShape(2.dp))
                .background(Color(0xFF1E293B))
        ) {
            if (ragePct > 0f) {
                Box(
                    modifier = Modifier
                        .fillMaxHeight()
                        .fillMaxWidth(fraction = ragePct)
                        .clip(RoundedCornerShape(2.dp))
                        .background(
                            if (fighter.isRageActive) Color(0xFFA855F7) else Color(0xFFFBBF24)
                        )
                )
            }
        }
    }
}

@Composable
private fun TimeStopBanner(owner: FighterState, remaining: Float) {
    val def = CharacterRegistry.get(owner.characterId)
    val color = if (owner.characterId == CharacterId.DIO) Color(0xFFFACC15) else Color(0xFFA855F7)

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(color.copy(alpha = 0.2f))
            .border(1.5.dp, color, RoundedCornerShape(8.dp))
            .padding(horizontal = 12.dp, vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                imageVector = Icons.Default.Lock,
                contentDescription = "Time Stop",
                tint = color,
                modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = "${def.id.displayName}: TIME STOP ACTIVE",
                color = Color.White,
                fontWeight = FontWeight.Black,
                fontSize = 12.sp
            )
        }

        Text(
            text = String.format("%.1fs", remaining),
            color = color,
            fontWeight = FontWeight.ExtraBold,
            fontSize = 14.sp,
            fontFamily = FontFamily.Monospace
        )
    }
}

@Composable
private fun BottomBattleStatus(simulator: BattleSimulator) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(Color(0xFF0F172A).copy(alpha = 0.8f))
            .padding(horizontal = 12.dp, vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = "STAND-OFF SIMULATOR",
            color = Color(0xFF94A3B8),
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace
        )
        Text(
            text = "AUTONOMOUS COMBAT",
            color = Color(0xFF38BDF8),
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold
        )
    }
}

@Composable
private fun VictoryOverlay(
    simulator: BattleSimulator,
    config: BattleConfig,
    onRematch: () -> Unit,
    onSelectFighters: () -> Unit,
    onMainMenu: () -> Unit,
    onNextPrediction: (() -> Unit)? = null
) {
    val winnerTeam = simulator.winnerTeam ?: Team.BLUE
    val isBlue = winnerTeam == Team.BLUE
    val bannerColor = if (isBlue) Color(0xFF0284C7) else Color(0xFFDC2626)
    val teamTitle = if (isBlue) "BLUE TEAM WINS!" else "RED TEAM WINS!"

    val pred = config.predictionConfig
    val isPredictionMode = pred != null
    val isCorrect = isPredictionMode && winnerTeam == pred.predictedTeam

    // Settle prediction balance once
    LaunchedEffect(simulator.phase) {
        if (isPredictionMode && simulator.phase == BattlePhase.VICTORY_SCREEN) {
            if (isCorrect) {
                CurrencyManager.awardPayout(config.battleInstanceId, pred.totalReturn)
            } else {
                CurrencyManager.recordLoss(config.battleInstanceId)
            }
        }
    }

    val currentCoins by CurrencyManager.coins.collectAsState()
    val animatedCoins by androidx.compose.animation.core.animateIntAsState(
        targetValue = currentCoins,
        animationSpec = androidx.compose.animation.core.tween(durationMillis = 1000)
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xCC000000))
            .padding(20.dp),
        contentAlignment = Alignment.Center
    ) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .border(
                    2.dp,
                    if (isPredictionMode) (if (isCorrect) Color(0xFF10B981) else Color(0xFFEF4444)) else bannerColor,
                    RoundedCornerShape(16.dp)
                ),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A))
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "決 着 (COMPLETE)",
                    color = Color(0xFFFBBF24),
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )

                Spacer(modifier = Modifier.height(4.dp))

                Text(
                    text = teamTitle,
                    color = bannerColor,
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Black,
                    letterSpacing = 1.sp
                )

                Spacer(modifier = Modifier.height(12.dp))

                if (isPredictionMode) {
                    // PREDICTION OUTCOME BANNER
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (isCorrect) Color(0xFF065F46) else Color(0xFF7F1D1D))
                            .padding(vertical = 8.dp, horizontal = 12.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = if (isCorrect) "✓ PREDICTION CORRECT" else "✕ PREDICTION WRONG",
                            color = Color.White,
                            fontWeight = FontWeight.Black,
                            fontSize = 15.sp,
                            letterSpacing = 1.sp
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Payout details box
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp)
                        ) {
                            if (pred.tier == PredictionTier.FREE) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text("MODE:", color = Color(0xFF94A3B8), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    Text("FREE PREDICTION", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Black)
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text("REWARD:", color = Color(0xFF94A3B8), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    Text(
                                        text = if (isCorrect) "+25 🪙" else "0 🪙",
                                        color = if (isCorrect) Color(0xFF10B981) else Color(0xFF94A3B8),
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Black,
                                        fontFamily = FontFamily.Monospace
                                    )
                                }
                            } else {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text("WAGER:", color = Color(0xFF94A3B8), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    Text("${pred.wagerAmount} 🪙", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Black)
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text("MULTIPLIER:", color = Color(0xFF94A3B8), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    Text(pred.tier.displayName, color = Color(0xFFFBBF24), fontSize = 11.sp, fontWeight = FontWeight.Black)
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                if (isCorrect) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text("PROFIT:", color = Color(0xFF94A3B8), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                        Text("+${pred.potentialProfit} 🪙", color = Color(0xFF10B981), fontSize = 12.sp, fontWeight = FontWeight.Black)
                                    }
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text("TOTAL RETURN:", color = Color(0xFFFDE047), fontSize = 11.sp, fontWeight = FontWeight.Black)
                                        Text("${pred.totalReturn} 🪙", color = Color(0xFFFDE047), fontSize = 12.sp, fontWeight = FontWeight.Black)
                                    }
                                } else {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text("WAGER LOST:", color = Color(0xFFEF4444), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                        Text("-${pred.wagerAmount} 🪙", color = Color(0xFFEF4444), fontSize = 12.sp, fontWeight = FontWeight.Black)
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(6.dp))
                            Divider(color = Color(0xFF334155), thickness = 0.5.dp)
                            Spacer(modifier = Modifier.height(6.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("NEW BALANCE:", color = Color(0xFFFBBF24), fontSize = 12.sp, fontWeight = FontWeight.Black)
                                Text(
                                    text = "🪙 ${String.format("%,d", animatedCoins)}",
                                    color = Color(0xFFFDE047),
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Black,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Button(
                        onClick = {
                            if (onNextPrediction != null) {
                                onNextPrediction()
                            } else {
                                onMainMenu()
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFF59E0B)),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("next_prediction_button"),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("NEXT PREDICTION", color = Color.Black, fontWeight = FontWeight.Black)
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    TextButton(
                        onClick = onMainMenu,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(44.dp)
                            .testTag("prediction_main_menu_button")
                    ) {
                        Text("MAIN MENU", color = Color(0xFF94A3B8), fontWeight = FontWeight.SemiBold)
                    }
                } else {
                    // Standard Victory Screen (1v1, 2v2, Random)
                    Row(
                        horizontalArrangement = Arrangement.Center,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        for (charId in simulator.winnerFighters) {
                            val def = CharacterRegistry.get(charId)
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                modifier = Modifier.padding(horizontal = 8.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(56.dp)
                                        .clip(CircleShape)
                                        .background(def.secondaryColor)
                                        .border(2.dp, bannerColor, CircleShape),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = def.id.displayName.take(2),
                                        color = Color.White,
                                        fontSize = 18.sp,
                                        fontWeight = FontWeight.Black
                                    )
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = def.id.displayName,
                                    color = Color.White,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(24.dp))

                    Button(
                        onClick = onRematch,
                        colors = ButtonDefaults.buttonColors(containerColor = bannerColor),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("rematch_button"),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Refresh, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("REMATCH", fontWeight = FontWeight.Black)
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedButton(
                        onClick = onSelectFighters,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("select_fighters_button"),
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White)
                    ) {
                        Text("CHARACTER SELECT", fontWeight = FontWeight.Bold)
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    TextButton(
                        onClick = onMainMenu,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("main_menu_button")
                    ) {
                        Text("MAIN MENU", color = Color(0xFF94A3B8), fontWeight = FontWeight.SemiBold)
                    }
                }
            }
        }
    }
}
