package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.SportsMma
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.CharacterRegistry

@Composable
fun HowToPlayScreen(
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler { onBack() }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(
                        Color(0xFF030712),
                        Color(0xFF0F172A),
                        Color(0xFF020617)
                    )
                )
            )
            .systemBarsPadding()
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp, vertical = 8.dp)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = onBack,
                    modifier = Modifier.testTag("back_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.ArrowBack,
                        contentDescription = "Back",
                        tint = Color.White
                    )
                }

                Spacer(modifier = Modifier.width(8.dp))

                Column {
                    Text(
                        text = "MANGA BATTLE ARCHIVE",
                        color = Color(0xFFFBBF24),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                    Text(
                        text = "HOW TO PLAY & MECHANICS",
                        color = Color.White,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Black
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // 1. Core Rule Card
                item {
                    RuleCard(
                        title = "1. ZERO PLAYER CONTROLS (AUTONOMOUS)",
                        icon = Icons.Default.SportsMma,
                        accentColor = Color(0xFF38BDF8),
                        content = "You do NOT control the fighters during battle! Select characters, start the match, and watch them continuously bounce around the square arena while automatically triggering attacks, collisions, and rage specials."
                    )
                }

                // 2. DVD Screensaver Movement
                item {
                    RuleCard(
                        title = "2. DVD-SCREENSAVER PHYSICS",
                        icon = Icons.Default.Bolt,
                        accentColor = Color(0xFFFACC15),
                        content = "Every fighter continuously moves across the square arena like a DVD logo screensaver. Hitting walls reflects velocity and maintains momentum. They never stop to wait, creating emergent chaotic clashes."
                    )
                }

                // 3. Collision vs Barrage (Strict distinction)
                item {
                    RuleCard(
                        title = "3. BALL COLLISION VS BARRAGE ATTACK",
                        icon = Icons.Default.Shield,
                        accentColor = Color(0xFFEF4444),
                        content = "• Ball-to-Ball Collision: Strong mutual physical knockback! Two balls slam together, separate instantly, and bounce apart with moderate damage.\n• Barrage Attacks: Rapid flurry of visible fists or rapiers. Inflicts multi-hits and brief hit-stop, but does NOT launch opponents across the arena."
                    )
                }

                // 4. Time Stop Rule
                item {
                    RuleCard(
                        title = "4. EXACT 8-SECOND TIME STOP",
                        icon = Icons.Default.Timer,
                        accentColor = Color(0xFFA855F7),
                        content = "Jotaro and DIO can activate Time Stop for exactly 8 seconds when their Rage meter fills. During Time Stop, all enemies, projectiles, and physics are frozen in place while the user moves rapidly to attack!"
                    )
                }

                // Header for the 9 characters
                item {
                    Text(
                        text = "THE 9 ROSTER FIGHTERS",
                        color = Color(0xFFFBBF24),
                        fontWeight = FontWeight.Black,
                        fontSize = 14.sp,
                        fontFamily = FontFamily.Monospace,
                        modifier = Modifier.padding(top = 8.dp)
                    )
                }

                // 5. The 9 Characters breakdown
                items(CharacterRegistry.characters.values.toList()) { def ->
                    CharacterArchiveCard(def = def)
                }

                item {
                    Spacer(modifier = Modifier.height(24.dp))
                }
            }
        }
    }
}

@Composable
private fun RuleCard(
    title: String,
    icon: ImageVector,
    accentColor: Color,
    content: String
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .border(1.dp, accentColor.copy(alpha = 0.5f), RoundedCornerShape(12.dp)),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A))
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(32.dp)
                        .clip(CircleShape)
                        .background(accentColor.copy(alpha = 0.2f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(imageVector = icon, contentDescription = null, tint = accentColor, modifier = Modifier.size(18.dp))
                }
                Spacer(modifier = Modifier.width(10.dp))
                Text(
                    text = title,
                    color = Color.White,
                    fontWeight = FontWeight.Black,
                    fontSize = 13.sp
                )
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = content,
                color = Color(0xFFCBD5E1),
                fontSize = 12.sp,
                lineHeight = 17.sp
            )
        }
    }
}

@Composable
private fun CharacterArchiveCard(def: com.example.model.CharacterDef) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .border(1.dp, Color(0xFF334155), RoundedCornerShape(10.dp)),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF0B1120))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(46.dp)
                    .clip(CircleShape)
                    .background(def.secondaryColor)
                    .border(2.dp, def.accentColor, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = def.id.displayName.take(2),
                    color = Color.White,
                    fontWeight = FontWeight.Black,
                    fontSize = 16.sp
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = def.id.displayName,
                        color = Color.White,
                        fontWeight = FontWeight.Black,
                        fontSize = 14.sp
                    )
                    Text(
                        text = "SPD: ${def.baseSpeed.toInt()}",
                        color = Color(0xFF38BDF8),
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }

                Text(
                    text = "Stand: ${def.id.standName} • ${def.id.title}",
                    color = Color(0xFF94A3B8),
                    fontSize = 11.sp
                )

                Spacer(modifier = Modifier.height(4.dp))

                Text(
                    text = "Rage (${def.rageDuration.toInt()}s): ${def.rageName} - ${def.rageDescription}",
                    color = Color(0xFFFBBF24),
                    fontSize = 11.sp,
                    lineHeight = 14.sp
                )
            }
        }
    }
}
